// ══════════════════════════════════════════════════════════════════════
// GALAXY FORGE v7 — Full Universe Simulator
// Features: Galaxy · Civ · Ships · Supernova · Tidal Spaghettification
//           Binary Planets · Surface View · Solar Flares · Mag Fields
// ══════════════════════════════════════════════════════════════════════

const cv=document.getElementById('cv'),ctx=cv.getContext('2d');
let bodies=[],spawnT=null,orbitSh='circle';
let paused=false,simSpd=1,simTime=0,gravSim=true,showNebulae=true,showMagFields=true;
let camX=0,camY=0,camSc=1,followBody=null;
let isDrag=false,dragSX=0,dragSY=0,camSX=0,camSY=0;
let dragBodyId=null,dragOX=0,dragOY=0;
let nextId=1,gravMult=1,selectedId=null;
let nebulae=[],galaxies=[];
let civilizations=[],ships=[],cFlashes=[],solarEvents=[];
let binaryPairs=[];  // {aId,bId,timer,captured}
let waterFloodAnims=[]; // active water flood animations
const CNT={p:0,s:0,h:0,b:0,a:0};
const TEX={};

// ── Supernova — only Yellow+Blue, min 50k yr ──────────────────
const SUPERNOVA_CAPABLE=['star-yellow','star-blue-giant'];
const SUPERNOVA_MIN_YR=50000; // simTime years

const SDEFS={
  'star-red-dwarf':{name:'Red Dwarf',mass:30,radius:12,lum:0.04,color:'#ff6633',glow:'#ff3300',tempK:3200,lifespan:99999,canSupernova:false},
  'star-yellow':{name:'Yellow Star',mass:100,radius:28,lum:1,color:'#fff44f',glow:'#ffcc00',tempK:5778,lifespan:99999,canSupernova:true},
  'star-blue-giant':{name:'Blue Giant',mass:800,radius:42,lum:100,color:'#aaddff',glow:'#4499ff',tempK:20000,lifespan:99999,canSupernova:true},
  'star-white-dwarf':{name:'White Dwarf',mass:80,radius:8,lum:0.01,color:'#eeeeff',glow:'#aabbff',tempK:25000,lifespan:99999,canSupernova:false},
  'neutron-star':{name:'Neutron Star',mass:200,radius:4,lum:0.001,color:'#ccddff',glow:'#8899ff',tempK:600000,lifespan:99999,canSupernova:false,isPulsar:false},
  'pulsar':{name:'Pulsar',mass:200,radius:4,lum:10,color:'#aaffee',glow:'#00ffcc',tempK:1000000,lifespan:99999,canSupernova:false,isPulsar:true},
};
const PDEFS={
  rocky:{name:'Rocky',mass:1,radius:7,sub:'rocky',colors:['#8b7355','#a0856a','#7a6045']},
  gas:{name:'Gas Giant',mass:5,radius:20,sub:'gas',colors:['#e8c87a','#d4a050','#c89040']},
  ice:{name:'Ice Giant',mass:4,radius:15,sub:'ice',colors:['#7ac8e8','#5099bb','#3377aa']},
  lava:{name:'Lava World',mass:1.2,radius:7,sub:'rocky',colors:['#ff4400','#cc2200','#ff6600']},
  ocean:{name:'Ocean World',mass:1.5,radius:8,sub:'rocky',colors:['#2255dd','#1144bb','#3366ee']},
  desert:{name:'Desert',mass:0.9,radius:7,sub:'rocky',colors:['#ddaa44','#cc9933','#bbaa55']},
};
const EVO={
  lava:{base:'#cc2200',atmo:0.1,label:'🌋 LAVA'},
  cooling:{base:'#884422',atmo:0.15,label:'🌑 COOLING'},
  rocky:{base:'#8b7355',atmo:0.2,label:'🪨 ROCKY'},
  arid:{base:'#c8984a',atmo:0.25,label:'🏜 ARID'},
  ocean:{base:'#2255bb',atmo:0.5,label:'🌊 OCEAN'},
  life:{base:'#1a6b33',atmo:0.65,label:'🌍 LIFE'},
  advanced:{base:'#1a4488',atmo:0.8,label:'🌐 ADV'},
  magma:{base:'#ff2200',atmo:0.05,label:'💥 MAGMA'},
  freezing:{base:'#88aacc',atmo:0.35,label:'🥶 FREEZING'},
  frozen:{base:'#c8dff0',atmo:0.15,label:'❄ FROZEN'},
};
const CIV_STAGES=['Primitive','Ancient','Medieval','Industrial','Atomic','Spacefaring','Interstellar','Transcendent'];
const CIV_COLORS=['#aa8844','#cc9922','#44aa88','#4488cc','#8844cc','#44ccaa','#cc44aa','#ffffff'];
const CIV_NAMES=['Aethon','Veln','Zuri','Kalos','Miren','Thyra','Solun','Drakis','Ixon','Veloth','Cyren','Arun','Elvan','Moryn','Tessik','Oryn','Pyrith','Nexal','Velkir','Sundra'];
let civNameIdx=0;

// ── Canvas + Camera ───────────────────────────────────────────
function resize(){
  const c=document.getElementById('cc');
  cv.width=c.clientWidth;cv.height=c.clientHeight;
}
function resizeSV(){
  const svc=document.getElementById('sv-cv');
  svc.width=window.innerWidth;
  svc.height=window.innerHeight-42;
}
window.addEventListener('resize',resize);resize();
const w2s=(wx,wy)=>({x:wx*camSc+camX,y:wy*camSc+camY});
const s2w=(sx,sy)=>({x:(sx-camX)/camSc,y:(sy-camY)/camSc});

// ── Noise ─────────────────────────────────────────────────────
function hash(x,y,s=0){let h=((x*374761393+y*668265263+(s|0)*2246822519)|0)*2246822519;h=(h^(h>>13))*1274126177;return((h^(h>>16))&0x7fffffff)/0x7fffffff;}
function snoise(x,y,s=0){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);return hash(xi,yi,s)*(1-u)*(1-v)+hash(xi+1,yi,s)*u*(1-v)+hash(xi,yi+1,s)*(1-u)*v+hash(xi+1,yi+1,s)*u*v;}
function fbm(x,y,s,oct=4){let v=0,a=0.5,f=1;for(let i=0;i<oct;i++){v+=a*snoise(x*f,y*f,s+i*137);a*=0.5;f*=2.1;}return v;}
// Domain-warped fbm — makes organically swirling shapes
function wfbm(x,y,s,oct=4,str=1.2){
  const qx=fbm(x+0.4,y+2.3,s+77,3),qy=fbm(x+9.2,y+6.8,s+33,3);
  const rx=fbm(x+4.0*qx+1.7,y+4.0*qy+9.2,s+11,3),ry=fbm(x+4.0*qx+8.3,y+4.0*qy+2.8,s+55,3);
  return fbm(x+str*rx,y+str*ry,s,oct);
}
// Ridged multifractal — sharp ridges for mountains / lava cracks
function ridged(x,y,s,oct=5){let v=0,a=0.5,f=1,w=1;for(let i=0;i<oct;i++){const n=1-Math.abs(snoise(x*f,y*f,s+i*137)*2-1);v+=a*n*n*w;w=Math.min(1,n);a*=0.5;f*=2.2;}return v;}
// Voronoi cell distance — great for craters & plates
function vor(x,y,s){const xi=Math.floor(x),yi=Math.floor(y);let md=9,md2=9;
  for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){
    const h1=hash(xi+dx,yi+dy,s),h2=hash(xi+dx,yi+dy,s+4444);
    const d=Math.hypot(x-(xi+dx+h1),y-(yi+dy+h2));
    if(d<md){md2=md;md=d;}else if(d<md2){md2=d;}}
  return{f1:md,f2:md2,edge:md2-md};}
// Turbulence (abs fbm) — good for stormy/chaotic detail
function turb(x,y,s,oct=4){let v=0,a=0.5,f=1;for(let i=0;i<oct;i++){v+=a*Math.abs(snoise(x*f,y*f,s+i*137)*2-1);a*=0.5;f*=2.1;}return v;}

// ── Zone system ───────────────────────────────────────────────
function getZB(def){const l=Math.sqrt((def?.lum||1))*Math.sqrt((def?.radius||18)/18);return{hot:55*l,warm:95*l,hab1:135*l,hab2:210*l,cold:300*l,out:550*l};}
function getZone(d,def){const z=getZB(def);if(d<z.hot)return'hot';if(d<z.warm)return'warm';if(d<z.hab1)return'inner-hab';if(d<z.hab2)return'habitable';if(d<z.cold)return'outer-hab';return'cold';}
function getPlanetTemp(p){const star=bodies.find(b=>b.id===p.orbitStar);if(!star)return 40;const d=Math.hypot(p.x-star.x,p.y-star.y);return Math.min(Math.max(278*Math.pow(star.lum||1,0.25)/Math.pow(Math.max(d,1)/100,0.5),10),4000);}
function tempToColor(T){if(T<200)return'#4488ff';if(T<300)return'#88ccff';if(T<400)return'#00ff88';if(T<600)return'#ffcc00';if(T<1000)return'#ff8800';return'#ff3300';}
function getNearStar(wx,wy){let n=null,md=Infinity;for(const b of bodies){if(b.type==='star'||b.type==='hole'){const d=Math.hypot(b.x-wx,b.y-wy);if(d<md){md=d;n=b;}}}return n;}

// ── Nebulae ───────────────────────────────────────────────────
function genNebula(cx,cy,type='diffuse'){
  const cols={diffuse:['#ff6b9d','#9d6bff','#6b9dff'],stellar:['#ffaa44','#ff6600','#ffdd88'],emission:['#ff4488','#ff88cc','#cc44ff']};
  const col=cols[type]||cols.diffuse;
  return{id:nextId++,type:'nebula',nebType:type,name:(type==='stellar'?'Stellar ':'')+'Nebula '+nextId,
    x:cx,y:cy,radius:250+Math.random()*400,colors:col,seed:Math.random()*1000,
    starFormRate:type==='stellar'?0.0003:0.00004,age:0,
    particles:genNebParticles(cx,cy,250+Math.random()*400,col)};
}
function genNebParticles(cx,cy,r,colors){
  const pts=[];for(let i=0;i<60;i++){
    const a=Math.random()*Math.PI*2,d=Math.pow(Math.random(),0.5)*r;
    pts.push({x:cx+Math.cos(a)*d,y:cy+Math.sin(a)*d,r:4+Math.random()*14,
      color:colors[Math.floor(Math.random()*colors.length)],alpha:0.025+Math.random()*0.065,
      vx:(Math.random()-.5)*0.015,vy:(Math.random()-.5)*0.015});}
  return pts;
}

// ── GALAXY GENERATOR ─────────────────────────────────────────
function genGalaxy(){
  clearAll();
  const arms=5,starsPerArm=18,cx=0,cy=0;
  const galId=nextId++;
  galaxies.push({id:galId,cx,cy,vx:0,vy:0,name:'Milky Way',stars:[]});
  // Central supermassive black hole
  const bhMass=200000;
  const bh={id:nextId++,type:'hole',sub:'black',name:'Sgr A*',
    x:cx,y:cy,vx:0,vy:0,mass:bhMass,baseMass:bhMass,radius:45,age:0,angle:0,
    repulse:false,accretionParticles:genAccretion(cx,cy,45),galaxyId:galId};
  bodies.push(bh);CNT.h++;
  // Nuclear star cluster (dense core)
  for(let i=0;i<12;i++){
    const a=Math.random()*Math.PI*2,d=60+Math.random()*120;
    mkGalStar(cx+Math.cos(a)*d,cy+Math.sin(a)*d,'star-yellow',galId,0.8);
  }
  // Spiral arms
  for(let arm=0;arm<arms;arm++){
    for(let i=0;i<starsPerArm;i++){
      const t=i/starsPerArm;
      const aAngle=(arm/arms)*Math.PI*2;
      const spiral=aAngle+t*Math.PI*3;
      const dist=130+t*900+((Math.random()-.5)*100);
      const wx=cx+Math.cos(spiral)*dist+(Math.random()-.5)*90;
      const wy=cy+Math.sin(spiral)*dist+(Math.random()-.5)*90;
      const starTypes=['star-yellow','star-red-dwarf','star-blue-giant','star-white-dwarf'];
      const weights=[0.48,0.38,0.08,0.06];
      let rt=Math.random(),sT='star-yellow',acc=0;
      for(let w=0;w<weights.length;w++){acc+=weights[w];if(rt<acc){sT=starTypes[w];break;}}
      mkGalStar(wx,wy,sT,galId,0.5+Math.random()*0.9);
    }
  }
  // Halo scattered stars
  for(let i=0;i<20;i++){
    const a=Math.random()*Math.PI*2,d=800+Math.random()*800;
    mkGalStar(cx+Math.cos(a)*d,cy+Math.sin(a)*d,'star-red-dwarf',galId,0.6);
  }
  // Nebulae
  for(let i=0;i<9;i++){
    const a=Math.random()*Math.PI*2,d=150+Math.random()*700;
    nebulae.push(genNebula(cx+Math.cos(a)*d,cy+Math.sin(a)*d,Math.random()<0.35?'stellar':'diffuse'));
  }
  camX=cv.width/2;camY=cv.height/2;camSc=0.08;
  updCnt();log('Galaxy generated!','n');ntf('🌌 Galaxy generated — zoom out to see it all!');
  return galId;
}

function mkGalStar(wx,wy,sT,galId,ms){
  const def=SDEFS[sT];if(!def)return;
  const star={id:nextId++,type:'star',sub:sT,
    name:def.name+' '+String.fromCharCode(65+Math.floor(Math.random()*26))+Math.floor(Math.random()*99),
    x:wx,y:wy,vx:0,vy:0,
    mass:def.mass*ms,radius:def.radius*(0.65+ms*.5),
    color:def.color,glow:def.glow,lum:def.lum*(0.5+ms*.8),tempK:def.tempK,
    def,age:Math.random()*50000,
    moons:[],rings:0,angle:Math.random()*Math.PI*2,
    _oA:0,_oR:0,_oSpd:0,_multi:false,
    lifespan:99999,supernovaTriggered:false,canSupernova:def.canSupernova,galaxyId:galId,
    magField:Math.random()<0.4?{strength:0.3+Math.random()*0.7,radius:def.radius*(2+Math.random()*3)}:null};
  bodies.push(star);CNT.s++;
  const nPlanets=1+Math.floor(Math.random()*4);
  for(let p=0;p<nPlanets;p++)spawnPlanetAround(star,p);
  return star;
}

function spawnPlanetAround(star,idx){
  const dists=[85,160,240,330,440,560];
  const dist=dists[idx%dists.length]*(0.65+Math.random()*0.75);
  const angle=Math.random()*Math.PI*2;
  const ptypes=['rocky','rocky','gas','ice','desert','ocean','lava','rocky','gas'];
  const pt=ptypes[Math.floor(Math.random()*ptypes.length)];
  const def=PDEFS[pt];
  const orbitSpd=Math.sqrt(star.mass*0.0002/dist)*60/dist;
  const p={id:nextId++,type:'planet',sub:def.sub,pt,
    name:star.name.replace(/\s/g,'').slice(-4)+['I','II','III','IV','V'][idx],
    x:star.x+Math.cos(angle)*dist,y:star.y+Math.sin(angle)*dist,
    vx:-Math.sin(angle)*orbitSpd*dist*60,vy:Math.cos(angle)*orbitSpd*dist*60,
    mass:def.mass*10,radius:def.radius*(0.55+Math.random()*0.9),
    colors:[...def.colors],color:def.colors[0],
    orbitAngle:angle,orbitRadius:dist,orbitA:dist,orbitB:dist,orbitEcc:0,orbitSpd,
    orbitStar:star.id,lockedOrbit:true,
    age:0,moons:[],rings:pt==='gas'&&Math.random()<0.4?Math.floor(Math.random()*3+1):0,
    hasLife:false,hadWater:false,atmo:def.sub==='gas'?1:0.2,
    strippedGas:false,zone:'unknown',noiseOff:Math.random()*1000,cloudAngle:0,shapeY:1,
    roughness:0.5,tempK:0,evoStage:pt,evoProgress:0,civilizationId:null,
    magField:Math.random()<0.3?{strength:0.2+Math.random()*0.5,radius:def.radius*(1.5+Math.random()*2)}:null,
    tidal:{sx:1,sy:1},cooldownTimer:0,waterFloodProgress:0};
  bodies.push(p);CNT.p++;
  return p;
}

// ── ASTEROID FIELD ────────────────────────────────────────────
function spawnAsteroidField(count=1000){
  const ctr=s2w(cv.width/2,cv.height/2);
  const star=getNearStar(ctr.x,ctr.y)||{x:0,y:0,mass:100};
  for(let i=0;i<count;i++){
    const angle=Math.random()*Math.PI*2,dist=100+Math.pow(Math.random(),0.5)*700;
    const wx=star.x+Math.cos(angle)*dist,wy=star.y+Math.sin(angle)*dist;
    const v=Math.sqrt((star.mass||100)*0.0002/dist)*60*(0.6+Math.random()*0.8);
    bodies.push({id:nextId++,type:'asteroid',name:'Ast.'+nextId,
      isWater:Math.random()<0.18,x:wx,y:wy,
      vx:-Math.sin(angle)*v+(Math.random()-.5)*v*.35,
      vy:Math.cos(angle)*v+(Math.random()-.5)*v*.35,
      mass:0.01+Math.random()*0.12,radius:1+Math.random()*3.5,
      orbitStar:star.id,age:Math.random()*80,
      angle:Math.random()*Math.PI*2,rotSpd:(Math.random()-.5)*0.12,tidal:{sx:1,sy:1}});
    CNT.a++;
  }
  updCnt();log(`${count} asteroids spawned`,'n');ntf(`☄ ${count} asteroids!`);
}

// ── ACCRETION + BELT ──────────────────────────────────────────
function genAccretion(cx,cy,r){
  const pts=[];for(let i=0;i<120;i++){
    const a=Math.random()*Math.PI*2,d=r*(1.4+Math.random()*4);
    pts.push({a,dist:d,speed:0.001+Math.random()*0.007,size:0.5+Math.random()*1.8,
      color:['#ff8800','#ff4400','#ffaa00','#dd6600','#ff6600'][Math.floor(Math.random()*5)]});}
  return pts;
}
function genBelt(cx,cy,radius){
  const pts=[];for(let i=0;i<160;i++){
    const a=Math.random()*Math.PI*2,r=radius+(Math.random()-.5)*35;
    pts.push({angle:a,r,speed:(0.0004+Math.random()*0.0009)*(Math.random()>.5?1:-1),size:0.4+Math.random()*2.2});}
  return pts;
}

// ── MULTI-STAR ────────────────────────────────────────────────
function setupMultiStar(){
  const ss=bodies.filter(b=>b.type==='star');const n=ss.length;
  if(n<2){if(n===1)ss[0]._multi=false;return;}
  const cx=ss.reduce((s,b)=>s+b.x,0)/n,cy=ss.reduce((s,b)=>s+b.y,0)/n;
  const tm=ss.reduce((s,b)=>s+b.mass,0),R=120+n*18;
  ss.forEach((s,i)=>{const a=(i/n)*Math.PI*2;s.x=cx+Math.cos(a)*R;s.y=cy+Math.sin(a)*R;
    const v=Math.sqrt(tm*.00014/R)*52;s.vx=-Math.sin(a)*v;s.vy=Math.cos(a)*v;
    s._multi=true;s._oA=a;s._oR=R;s._oSpd=v/R*.015;});
}

// ── SUPERNOVA ─────────────────────────────────────────────────
// Only yellow+blue, only after 50k simTime years
function checkSupernovaConditions(star,dt){
  if(star.supernovaTriggered)return;
  if(!star.canSupernova)return;
  if(simTime<SUPERNOVA_MIN_YR)return;
  // Random chance per year after 50k
  const chancePerSec=0.000001*simSpd;
  if(Math.random()<chancePerSec*dt){
    triggerSupernova(star);
  }
}

function triggerSupernova(star){
  if(star.supernovaTriggered)return;
  star.supernovaTriggered=true;
  star.supernovaAge=0;
  star.supernovaPhase='swell'; // swell -> flash -> shrink -> white_dwarf
  star.origRadius=star.radius;
  log(`💥 SUPERNOVA: ${star.name}!`,'w');
  ntf(`💥 SUPERNOVA! ${star.name}`,'w');
  sndSupernova();
  // Create stellar nebula at location
  nebulae.push(genNebula(star.x,star.y,'stellar'));
  // Blast all nearby bodies
  for(const p of bodies.filter(b=>b.type==='planet'||b.type==='asteroid')){
    const d=Math.hypot(p.x-star.x,p.y-star.y);
    if(d<800){
      const a=Math.atan2(p.y-star.y,p.x-star.x),f=(800-d)*.5;
      p.vx+=Math.cos(a)*f;p.vy+=Math.sin(a)*f;p.lockedOrbit=false;
    }
  }
  flash(star.x,star.y,star.radius*3,'#ffffff',true);
}

function updateSupernovaAnimation(star,dt){
  if(!star.supernovaTriggered)return;
  star.supernovaAge+=dt;
  const origR=star.origRadius||star.radius;
  if(star.supernovaPhase==='swell'){
    // Expand over 3 seconds
    star.radius=origR*(1+Math.min(star.supernovaAge/3,1)*5);
    if(star.supernovaAge>3){star.supernovaPhase='flash';star.supernovaAge=0;}
  } else if(star.supernovaPhase==='flash'){
    if(star.supernovaAge<0.05){
      flash(star.x,star.y,star.radius*9,'#ffffcc',true);
      for(const p of bodies.filter(b=>b.type==='planet'||b.type==='asteroid')){
        const dx=p.x-star.x,dy=p.y-star.y,d=Math.hypot(dx,dy)||1;
        if(d<star.radius*35){const f=(star.radius*35-d)/(star.radius*35)*0.7;
          p.vx+=(dx/d)*f*60;p.vy+=(dy/d)*f*60;
          if((p.evoStage==='life'||p.evoStage==='advanced')&&Math.random()>.3){p.hasLife=false;setEvoStage(p,'lava');}
        }
      }
    }
    if(star.supernovaAge>1.5){star.supernovaPhase='shrink';star.supernovaAge=0;}
  } else if(star.supernovaPhase==='shrink'){
    // Shrink back to white dwarf size
    const t=Math.min(star.supernovaAge/5,1);
    star.radius=origR*(1+5*(1-t))*(1-t)+SDEFS['star-white-dwarf'].radius*t;
    if(star.supernovaAge>5){
      star.supernovaPhase='white_dwarf';
      star.radius=SDEFS['star-white-dwarf'].radius;
      Object.assign(star,{sub:'star-white-dwarf',color:SDEFS['star-white-dwarf'].color,
        glow:SDEFS['star-white-dwarf'].glow,lum:SDEFS['star-white-dwarf'].lum,
        def:SDEFS['star-white-dwarf'],canSupernova:false,supernovaTriggered:false});
      log(`${star.name} → White Dwarf`,'n');ntf(`⚪ White Dwarf formed!`);
      // Schedule black hole formation in ~3 real hours = 10800 seconds
      // For sim purposes: 3 hours real time at sim speed
      star._bhTimer=0;
      star._becomesBH=true;
      star._supernovaAge=0;
    }
  }
  // White dwarf slowly collapses into black hole
  if(star._becomesBH){
    star._bhTimer=(star._bhTimer||0)+dt;
    // Pulsing and shrinking
    const pulseFreq=Math.min(star._bhTimer*0.5,4);
    star._bhPulse=Math.sin(star._bhTimer*pulseFreq)*0.5;
    // After 180 seconds (3 sim minutes = represents 3 hours at 1× speed)
    if(star._bhTimer>180){
      triggerBlackHoleFormation(star);
    }
  }
}

function triggerBlackHoleFormation(star){
  log(`🌑 ${star.name} collapsing to Black Hole!`,'w');
  ntf(`🌑 Black Hole forming! Tidal forces incoming!`,'w');
  star._bhTimer=-999;star._becomesBH=false;
  star._bhFormAnim={age:0};
  // Animate collapse over 5 seconds then replace with hole
  star._collapsing=true;
  star._collapseAge=0;
  setTimeout(()=>{
    const idx=bodies.findIndex(b=>b.id===star.id);
    if(idx===-1)return;
    const bh={id:nextId++,type:'hole',sub:'black',
      name:star.name+' BH',x:star.x,y:star.y,vx:star.vx,vy:star.vy,
      mass:star.mass*1.5,baseMass:star.mass*1.5,radius:22,
      age:0,angle:0,repulse:false,accretionParticles:genAccretion(star.x,star.y,22),
      justFormed:true,formAge:0};
    bodies.splice(idx,1,bh);CNT.s--;CNT.h++;
    flash(bh.x,bh.y,200,'#000033',true);
    ntf(`⚫ Black Hole ${bh.name} formed!`,'sp');
    sndBlackHoleForm();
    log(`⚫ Black Hole formed at ${Math.round(bh.x)},${Math.round(bh.y)}`,'l');
    updCnt();
  },5000/simSpd);
}

// ── GAS GIANT STRIPPING ────────────────────────────────────────
function checkGasStrip(p){
  if(p.sub!=='gas'||p.strippedGas)return;
  const star=bodies.find(b=>b.id===p.orbitStar);if(!star)return;
  const d=Math.hypot(p.x-star.x,p.y-star.y);
  const z=getZone(d,star.def||star);
  if(z==='habitable'||z==='inner-hab'||z==='hot'||z==='warm'){
    p.strippedGas=true;
    // Strip gas - spawn gas particles orbiting star
    for(let i=0;i<12;i++){
      const ang=Math.random()*Math.PI*2;
      const gd=d*(0.5+Math.random()*0.8);
      cFlashes.push({x:star.x+Math.cos(ang)*gd,y:star.y+Math.sin(ang)*gd,r:4,age:0,maxAge:1.5,color:'#e8c87a',isGas:true});
    }
    p.sub='rocky';p.pt='rocky';p.evoStage='rocky';p.evoProgress=0;
    p.mass=p.mass*.3;p.radius=Math.max(p.radius*.5,5);
    p.atmo=0.05;p.colors=PDEFS.rocky.colors;p.color=p.colors[0];
    delete TEX[p.id];
    flash(p.x,p.y,p.radius*3,'#e8c87a');
    log(`${p.name}: gas stripped → rocky core!`,'w');
    ntf(`🌀 ${p.name} gas stripped!`,'w');
  }
}

// ── TIDAL SPAGHETTIFICATION ────────────────────────────────────
function calcTidalStretch(body){
  if(!body.tidal)body.tidal={sx:1,sy:1};
  let maxTidal=0,tidalAngle=0;
  for(const hole of bodies.filter(b=>b.type==='hole'&&b.sub==='black'&&!b.repulse)){
    const dx=hole.x-body.x,dy=hole.y-body.y;
    const d=Math.hypot(dx,dy);
    const rs=hole.radius*8;
    if(d<rs*5){
      const strength=Math.pow(Math.max(0,1-d/(rs*5)),2)*3;
      if(strength>maxTidal){maxTidal=strength;tidalAngle=Math.atan2(dy,dx);}
    }
  }
  if(maxTidal>0){
    body.tidal.sx=1+maxTidal*2.5;
    body.tidal.sy=1-maxTidal*0.7;
    body.tidalAngle=tidalAngle;
  } else {
    body.tidal.sx+=(1-body.tidal.sx)*0.1;
    body.tidal.sy+=(1-body.tidal.sy)*0.1;
  }
  if(maxTidal>0.5){throttleSound('tidal'+body.id,()=>sndTidalPull(Math.min(1,maxTidal)),0.8);}
}

// ── BINARY PLANETS ────────────────────────────────────────────
function checkBinaryPlanets(){
  const planets=bodies.filter(b=>b.type==='planet'&&!b.binaryCapture);
  for(let i=0;i<planets.length;i++){
    for(let j=i+1;j<planets.length;j++){
      const a=planets[i],b=planets[j];
      const d=Math.hypot(a.x-b.x,a.y-b.y);
      const captureD=(a.radius+b.radius)*6;
      if(d<captureD&&!binaryPairs.find(p=>(p.aId===a.id&&p.bId===b.id)||(p.aId===b.id&&p.bId===a.id))){
        // Capture as binary pair
        a.binaryCapture=true;b.binaryCapture=true;
        binaryPairs.push({aId:a.id,bId:b.id,timer:0,collisionTime:18000,phase:'orbit'});
        log(`Binary capture: ${a.name} + ${b.name}!`,'l');
        ntf(`🌍🌍 Binary planets: ${a.name} & ${b.name}!`,'lf');
      }
    }
  }
  // Update binary pairs
  for(let i=binaryPairs.length-1;i>=0;i--){
    const pair=binaryPairs[i];
    const pa=bodies.find(b=>b.id===pair.aId);
    const pb=bodies.find(b=>b.id===pair.bId);
    if(!pa||!pb){binaryPairs.splice(i,1);continue;}
    pair.timer+=1;
    // Spiral inward
    const dx=pb.x-pa.x,dy=pb.y-pa.y;
    const d=Math.hypot(dx,dy);
    const t=pair.timer/pair.collisionTime;
    // Draw spiral stretch effect when close
    if(t>.7){
      const stretchFactor=Math.pow(t,2)*2;
      pa.tidal={sx:1+stretchFactor*.5,sy:1};pa.tidalAngle=Math.atan2(dy,dx);
      pb.tidal={sx:1+stretchFactor*.5,sy:1};pb.tidalAngle=Math.atan2(-dy,-dx);
    }
    // Collision after timer
    if(pair.timer>=pair.collisionTime||d<pa.radius+pb.radius){
      binaryCollide(pa,pb);
      binaryPairs.splice(i,1);
    }
  }
}

function binaryCollide(pa,pb){
  // Pick bigger as survivor
  const big=pa.mass>=pb.mass?pa:pb,sml=pa.mass<pb.mass?pa:pb;
  big.mass+=sml.mass;
  big.radius=Math.min(Math.cbrt(big.radius**3+sml.radius**3),70);
  // Momentum conserved
  const tm=big.mass+sml.mass;
  big.vx=(big.vx*pa.mass+sml.vx*pb.mass)/tm;
  big.vy=(big.vy*pa.mass+sml.vy*pb.mass)/tm;
  // Surface reaches 4000°C
  big.evoStage='magma';big.evoProgress=0;big.tempOverride=4273;
  big.hasLife=false;big.hadWater=false;
  big.cooldownTimer=3000; // 50 real minutes at 1x (3000s)
  delete TEX[big.id];big.binaryCapture=false;
  // Spawn moons from collision debris
  const nMoons=Math.min(Math.floor((sml.radius/10)+1),5);
  for(let i=0;i<nMoons;i++){
    big.moons.push({angle:Math.random()*Math.PI*2,speed:(0.02+Math.random()*.04)*(Math.random()>.5?1:-1),dist:big.radius*2+i*12+Math.random()*20,radius:2+Math.random()*3});
  }
  flash(big.x,big.y,big.radius*5,'#ff4400',true);
  sndPlanetCollision();
  log(`💥 Binary collision: ${big.name}+${sml.name}! ${nMoons} moons!`,'w');
  ntf(`💥 Worlds collide! ${nMoons} moons formed!`,'w');
  const idx=bodies.findIndex(b=>b.id===sml.id);
  if(idx!==-1){bodies.splice(idx,1);CNT.p--;if(selectedId===sml.id)sel(big.id);}
  updCnt();
}

// ── EVOLUTION SYSTEM ──────────────────────────────────────────
function setEvoStage(p,stage){
  p.evoStage=stage;p.evoProgress=0;
  const ec=EVO[stage];if(!ec)return;
  p.color=ec.base;p.colors=[ec.base,ec.base,darken(ec.base,20)];
  p.atmo=ec.atmo;delete TEX[p.id];
  if(stage==='life'||stage==='advanced'){
    if(!p.hasLife){p.hasLife=true;setTimeout(()=>spawnCivilization(p),500);}
  }
  log(`${p.name}: ${ec.label}`,'n');
}

function advanceEvo(p,dt){
  // Cooldown after collision (4000°C magma phase)
  if(p.cooldownTimer>0){
    p.cooldownTimer-=dt;
    if(p.cooldownTimer<=0){
      p.cooldownTimer=0;delete p.tempOverride;
      // After cooling, become rocky again and restart
      setEvoStage(p,'rocky');p.hasLife=false;p.hadWater=false;
      log(`${p.name} cooled — restarting evolution`,'n');
      delete TEX[p.id];
    }
    return;
  }
  if(!p.evoStage)p.evoStage=p.pt||'rocky';
  const star=bodies.find(b=>b.id===p.orbitStar);if(!star)return;
  const T=p.tempOverride||p.tempK,z=p.zone;
  p.evoProgress=(p.evoProgress||0)+dt*0.00025*simSpd;
  const s=p.evoStage;
  if(s==='lava'&&T<900&&p.evoProgress>.2)setEvoStage(p,'cooling');
  else if(s==='cooling'&&T<700&&p.evoProgress>.35)setEvoStage(p,'rocky');
  else if(s==='rocky'&&(z==='warm'||z==='inner-hab'||z==='habitable')&&p.evoProgress>.4)setEvoStage(p,'arid');
  else if(s==='arid'&&(z==='habitable'||z==='inner-hab')&&(p.hadWater||Math.random()<.0008)&&p.evoProgress>.5)setEvoStage(p,'ocean');
  else if(s==='ocean'&&(z==='habitable'||z==='inner-hab')&&p.evoProgress>.6)setEvoStage(p,'life');
  else if(s==='life'&&(z==='habitable'||z==='inner-hab')&&p.evoProgress>1.2)setEvoStage(p,'advanced');
  // ── Freeze: ocean/life/advanced drift to cold zone ──────────
  else if((s==='ocean'||s==='life'||s==='advanced')&&(z==='cold'||z==='outer-hab')&&T<230&&p.evoProgress>.2){
    p.freezeProgress=(p.freezeProgress||0)+dt*0.0012*simSpd;
    if(p.freezeProgress>.15&&s!=='freezing'){
      setEvoStage(p,'freezing');
      log(p.name+' is freezing over!','w');
      ntf('❄ '+p.name+' — oceans freezing!','w');
    }
    if(p.freezeProgress>=1&&s==='freezing'){
      setEvoStage(p,'frozen');
      p.hasLife=false;p.hadWater=true;
      const civ=civilizations.find(c=>c.planetId===p.id&&!c.extinct);
      if(civ){civ.extinct=true;log(civ.name+' perished — global freeze!','w');ntf('💀 '+civ.name+' extinct — frozen world','w');}
      log(p.name+' fully frozen!','w');ntf('❄ '+p.name+' is now a frozen world','w');
    }
  }
  // Frozen planet warms up — thaw back to ocean
  else if((s==='freezing'||s==='frozen')&&(z==='habitable'||z==='inner-hab'||z==='warm')&&T>260){
    p.freezeProgress=Math.max(0,(p.freezeProgress||0)-dt*0.001*simSpd);
    if(p.freezeProgress<0.05&&s==='freezing'){
      setEvoStage(p,'ocean');
      log(p.name+' thawing — oceans returning!','l');
      ntf('🌊 '+p.name+' is thawing!','lf');
    } else if(s==='frozen'&&p.freezeProgress<0.4){
      setEvoStage(p,'freezing');
      log(p.name+' beginning to thaw','l');
    }
  }
  // Fully frozen + extreme cold zone = eventual rocky (sublimation)
  else if(s==='frozen'&&z==='cold'&&T<100&&p.evoProgress>.8){setEvoStage(p,'rocky');p.hasLife=false;p.freezeProgress=0;}
  else if((s==='rocky'||s==='arid'||s==='ocean')&&z==='hot'&&T>1200&&p.evoProgress>.15)setEvoStage(p,'lava');
  // Gas stripping
  if(p.sub==='gas')checkGasStrip(p);
}

// ── CIVILIZATION SYSTEM ────────────────────────────────────────
function spawnCivilization(planet){
  if(civilizations.find(c=>c.planetId===planet.id&&!c.extinct))return;
  const name=CIV_NAMES[civNameIdx%CIV_NAMES.length]+' Empire';civNameIdx++;
  civilizations.push({id:nextId++,planetId:planet.id,name,
    tech:0,pop:1,ships:[],age:0,stageIdx:0,
    color:CIV_COLORS[Math.floor(Math.random()*CIV_COLORS.length)],
    exploredPlanets:new Set([planet.id]),
    shipBuildTimer:0,lastContact:simTime,extinct:false});
  log(`🧠 Civ: ${name} on ${planet.name}`,'l');
  ntf(`🧠 ${name} emerged!`,'sp');sndCivDiscovery();updCnt();
}

function updateCivs(dt){
  for(const civ of civilizations){
    if(civ.extinct)continue;
    const planet=bodies.find(b=>b.id===civ.planetId);
    if(!planet||!planet.hasLife){civ.extinct=true;log(`${civ.name} extinct`,'w');updCnt();continue;}
    civ.age+=dt;
    civ.tech=Math.min(100,civ.tech+dt*(0.001+civ.tech*.0003)*simSpd);
    civ.pop=Math.min(1000,civ.pop+dt*civ.pop*.0004*simSpd*(civ.tech*.01+0.1));
    const ns=Math.min(CIV_STAGES.length-1,Math.floor(civ.tech/13));
    if(ns>civ.stageIdx){civ.stageIdx=ns;log(`${civ.name}: ${CIV_STAGES[ns]}!`,'l');ntf(`🧠 ${civ.name} → ${CIV_STAGES[ns]}!`,'sp');}
    if(civ.stageIdx>=5&&ships.filter(s=>s.civId===civ.id).length<Math.floor(civ.tech/15+3)){
      civ.shipBuildTimer=(civ.shipBuildTimer||0)+dt;
      if(civ.shipBuildTimer>6/simSpd){civ.shipBuildTimer=0;launchShip(civ,planet);}
    }
  }
}

function launchShip(civ,fromPlanet){
  const candidates=bodies.filter(b=>b.type==='planet'&&b.id!==fromPlanet.id&&!civ.exploredPlanets.has(b.id));
  if(candidates.length===0)return;
  const target=candidates.reduce((a,b)=>Math.hypot(b.x-fromPlanet.x,b.y-fromPlanet.y)<Math.hypot(a.x-fromPlanet.x,a.y-fromPlanet.y)?b:a);
  const types=['Scout','Explorer','Colony','Trade','Warship'];
  const type=types[Math.min(Math.floor(civ.tech/20),types.length-1)];
  ships.push({id:nextId++,civId:civ.id,fromId:fromPlanet.id,toId:target.id,
    x:fromPlanet.x,y:fromPlanet.y,tx:target.x,ty:target.y,
    speed:0.6+civ.tech*.025,type,state:'traveling',trail:[],age:0,color:civ.color,
    name:civ.name.split(' ')[0]+'-'+type[0]+nextId});
  civ.exploredPlanets.add(target.id);
  log(`🚀 ${ships[ships.length-1].name} launched`,'n');
}

function updateShips(dt){
  for(let i=ships.length-1;i>=0;i--){
    const ship=ships[i];const target=bodies.find(b=>b.id===ship.toId);
    if(!target){ships.splice(i,1);continue;}
    ship.tx=target.x;ship.ty=target.y;
    const dx=ship.tx-ship.x,dy=ship.ty-ship.y,d=Math.hypot(dx,dy);
    ship.age+=dt;
    ship.trail.push({x:ship.x,y:ship.y,age:0});
    if(ship.trail.length>25)ship.trail.shift();
    for(const t of ship.trail)t.age+=dt;
    if(d<6){
      const civ=civilizations.find(c=>c.id===ship.civId);
      if(civ){civ.tech=Math.min(100,civ.tech+1);
        if(target.hasLife){const oc=civilizations.find(c=>c.planetId===target.id&&!c.extinct);
          if(oc&&oc.id!==civ.id){civ.tech=Math.min(100,civ.tech+5);oc.tech=Math.min(100,oc.tech+5);
            log(`🤝 First Contact: ${civ.name} & ${oc.name}!`,'l');ntf(`🤝 First Contact!`,'sp');}}}
      ships.splice(i,1);
    } else {
      const spd=ship.speed*dt*60*(simSpd*.15+0.08);
      ship.x+=dx/d*spd;ship.y+=dy/d*spd;
    }
  }
}

// ── SOLAR EVENTS ──────────────────────────────────────────────
function solarFlare(){
  const stars=bodies.filter(b=>b.type==='star');
  if(stars.length===0){ntf('No star for flare!','w');return;}
  const star=selectedId?bodies.find(b=>b.id===selectedId&&b.type==='star')||stars[0]:stars[0];
  const numArcs=8+Math.floor(Math.random()*6);
  for(let i=0;i<numArcs;i++){
    solarEvents.push({type:'flare',starId:star.id,angle:(i/numArcs)*Math.PI*2+(Math.random()-.5)*.3,
      length:star.radius*(2+Math.random()*4),width:star.radius*(.2+Math.random()*.3),
      age:0,maxAge:2+Math.random()*2,color:star.color,speed:Math.random()*.5});
  }
  // Affect planets
  for(const p of bodies.filter(b=>b.type==='planet')){
    const d=Math.hypot(p.x-star.x,p.y-star.y);
    if(d<400&&p.hasLife){p.hasLife=Math.random()>.3;if(!p.hasLife)log(`Solar flare devastates ${p.name}!`,'w');}
  }
  ntf(`☀️ Solar Flare erupted!`,'w');log('Solar flare!','w');sndSolarFlare();
}
function solarRadiation(){
  const stars=bodies.filter(b=>b.type==='star');if(stars.length===0)return;
  const star=selectedId?bodies.find(b=>b.id===selectedId&&b.type==='star')||stars[0]:stars[0];
  // 10,000 AU at ~100 world units/AU = 1,000,000 world units
  // Travel at ~2500 world units/second, so maxAge = 400 seconds
  solarEvents.push({type:'radiation',starId:star.id,age:0,maxAge:400,radius:0,maxRadius:1000000,speed:2500});
  ntf('⚡ Radiation burst launched! (10,000 AU range)','w');
  log('Solar radiation burst — 10k AU range!','w');
  if(typeof sndSolarFlare==='function')sndSolarFlare();
}

// ── MAGNETIC FIELDS ────────────────────────────────────────────
function addMagField(){
  const b=bodies.find(b=>b.id===selectedId);if(!b)return;
  b.magField={strength:0.5,radius:b.radius*2.5};
  ntf(`🧲 Mag field added to ${b.name}`);
}

// ── COLLISIONS ────────────────────────────────────────────────
function chkCollisions(){
  const planets=bodies.filter(b=>b.type==='planet');
  const asteroids=bodies.filter(b=>b.type==='asteroid');
  const stars=bodies.filter(b=>b.type==='star');
  const holes=bodies.filter(b=>b.type==='hole'&&b.sub==='black'&&!b.repulse);
  const rm=new Set();

  // Moon-moon collisions
  for(const pl of planets){
    for(let i=0;i<pl.moons.length;i++){
      for(let j=i+1;j<pl.moons.length;j++){
        const a=pl.moons[i],b=pl.moons[j];
        const dA=Math.abs(a.dist-b.dist),dAng=Math.abs(a.angle-b.angle)%(Math.PI*2);
        const minAng=Math.min(dAng,Math.PI*2-dAng);
        if(dA<(a.radius+b.radius)*1.5&&minAng<0.15){
          // Merge moons
          a.radius=Math.cbrt(a.radius**3+b.radius**3);
          a.dist=(a.dist+b.dist)/2;
          pl.moons.splice(j,1);j--;
          flash(pl.x+Math.cos(a.angle)*a.dist*camSc,pl.y,'#ccbbaa');
        }
      }
    }
  }

  // Asteroid-asteroid collisions (sample for performance)
  if(asteroids.length<300){
    for(let i=0;i<asteroids.length;i++){
      for(let j=i+1;j<asteroids.length;j++){
        if(rm.has(asteroids[i].id)||rm.has(asteroids[j].id))continue;
        const a=asteroids[i],b=asteroids[j];
        if(Math.hypot(a.x-b.x,a.y-b.y)<a.radius+b.radius){
          const big=a.mass>=b.mass?a:b,sml=a.mass<b.mass?a:b;
          big.mass+=sml.mass*.5;big.radius=Math.cbrt(big.radius**3+sml.radius**3*.3);
          const tm=big.mass+sml.mass;big.vx=(big.vx*a.mass+sml.vx*b.mass)/tm;big.vy=(big.vy*a.mass+sml.vy*b.mass)/tm;
          rm.add(sml.id);
        }
      }
    }
  }

  // Planet-planet collisions (not binary — those are separate)
  for(let i=0;i<planets.length;i++){if(rm.has(planets[i].id))continue;
    for(let j=i+1;j<planets.length;j++){if(rm.has(planets[j].id))continue;
      const a=planets[i],b=planets[j];
      if(binaryPairs.find(p=>(p.aId===a.id&&p.bId===b.id)||(p.aId===b.id&&p.bId===a.id)))continue;
      if(Math.hypot(a.x-b.x,a.y-b.y)<(a.radius+b.radius)*.85){
        const big=a.mass>=b.mass?a:b,sml=a.mass<b.mass?a:b;
        big.mass+=sml.mass*.7;big.radius=Math.min(Math.cbrt(big.radius**3+sml.radius**3),70);
        const tm=big.mass+sml.mass;big.vx=(big.vx*a.mass+sml.vx*b.mass)/tm;big.vy=(big.vy*a.mass+sml.vy*b.mass)/tm;
        if(sml.hasLife||big.hasLife)big.hasLife=true;
        // Magma phase + cooldown
        big.evoStage='magma';big.tempOverride=4273;big.cooldownTimer=3000;big.evoProgress=0;big.hasLife=false;
        for(const m of sml.moons)if(big.moons.length<50){m.dist+=big.radius*1.5;big.moons.push(m);}
        flash(big.x,big.y,big.radius*4,'#ff4400',true);sndPlanetCollision();log(`${big.name} absorbed ${sml.name}!`,'w');
        delete TEX[big.id];big.binaryCapture=false;
        rm.add(sml.id);if(selectedId===sml.id)sel(big.id);
      }
    }
  }

  // Asteroid-planet
  for(const ast of asteroids){if(rm.has(ast.id))continue;
    for(const pl of planets){if(rm.has(pl.id))continue;
      if(Math.hypot(ast.x-pl.x,ast.y-pl.y)<pl.radius+ast.radius){
        if(ast.isWater){
          pl.hadWater=true;
          const star=bodies.find(s=>s.id===pl.orbitStar);
          if(star&&pl.sub==='rocky'){
            const d=Math.hypot(pl.x-star.x,pl.y-star.y);const z=getZone(d,star.def||star);
            if((z==='habitable'||z==='inner-hab')&&!pl.hasLife){
              if(pl.evoStage==='arid'||pl.evoStage==='rocky'){
                setEvoStage(pl,'ocean');
                // Trigger water flood animation
                waterFloodAnims.push({planetId:pl.id,progress:0,maxProgress:1,age:0});
                ntf(`💧 Water floods ${pl.name}!`,'lf');sndWaterImpact();
              }
            }
          }
        }
        flash(pl.x,pl.y,pl.radius*1.5,'#aabbff');rm.add(ast.id);break;
      }
    }
  }

  // Star incinerates
  for(const star of stars){
    for(const p of [...planets,...asteroids]){if(rm.has(p.id))continue;
      const d=Math.hypot(p.x-star.x,p.y-star.y);
      const consumeD=p.type==='planet'?star.radius+p.radius:star.radius+p.radius;
      if(d<consumeD){flash(star.x,star.y,star.radius*1.5,'#ffff88');log(`${p.name} incinerated!`,'w');
        if(p.type==='planet')CNT.p--;else CNT.a--;rm.add(p.id);if(selectedId===p.id)sel(null);}
    }
  }

  // Black hole consumes
  for(const bh of holes){
    for(const p of [...planets,...asteroids]){if(rm.has(p.id))continue;
      if(Math.hypot(p.x-bh.x,p.y-bh.y)<bh.radius+p.radius){
        flash(bh.x,bh.y,bh.radius*1.5,'#cc44ff');log(`${p.name} consumed by ${bh.name}!`,'w');
        if(p.type==='planet'){CNT.p--;civilizations.filter(c=>c.planetId===p.id).forEach(c=>c.extinct=true);}
        else CNT.a--;rm.add(p.id);if(selectedId===p.id)sel(null);
      }
    }
    // Belt particles consumed
    for(const belt of bodies.filter(b=>b.type==='belt')){
      const d=Math.hypot(bh.x-belt.x,bh.y-belt.y);
      if(d<belt.radius+bh.radius*3){
        belt.particles=belt.particles.filter((_,idx)=>Math.random()>.05);
        if(belt.particles.length<5)rm.add(belt.id);
      }
    }
  }

  if(rm.size>0){
    for(const id of rm){const idx=bodies.findIndex(b=>b.id===id);if(idx!==-1){const b=bodies[idx];if(b.type==='belt')CNT.b--;bodies.splice(idx,1);}}
    updCnt();
  }
}

// ── PHYSICS ──────────────────────────────────────────────────
function accel(body,sources,G){
  let ax=0,ay=0;
  for(const s of sources){
    if(s.id===body.id)continue;
    const dx=s.x-body.x,dy=s.y-body.y,d2=dx*dx+dy*dy;
    const d=Math.sqrt(d2);const soft=Math.max(d,s.radius*0.5);
    const a=G*s.mass/(soft*soft);ax+=a*dx/d;ay+=a*dy/d;
    // Roche tidal shear near black holes
    if(s.type==='hole'&&s.sub==='black'&&d<s.radius*14){
      const ts=G*s.mass*(body.radius||8)*2/((d2+0.01)*d)*0.06;
      ax-=ts*(dy/d);ay+=ts*(dx/d);
    }
  }
  return{ax,ay};
}

function _physStep(dt){
  const G=0.0002*gravMult;
  const massive=bodies.filter(b=>b.type==='star'||b.type==='hole');
  const ss=bodies.filter(b=>b.type==='star');

  // Multi-star rotation
  if(ss.length>=2&&ss.length<=4){
    const cx=ss.reduce((s,b)=>s+b.x,0)/ss.length,cy=ss.reduce((s,b)=>s+b.y,0)/ss.length;
    for(const s of ss){if(!s._multi)continue;s._oA+=s._oSpd*dt*60;s.x=cx+Math.cos(s._oA)*s._oR;s.y=cy+Math.sin(s._oA)*s._oR;}
  }

  // Star aging + supernova checks
  for(const s of ss){
    s.age+=dt;
    updateSupernovaAnimation(s,dt);
    if(!s.supernovaTriggered&&!s._becomesBH&&!s._collapsing)checkSupernovaConditions(s,dt);
  }

  // Black hole just formed — dramatic infall animation
  for(const h of bodies.filter(b=>b.type==='hole'&&b.justFormed)){
    h.formAge=(h.formAge||0)+dt;
    if(h.formAge>3)h.justFormed=false;
  }

  // Locked planets — analytic orbit
  for(const p of bodies.filter(b=>b.type==='planet'&&b.lockedOrbit)){
    const oS=bodies.find(b=>b.id===p.orbitStar);if(!oS)continue;
    p.orbitAngle+=p.orbitSpd*dt*60;
    const a=p.orbitA||p.orbitRadius,b2=p.orbitB||p.orbitRadius;
    p.x=oS.x+Math.cos(p.orbitAngle)*a;p.y=oS.y+Math.sin(p.orbitAngle)*b2;
    p.vx=-Math.sin(p.orbitAngle)*p.orbitSpd*a*60;p.vy=Math.cos(p.orbitAngle)*p.orbitSpd*b2*60;
    for(const m of p.moons)m.angle+=m.speed*dt*60;
    calcTidalStretch(p);
    if(p.spinSpeed)p.spinAngle=(p.spinAngle||0)+p.spinSpeed*dt*0.5;
  }

  // Free planets — leapfrog
  if(gravSim){
    const free=bodies.filter(b=>b.type==='planet'&&!b.lockedOrbit);
    for(const p of free){const{ax,ay}=accel(p,massive,G);p.vx+=ax*dt*60*.5;p.vy+=ay*dt*60*.5;}
    for(const p of free){p.x+=p.vx*dt;p.y+=p.vy*dt;}
    for(const p of free){const{ax,ay}=accel(p,massive,G);p.vx+=ax*dt*60*.5;p.vy+=ay*dt*60*.5;
      for(const m of p.moons)m.angle+=m.speed*dt*60;calcTidalStretch(p);}

    // Asteroids
    const asts=bodies.filter(b=>b.type==='asteroid');
    for(let i=0;i<asts.length;i++){
      if(asts.length>300&&i%4!==0)continue;
      const p=asts[i];const{ax,ay}=accel(p,massive,G);
      p.vx+=ax*dt*60;p.vy+=ay*dt*60;p.x+=p.vx*dt;p.y+=p.vy*dt;
      p.angle+=p.rotSpd*dt*60;p.age+=dt;
      calcTidalStretch(p);
    }
  }
}

function updatePhysics(dt){
  const steps=simSpd>10?3:simSpd>5?2:1;
  for(let i=0;i<steps;i++)_physStep(dt/steps);

  for(const p of bodies.filter(b=>b.type==='planet')){
    p.cloudAngle=(p.cloudAngle||0)+.0008*dt;p.age+=dt;
    p.tempK=p.tempOverride||getPlanetTemp(p);
    advanceEvo(p,dt);
    const star=bodies.find(b=>b.id===p.orbitStar);
    if(star)p.zone=getZone(Math.hypot(p.x-star.x,p.y-star.y),star.def||star);
  }
  for(const s of bodies.filter(b=>b.type==='star'))s.angle+=.008*dt;
  for(const h of bodies.filter(b=>b.type==='hole')){h.age+=dt;h.angle+=.016*dt;for(const ap of h.accretionParticles)ap.a+=ap.speed*dt*60;}
  for(const belt of bodies.filter(b=>b.type==='belt')){for(const p of belt.particles)p.angle+=p.speed*dt*60;belt.age+=dt;}

  // Nebula star formation
  for(const nb of nebulae){nb.age+=dt;
    if(nb.starFormRate&&Math.random()<nb.starFormRate*dt*simSpd&&CNT.s<60){
      const a=Math.random()*Math.PI*2,d=Math.random()*nb.radius*.4;
      mkGalStar(nb.x+Math.cos(a)*d,nb.y+Math.sin(a)*d,'star-red-dwarf',null,0.5);
      log(`⭐ Star born from nebula!`,'l');ntf(`⭐ Star formation!`,'l');updCnt();
    }
    for(const pt of nb.particles){pt.x+=pt.vx*dt*25;pt.y+=pt.vy*dt*25;}
  }

  // Solar events
  for(let i=solarEvents.length-1;i>=0;i--){
    const ev=solarEvents[i];ev.age+=dt;
    if(ev.type==='radiation'){
      // Expand at constant speed
      ev.radius=Math.min(ev.maxRadius,(ev.speed||2500)*ev.age);
      // Ring gets thicker as it travels (inverse square expansion)
      ev.ringWidth=Math.max(2, ev.radius * 0.04);
    }
    if(ev.type==='pulse') ev.radius=Math.min(ev.maxRadius,(ev.speed||200)*ev.age);
    if(ev.age>=ev.maxAge)solarEvents.splice(i,1);
  }

  // Water flood animations
  for(let i=waterFloodAnims.length-1;i>=0;i--){
    const wf=waterFloodAnims[i];wf.age+=dt;wf.progress=Math.min(1,wf.age/8);
    const pl=bodies.find(b=>b.id===wf.planetId);if(pl)pl.waterFloodProgress=wf.progress;
    if(wf.progress>=1)waterFloodAnims.splice(i,1);
  }

  checkBinaryPlanets();
  updateCivs(dt);updateShips(dt);
  simTime+=dt*simSpd*.01;
  chkCollisions();
  cFlashes=cFlashes.filter(f=>{f.age+=dt;return f.age<f.maxAge;});
}

// ── TEXTURE BAKING ────────────────────────────────────────────
function getTex(p,size){
  const k=p.id,stage=p.evoStage||p.pt;
  if(!TEX[k]||TEX[k].stage!==stage||TEX[k].size!==size)TEX[k]={canvas:bakeTexture(p,size),stage,size};
  return TEX[k].canvas;
}
function bakeTexture(planet,sz){
  const oc=document.createElement('canvas');oc.width=sz;oc.height=sz;
  const pc=oc.getContext('2d');
  const s=planet.evoStage||planet.pt||'rocky';
  const seed=planet.id*13+7;
  const img=pc.createImageData(sz,sz);const d=img.data;
  const ca=planet.cloudAngle||0;

  for(let py=0;py<sz;py++){
    for(let px=0;px<sz;px++){
      const nx=px/sz*2-1,ny=py/sz*2-1,r2=nx*nx+ny*ny;
      if(r2>1){d[(py*sz+px)*4+3]=0;continue;}
      const nz=Math.sqrt(1-r2);
      // Spherical UV with rotation offset for clouds
      const lon=(Math.atan2(nx,nz)*3+ca*.08)%(Math.PI*2);
      const lat=Math.asin(Math.max(-1,Math.min(1,ny)));
      const u=lon,v=lat;
      const absLat=Math.abs(lat)/Math.PI*2; // 0=equator 1=pole

      let R=0,G=0,B=0;

      // ── LAVA / MAGMA ────────────────────────────────────────
      if(s==='lava'||s==='magma'){
        // Cracked dark crust over glowing lava
        const crack=ridged(u*2.5,v*2.5,seed,5);
        const warp=wfbm(u*1.8,v*1.8,seed+11,4,1.5);
        const heat=fbm(u*3,v*3,seed+22,4);
        // Crust vs exposed lava
        const isCrust=crack>0.38;
        if(isCrust){
          // Dark basalt crust with orange glow along cracks
          const crackProx=Math.pow(1-Math.min(crack,0.85)/.85,3);
          R=Math.floor(18+heat*25+crackProx*200);
          G=Math.floor(5+heat*12+crackProx*60);
          B=Math.floor(2+heat*5);
        } else {
          // Molten lava: yellows -> orange -> bright white-hot
          const t=Math.pow(1-crack/0.38,1.5)*(0.4+warp*0.6);
          R=Math.min(255,Math.floor(180+t*75));
          G=Math.min(255,Math.floor(40+t*160));
          B=Math.floor(t*80);
        }
      }

      // ── COOLING ─────────────────────────────────────────────
      else if(s==='cooling'){
        const w1=wfbm(u*2,v*2,seed,4,1.0);
        const r2b=ridged(u*3,v*3,seed+5,4);
        // Dark grey/black with some still-warm orange veins
        const isHot=r2b<0.3&&w1>0.5;
        R=isHot?Math.floor(80+w1*120):Math.floor(22+w1*28);
        G=isHot?Math.floor(20+w1*35):Math.floor(18+w1*22);
        B=isHot?5:Math.floor(12+w1*18);
      }

      // ── ROCKY ───────────────────────────────────────────────
      else if(s==='rocky'){
        const height=wfbm(u*2.2,v*2.2,seed,5,0.9);
        const detail=fbm(u*5,v*5,seed+8,3);
        const craterV=vor(u*4+seed*.01,v*4+seed*.01,seed+3);
        // Crater rim highlight vs floor
        const isCraterRim=craterV.edge<0.08;
        const isCraterFloor=craterV.f1<0.12;
        // Base colour — warm grey-brown geology
        const h2=height*0.7+detail*0.3;
        R=Math.floor(90+h2*85+detail*20+(isCraterRim?30:0));
        G=Math.floor(72+h2*68+detail*15+(isCraterRim?20:0));
        B=Math.floor(52+h2*48+detail*10+(isCraterFloor?-8:0));
        // Subtle iron-oxide reddish patches
        const oxide=fbm(u*1.5,v*1.5,seed+99,3);
        if(oxide>0.62){R=Math.min(255,R+Math.floor((oxide-0.62)*3*60));G=Math.max(0,G-5);}
      }

      // ── ARID / DESERT ───────────────────────────────────────
      else if(s==='arid'||s==='desert'){
        const dunes=ridged(u*3+wfbm(u,v,seed,2,0.5)*0.4,v*3,seed,4);
        const sand=fbm(u*6,v*6,seed+3,3);
        const rock=fbm(u*2,v*2,seed+77,4);
        // Sandy tan with dune shadows
        R=Math.floor(160+dunes*55+sand*18);
        G=Math.floor(118+dunes*40+sand*12);
        B=Math.floor(48+dunes*18+sand*6);
        // Rocky outcrops at high elevation
        if(rock>0.65){
          const t=(rock-0.65)*2.8;
          R=Math.floor(R*(1-t*0.4)+120*t);
          G=Math.floor(G*(1-t*0.4)+100*t);
          B=Math.floor(B*(1-t*0.3)+80*t);
        }
        // Polar dust haze
        if(absLat>0.75){const p=(absLat-0.75)*4;R=Math.floor(R*(1-p)+200*p);G=Math.floor(G*(1-p)+185*p);B=Math.floor(B*(1-p)+160*p);}
      }

      // ── ICE ─────────────────────────────────────────────────
      else if(s==='ice'){
        const glacier=wfbm(u*2.5,v*2.5,seed,5,1.0);
        const crack2=ridged(u*4,v*4,seed+5,5);
        const depth=fbm(u*8,v*8,seed+33,3);
        // Crevasse cracks vs ice surface
        const isCrevasse=crack2<0.35;
        if(isCrevasse){
          // Deep blue in crevasses
          R=Math.floor(8+depth*30);
          G=Math.floor(30+depth*60);
          B=Math.floor(90+depth*90);
        } else {
          // Bright white ice with blue-tinted shadows
          const iceBright=glacier*0.6+crack2*0.4;
          R=Math.floor(160+iceBright*85);
          G=Math.floor(180+iceBright*70);
          B=Math.floor(210+iceBright*45);
        }
        // Ice-free rocky patches at mid-lat
        const bare=fbm(u*1.8,v*1.8,seed+111,3);
        if(absLat<0.4&&bare>0.68){
          const t=(bare-0.68)*3;
          R=Math.floor(R*(1-t)+95*t);G=Math.floor(G*(1-t)+85*t);B=Math.floor(B*(1-t)+72*t);
        }
      }

      // ── OCEAN ───────────────────────────────────────────────
      else if(s==='ocean'){
        const cont=wfbm(u*1.5,v*1.5,seed,5,1.3); // continent mask
        const isLand=cont>0.52;
        const shallowMask=cont>0.46&&cont<=0.52;
        const depth2=fbm(u*3,v*3,seed+7,4);
        const detail=fbm(u*8,v*8,seed+13,2);
        if(isLand){
          // Terrain: highlands vs lowlands
          const hill=ridged(u*4,v*4,seed+2,4);
          R=Math.floor(70+cont*90+hill*30);
          G=Math.floor(55+cont*70+hill*25);
          B=Math.floor(30+cont*45+hill*15);
          // Snowy mountains
          if(hill>0.72){const t=(hill-0.72)*3.5;R=Math.floor(R*(1-t)+230*t);G=Math.floor(G*(1-t)+230*t);B=Math.floor(B*(1-t)+240*t);}
        } else if(shallowMask){
          // Shallow coastal water — turquoise
          R=Math.floor(15+depth2*40);G=Math.floor(100+depth2*60);B=Math.floor(140+depth2*60);
        } else {
          // Deep ocean with depth variation
          R=Math.floor(5+depth2*18+detail*8);
          G=Math.floor(18+depth2*45+detail*15);
          B=Math.floor(65+depth2*90+detail*25);
        }
        // Polar ice caps
        if(absLat>0.72){const t=Math.min(1,(absLat-0.72)*5);R=Math.floor(R*(1-t)+230*t);G=Math.floor(G*(1-t)+235*t);B=Math.floor(B*(1-t)+250*t);}
        // Water flood blend
        const fl=planet.waterFloodProgress||0;
        if(fl>0&&isLand){R=Math.floor(R*(1-fl*0.5)+10*fl*0.5);G=Math.floor(G*(1-fl*0.5)+70*fl*0.5);B=Math.floor(B*(1-fl*0.5)+160*fl*0.5);}
      }

      // ── FREEZING ────────────────────────────────────────────
      else if(s==='freezing'){
        const cont=wfbm(u*1.5,v*1.5,seed,5,1.3);
        const isLand=cont>0.50;
        const iceSheet=wfbm(u*2.2,v*2.2,seed+88,4,0.8);
        const fp=Math.min(1,planet.freezeProgress||0.3);
        const poleIce=absLat>(0.85-fp*0.75);
        const equatorIce=iceSheet>(1.0-fp*0.8);
        const isIce=poleIce||equatorIce;
        const crack2=ridged(u*5,v*5,seed+5,4);
        if(isIce){
          const iceBright=iceSheet*0.5+crack2*0.5;
          R=Math.floor(155+iceBright*80);G=Math.floor(175+iceBright*65);B=Math.floor(210+iceBright*42);
          if(crack2<0.32){R=Math.floor(20+crack2*80);G=Math.floor(50+crack2*100);B=Math.floor(130+crack2*80);}
        } else if(isLand){
          R=Math.floor(90+iceSheet*60);G=Math.floor(100+iceSheet*55);B=Math.floor(110+iceSheet*60);
        } else {
          const iceFrag=fbm(u*6,v*6,seed+11,3);
          R=Math.floor(8+iceFrag*40);G=Math.floor(25+iceFrag*60);B=Math.floor(80+iceFrag*80);
          if(iceFrag>0.62){const t2=(iceFrag-0.62)*3;R=Math.floor(R+t2*160);G=Math.floor(G+t2*150);B=Math.floor(B+t2*120);}
        }
      }
      // ── FROZEN ───────────────────────────────────────────────
      else if(s==='frozen'){
        const glacier=wfbm(u*2.5,v*2.5,seed,5,1.0);
        const crack2=ridged(u*4.5,v*4.5,seed+5,5);
        const depth=fbm(u*8,v*8,seed+33,3);
        const subsurface=fbm(u*1.8,v*1.8,seed+77,3);
        if(crack2<0.28){
          R=Math.floor(5+depth*25);G=Math.floor(35+depth*70+subsurface*20);B=Math.floor(90+depth*100);
        } else {
          const iceBright=glacier*0.55+crack2*0.45;
          R=Math.floor(145+iceBright*100);G=Math.floor(170+iceBright*78);B=Math.floor(210+iceBright*45);
          if(crack2>0.55&&crack2<0.62){R=Math.max(0,R-20);G=Math.max(0,G-10);B=Math.min(255,B+15);}
        }
      }
      // ── LIFE ────────────────────────────────────────────────
      else if(s==='life'){
        const cont=wfbm(u*1.5,v*1.5,seed,5,1.3);
        const isLand=cont>0.50;
        const isShallow=cont>0.44&&cont<=0.50;
        const biome=fbm(u*2,v*2,seed+44,4); // biome variation
        const detail=fbm(u*7,v*7,seed+88,3);
        if(isLand){
          const hill=ridged(u*3.5,v*3.5,seed+2,4);
          // Biome: tropical green, temperate, tundra, desert patch
          if(absLat<0.25){
            // Tropical jungle — deep green
            R=Math.floor(18+biome*25+detail*15);G=Math.floor(75+biome*60+detail*25);B=Math.floor(12+biome*18);
          } else if(absLat<0.55){
            // Temperate — varied green/brown
            R=Math.floor(35+biome*55+detail*20);G=Math.floor(70+biome*55+detail*30);B=Math.floor(20+biome*25);
          } else if(absLat<0.72){
            // Taiga / tundra — grey-green
            R=Math.floor(55+biome*40);G=Math.floor(68+biome*45);B=Math.floor(45+biome*35);
          } else {
            // Polar — white
            const p=(absLat-0.72)*3.5;R=Math.floor(160+p*90);G=Math.floor(170+p*80);B=Math.floor(185+p*70);
          }
          // Mountain snow overlay
          if(hill>0.70){const t=(hill-0.70)*3.3;R=Math.floor(R*(1-t)+230*t);G=Math.floor(G*(1-t)+232*t);B=Math.floor(B*(1-t)+248*t);}
          // Desert patches mid-lat
          const dry=fbm(u*1.2,v*1.2,seed+222,3);
          if(absLat>0.2&&absLat<0.45&&dry>0.65){const t=(dry-0.65)*2.5;R=Math.floor(R*(1-t)+165*t);G=Math.floor(G*(1-t)+128*t);B=Math.floor(B*(1-t)+68*t);}
        } else if(isShallow){
          R=Math.floor(10+biome*30);G=Math.floor(90+biome*50);B=Math.floor(130+biome*55);
        } else {
          R=Math.floor(4+biome*15);G=Math.floor(20+biome*50);B=Math.floor(75+biome*100);
          if(absLat>0.72){const t=Math.min(1,(absLat-0.72)*5);R=Math.floor(R*(1-t)+225*t);G=Math.floor(G*(1-t)+232*t);B=Math.floor(B*(1-t)+248*t);}
        }
      }

      // ── ADVANCED ────────────────────────────────────────────
      else if(s==='advanced'){
        // Earth-like base + city-light grids on night side
        const cont=wfbm(u*1.5,v*1.5,seed,5,1.3);
        const isLand=cont>0.50;
        const biome=fbm(u*2,v*2,seed+44,4);
        const detail=fbm(u*7,v*7,seed+88,3);
        const cityGrid=Math.max(
          Math.abs(Math.sin(u*18+seed*.03)),
          Math.abs(Math.sin(v*18+seed*.07))
        );
        if(isLand){
          if(absLat<0.55){R=Math.floor(28+biome*50+detail*15);G=Math.floor(60+biome*55+detail*22);B=Math.floor(18+biome*22);}
          else if(absLat<0.72){R=Math.floor(50+biome*40);G=Math.floor(65+biome*42);B=Math.floor(42+biome*32);}
          else{R=Math.floor(180+biome*60);G=Math.floor(185+biome*55);B=Math.floor(210+biome*45);}
          // City grids — warm yellow light
          if(nz<0.2&&cityGrid>0.88&&biome>0.3){R=Math.min(255,R+100);G=Math.min(255,G+80);B=Math.min(255,B+20);}
        } else {
          R=Math.floor(4+biome*15);G=Math.floor(18+biome*48);B=Math.floor(72+biome*95);
          if(absLat>0.72){const t=Math.min(1,(absLat-0.72)*5);R=Math.floor(R*(1-t)+225*t);G=Math.floor(G*(1-t)+230*t);B=Math.floor(B*(1-t)+248*t);}
        }
      }

      // ── GAS GIANT ───────────────────────────────────────────
      else if(s==='gas'){
        // Each gas giant has its own colour palette based on seed
        const palIdx=seed%5;
        // Domain-warped bands for the Great Red Spot style storms
        const warp2=wfbm(u*1.2,v*4,seed,5,0.7);
        const band=Math.sin(v*10+warp2*3+seed*.02)*0.5+0.5; // main latitudinal bands
        const storm=vor(u*3+seed*.02,v*3,seed+11);
        const detail=turb(u*4,v*4,seed+55,3);
        // Palette 0: Jupiter-like (cream/brown/orange)
        if(palIdx===0){
          const b2=band*0.6+detail*0.4;
          R=Math.floor(180+b2*60);G=Math.floor(130+b2*45-band*30);B=Math.floor(60+b2*25);
          // Storm oval
          if(storm.f1<0.18){const t=1-storm.f1/0.18;R=Math.min(255,Math.floor(R+t*40));G=Math.floor(G-t*20);B=Math.floor(B-t*10);}
        }
        // Palette 1: Saturn-like (golden)
        else if(palIdx===1){
          R=Math.floor(190+band*50+detail*15);G=Math.floor(155+band*40+detail*12);B=Math.floor(60+band*20);
          if(storm.f1<0.15){const t=1-storm.f1/0.15;R=Math.min(255,Math.floor(R+t*30));G=Math.floor(G+t*10);}
        }
        // Palette 2: Neptune-like (deep blue)
        else if(palIdx===2){
          const b2=band*0.5+warp2*0.5;
          R=Math.floor(15+b2*30);G=Math.floor(40+b2*80);B=Math.floor(140+b2*90);
          if(storm.f1<0.2){const t=1-storm.f1/0.2;R=Math.min(255,Math.floor(R+t*60));G=Math.min(255,Math.floor(G+t*40));}
        }
        // Palette 3: Uranus-like (pale cyan)
        else if(palIdx===3){
          R=Math.floor(60+band*40+detail*20);G=Math.floor(160+band*50+detail*25);B=Math.floor(170+band*50+detail*20);
        }
        // Palette 4: Hot Jupiter (magenta/purple)
        else{
          const b2=band*0.6+detail*0.4;
          R=Math.floor(120+b2*100);G=Math.floor(40+b2*40);B=Math.floor(100+b2*80);
          if(storm.f1<0.15){const t=1-storm.f1/0.15;R=Math.min(255,Math.floor(R+t*50));G=Math.min(255,Math.floor(G+t*30));}
        }
      }

      // ── FALLBACK ─────────────────────────────────────────────
      else{
        const n1=fbm(u*2,v*2,seed,4);R=Math.floor(95+n1*58);G=Math.floor(78+n1*48);B=Math.floor(65+n1*38);
      }

      // ── LIGHTING ─────────────────────────────────────────────
      // Multi-component lighting: diffuse + rim light + specular
      const lightX=0.45,lightY=-0.25,lightZ=0.85;
      const llen=Math.sqrt(lightX*lightX+lightY*lightY+lightZ*lightZ);
      const lx2=lightX/llen,ly2=lightY/llen,lz2=lightZ/llen;
      const diffuse=Math.max(0,nx*lx2+ny*ly2+nz*lz2);
      // Ambient + diffuse
      const ambient=0.12;
      const light=ambient+diffuse*(1-ambient);
      // Subtle Fresnel rim (limb darkening)
      const rimDark=Math.pow(nz,0.4)*0.85+0.15;
      const finalLight=light*rimDark;

      const idx=(py*sz+px)*4;
      d[idx]  =Math.min(255,Math.floor(R*finalLight));
      d[idx+1]=Math.min(255,Math.floor(G*finalLight));
      d[idx+2]=Math.min(255,Math.floor(B*finalLight));
      d[idx+3]=255;
    }
  }
  pc.putImageData(img,0,0);

  // ── Cloud layer ──────────────────────────────────────────────
  if(s==='life'||s==='advanced'||s==='ocean'){
    for(let cy2=0;cy2<sz;cy2+=2){
      for(let cx2=0;cx2<sz;cx2+=2){
        const cnx=cx2/sz*2-1,cny=cy2/sz*2-1;
        if(cnx*cnx+cny*cny>1)continue;
        const cl=wfbm(cx2/sz*3.2+ca*.10,cy2/sz*3.2,seed+555,4,0.8);
        if(cl>.58){
          const ca2=Math.min(1,(cl-.58)*2.5)*.82;
          pc.fillStyle=`rgba(255,255,255,${ca2})`;
          pc.fillRect(cx2,cy2,2,2);
        }
      }
    }
  }
  // Gas giant haze at poles
  if(s==='gas'){
    for(let cy2=0;cy2<sz;cy2+=2){
      const yf=(cy2/sz)*2-1;
      const latAbs=Math.abs(yf);
      if(latAbs<0.65)continue;
      for(let cx2=0;cx2<sz;cx2+=2){
        const xf=(cx2/sz)*2-1;if(xf*xf+yf*yf>1)continue;
        const haze=(latAbs-0.65)/0.35;
        pc.fillStyle=`rgba(255,255,255,${haze*.12})`;
        pc.fillRect(cx2,cy2,2,2);
      }
    }
  }

  return oc;
}

// ── HELPERS ──────────────────────────────────────────────────
function lighten(hex,a){try{const r=Math.min(255,parseInt(hex.slice(1,3),16)+a),g=Math.min(255,parseInt(hex.slice(3,5),16)+a),b2=Math.min(255,parseInt(hex.slice(5,7),16)+a);return`rgb(${r},${g},${b2})`;}catch{return hex;}}
function darken(hex,a){try{const r=Math.max(0,parseInt(hex.slice(1,3),16)-a),g=Math.max(0,parseInt(hex.slice(3,5),16)-a),b2=Math.max(0,parseInt(hex.slice(5,7),16)-a);return`rgb(${r},${g},${b2})`;}catch{return hex;}}
function flash(wx,wy,r,color,isNova){cFlashes.push({x:wx,y:wy,r,age:0,maxAge:isNova?4:.6,color:color||'#ffaa44',isNova:!!isNova});}

// ── DRAWING ──────────────────────────────────────────────────
function drawGrid(){
  const step=100*camSc,ox=camX%step,oy=camY%step;
  ctx.strokeStyle='rgba(14,28,51,0.25)';ctx.lineWidth=.4;
  for(let x=ox;x<cv.width;x+=step){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,cv.height);ctx.stroke();}
  for(let y=oy;y<cv.height;y+=step){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(cv.width,y);ctx.stroke();}
}
function drawStarfield(){
  for(let i=0;i<300;i++){
    const x=((i*1847+i*i*37)%cv.width+cv.width)%cv.width,y=((i*2311+i*i*53)%cv.height+cv.height)%cv.height;
    const r=i%6===0?1.3:i%3===0?.7:.4;ctx.globalAlpha=.04+(i%6)*.04;
    ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
  }ctx.globalAlpha=1;
}
function drawNebulae(){
  if(!showNebulae)return;
  for(const nb of nebulae){
    for(const pt of nb.particles){
      const s=w2s(pt.x,pt.y);const sr=pt.r*camSc;if(sr<.3)continue;
      const gr=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,sr);
      gr.addColorStop(0,pt.color+Math.floor(pt.alpha*255).toString(16).padStart(2,'0'));gr.addColorStop(1,'transparent');
      ctx.beginPath();ctx.arc(s.x,s.y,sr,0,Math.PI*2);ctx.fillStyle=gr;ctx.fill();
    }
  }
}
function drawZones(){
  for(const star of bodies.filter(b=>b.type==='star')){
    const z=getZB(star.def||star);const s=w2s(star.x,star.y);const sc=camSc;
    const donut=(i,o,c)=>{ctx.beginPath();ctx.arc(s.x,s.y,o*sc,0,Math.PI*2);ctx.arc(s.x,s.y,i*sc,0,Math.PI*2,true);ctx.fillStyle=c;ctx.fill();};
    donut(0,z.hot,'rgba(255,50,0,0.04)');donut(z.hot,z.warm,'rgba(255,120,0,0.022)');
    donut(z.warm,z.hab1,'rgba(255,200,0,0.018)');donut(z.hab1,z.hab2,'rgba(0,255,120,0.05)');
    donut(z.hab2,z.cold,'rgba(50,150,255,0.018)');
    [[z.hot,'rgba(255,50,0,0.22)'],[z.hab1,'rgba(0,255,120,0.32)'],[z.hab2,'rgba(0,255,120,0.18)']].forEach(([r,c])=>{
      const sr=r*sc;if(sr<15)return;ctx.beginPath();ctx.arc(s.x,s.y,sr,0,Math.PI*2);
      ctx.strokeStyle=c;ctx.lineWidth=.5;ctx.setLineDash([3,4]);ctx.stroke();ctx.setLineDash([]);});
  }
}
function drawMagFields(){
  if(!showMagFields)return;
  for(const b of bodies){
    if(!b.magField)continue;
    const s=w2s(b.x,b.y);const mr=b.magField.radius*camSc;
    const time=performance.now()/1000;
    // Draw field lines
    for(let i=0;i<8;i++){
      const baseAngle=(i/8)*Math.PI*2+time*.2;
      ctx.save();ctx.translate(s.x,s.y);ctx.rotate(baseAngle);
      ctx.beginPath();
      for(let t=0;t<Math.PI;t+=0.1){const r=mr*(.5+Math.sin(t)*0.5);ctx.lineTo(r*Math.cos(t)-(mr*.3)*Math.cos(t*2),r*Math.sin(t)*(b.type==='star'?0.6:0.4));}
      ctx.strokeStyle=`rgba(100,180,255,${b.magField.strength*.08})`;ctx.lineWidth=.6;ctx.stroke();ctx.restore();
    }
    ctx.beginPath();ctx.ellipse(s.x,s.y,mr,mr*.3,0,0,Math.PI*2);
    ctx.strokeStyle=`rgba(80,160,255,${b.magField.strength*.15})`;ctx.lineWidth=.8;ctx.setLineDash([3,3]);ctx.stroke();ctx.setLineDash([]);
  }
}
function drawSolarEvents(){
  for(const ev of solarEvents){
    const star=bodies.find(b=>b.id===ev.starId);
    if(!star&&!ev.x)continue;
    const s=star?w2s(star.x,star.y):w2s(ev.x,ev.y);const r=star.radius*camSc;
    if(ev.type==='flare'){
      const t=ev.age/ev.maxAge,len=ev.length*camSc*(1-t*.3);
      ctx.save();ctx.translate(s.x,s.y);ctx.rotate(ev.angle+ev.speed*ev.age);
      const gg=ctx.createLinearGradient(r,0,r+len,0);
      gg.addColorStop(0,ev.color+'cc');gg.addColorStop(0.5,ev.color+'88');gg.addColorStop(1,ev.color+'00');
      ctx.beginPath();ctx.moveTo(r,0);ctx.bezierCurveTo(r+len*.4,ev.width*camSc*.5,r+len*.7,-ev.width*camSc*.3,r+len,0);
      ctx.bezierCurveTo(r+len*.7,ev.width*camSc*.3,r+len*.4,-ev.width*camSc*.5,r,0);
      ctx.fillStyle=gg;ctx.globalAlpha=1-t;ctx.fill();ctx.globalAlpha=1;ctx.restore();
    } else if(ev.type==='radiation'){
      const rr=ev.radius*camSc;
      if(rr>.3){
        const prog=ev.radius/ev.maxRadius; // 0->1 over lifetime
        const fade=Math.max(0, 1-prog*0.85); // fades as it expands
        const ringW=Math.max(1.5,(ev.ringWidth||2)*camSc);
        // Outer glow halo (wide soft ring)
        const gg=ctx.createRadialGradient(s.x,s.y,Math.max(0,rr-ringW*3),s.x,s.y,rr+ringW*1.5);
        gg.addColorStop(0,'transparent');
        gg.addColorStop(0.4,star.glow+(Math.floor(fade*0x22).toString(16).padStart(2,'0')));
        gg.addColorStop(0.75,star.glow+(Math.floor(fade*0x55).toString(16).padStart(2,'0')));
        gg.addColorStop(1,'transparent');
        ctx.beginPath();ctx.arc(s.x,s.y,rr+ringW*1.5,0,Math.PI*2);
        ctx.fillStyle=gg;ctx.fill();
        // Crisp leading edge ring
        ctx.beginPath();ctx.arc(s.x,s.y,rr,0,Math.PI*2);
        ctx.strokeStyle=star.glow+(Math.floor(fade*0xaa).toString(16).padStart(2,'0'));
        ctx.lineWidth=Math.max(0.5,ringW*0.5);ctx.stroke();
        // Secondary inner ring (echo wave)
        if(rr>30){
          const rr2=Math.max(0,rr-ringW*4);
          ctx.beginPath();ctx.arc(s.x,s.y,rr2,0,Math.PI*2);
          ctx.strokeStyle=star.glow+(Math.floor(fade*0x33).toString(16).padStart(2,'0'));
          ctx.lineWidth=Math.max(0.3,ringW*0.25);ctx.stroke();
        }
      }
    } else if(ev.type==='pulse'){
      const rr=ev.radius*camSc;
      if(rr>.5){
        const fade=1-ev.age/ev.maxAge;
        ctx.beginPath();ctx.arc(s.x,s.y,rr,0,Math.PI*2);
        ctx.strokeStyle=`rgba(150,255,200,${fade*0.5})`;ctx.lineWidth=2*fade;ctx.stroke();
        if(rr>10){ctx.beginPath();ctx.arc(s.x,s.y,rr*0.85,0,Math.PI*2);
          ctx.strokeStyle=`rgba(100,200,255,${fade*0.2})`;ctx.lineWidth=1;ctx.stroke();}
      }
    }
  }
}
function drawStar(star){
  const s=w2s(star.x,star.y);const r=star.radius*camSc;if(r<.3)return;
  // Neutron star / pulsar intense glow
  if(star.sub==='neutron-star'||star.sub==='pulsar'||star.isPulsar){
    const gr=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r*8);
    const c=star.isPulsar||star.sub==='pulsar'?'0,255,200':'100,150,255';
    gr.addColorStop(0,`rgba(${c},0.9)`);gr.addColorStop(0.2,`rgba(${c},0.4)`);gr.addColorStop(1,'transparent');
    ctx.beginPath();ctx.arc(s.x,s.y,r*8,0,Math.PI*2);ctx.fillStyle=gr;ctx.fill();
    ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);ctx.fillStyle=`rgba(${c},1)`;ctx.fill();
    if(star.id===selectedId){ctx.beginPath();ctx.arc(s.x,s.y,r+4,0,Math.PI*2);ctx.strokeStyle='#00d4ff';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);ctx.stroke();ctx.setLineDash([]);}
    return;
  }
  // Collapse animation
  if(star._collapsing){
    star._collapseAge=(star._collapseAge||0)+(1/60);
    const t=Math.min(star._collapseAge/5,1);
    const pulseR=r*(1-t*.7)*(1+Math.sin(star._collapseAge*8)*.1);
    const cg=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,pulseR*4);
    cg.addColorStop(0,'#ffffff');cg.addColorStop(.3,'rgba(200,200,255,'+(1-t)+')');cg.addColorStop(1,'transparent');
    ctx.beginPath();ctx.arc(s.x,s.y,pulseR*4,0,Math.PI*2);ctx.fillStyle=cg;ctx.fill();
    ctx.beginPath();ctx.arc(s.x,s.y,pulseR,0,Math.PI*2);ctx.fillStyle='#ffffff';ctx.fill();
    // Gravitational lensing rings
    for(let i=1;i<=3;i++){ctx.beginPath();ctx.arc(s.x,s.y,pulseR*i*.8,0,Math.PI*2);ctx.strokeStyle=`rgba(150,150,255,${(1-t)*.3/i})`;ctx.lineWidth=i*1.5;ctx.stroke();}
    return;
  }
  // White dwarf pulsing before BH
  if(star._becomesBH){
    const pulse=1+Math.sin((star._bhTimer||0)*star._bhTimer*.3)*.2;
    const gr=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r*pulse*5);
    gr.addColorStop(0,'#ffffff');gr.addColorStop(.4,'rgba(180,180,255,.8)');gr.addColorStop(1,'transparent');
    ctx.beginPath();ctx.arc(s.x,s.y,r*pulse*5,0,Math.PI*2);ctx.fillStyle=gr;ctx.fill();
    ctx.beginPath();ctx.arc(s.x,s.y,r*pulse,0,Math.PI*2);ctx.fillStyle='#ffffffee';ctx.fill();
    // Countdown ring
    const pct=(star._bhTimer||0)/180;
    ctx.beginPath();ctx.arc(s.x,s.y,r*pulse*1.8,-Math.PI/2,-Math.PI/2+pct*Math.PI*2);
    ctx.strokeStyle='#ff4400';ctx.lineWidth=3;ctx.stroke();
    return;
  }
  // Supernova swell/flash
  const snR=star.supernovaTriggered&&star.supernovaPhase==='swell'?star.radius*camSc:r;
  if(star.supernovaTriggered){
    const t=(star.supernovaAge||0)/3;
    const grd=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,snR*6);
    grd.addColorStop(0,'rgba(255,255,255,'+(1-t*.5)+')');grd.addColorStop(.3,'rgba(255,240,100,'+((1-t)*.8)+')');grd.addColorStop(1,'transparent');
    ctx.beginPath();ctx.arc(s.x,s.y,snR*6,0,Math.PI*2);ctx.fillStyle=grd;ctx.fill();
    // Shockwave rings
    for(let i=1;i<=3;i++){const rr=snR*(1+t*i*3);ctx.beginPath();ctx.arc(s.x,s.y,rr,0,Math.PI*2);ctx.strokeStyle=`rgba(255,200,50,${(.6-t*.5)/i})`;ctx.lineWidth=3;ctx.stroke();}
  }
  // Normal star
  const grd=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r*4.5);
  grd.addColorStop(0,star.glow+'bb');grd.addColorStop(.35,star.glow+'28');grd.addColorStop(1,'transparent');
  ctx.beginPath();ctx.arc(s.x,s.y,r*4.5,0,Math.PI*2);ctx.fillStyle=grd;ctx.fill();
  for(let i=0;i<10;i++){const a=star.angle+(i/10)*Math.PI*2,len=r*(1.15+Math.sin(star.age*.4+i)*.22);ctx.save();ctx.translate(s.x,s.y);ctx.rotate(a);ctx.beginPath();ctx.moveTo(r*.88,0);ctx.lineTo(len,0);ctx.strokeStyle=star.glow+'66';ctx.lineWidth=1.3;ctx.stroke();ctx.restore();}
  const sg2=ctx.createRadialGradient(s.x-r*.3,s.y-r*.3,0,s.x,s.y,r);sg2.addColorStop(0,'#fff');sg2.addColorStop(.28,star.color);sg2.addColorStop(1,star.glow);
  ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);ctx.fillStyle=sg2;ctx.fill();
  // Surface spots
  ctx.save();ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);ctx.clip();
  for(let i=0;i<4;i++){ctx.beginPath();ctx.arc(s.x+Math.cos(star.angle*1.2+i*1.4)*r*.5,s.y+Math.sin(star.angle*1.2+i*1.4)*r*.5,r*(.08+Math.sin(i)*.06),0,Math.PI*2);ctx.fillStyle='rgba(0,0,0,0.15)';ctx.fill();}
  ctx.restore();
  if(star.id===selectedId){ctx.beginPath();ctx.arc(s.x,s.y,r+4,0,Math.PI*2);ctx.strokeStyle='#00d4ff';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);ctx.stroke();ctx.setLineDash([]);}
  if(camSc>.04&&r>1){ctx.fillStyle=star.color;ctx.font=`${Math.max(6,7*Math.min(camSc,1.4))}px "Share Tech Mono"`;ctx.textAlign='center';ctx.fillText(star.name,s.x,s.y+r+9);}
  // Label age near supernova threshold
  if(star.canSupernova&&camSc>.2&&r>3){
    const pct=Math.min(simTime/SUPERNOVA_MIN_YR,1);
    ctx.strokeStyle='rgba(255,100,0,0.5)';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(s.x,s.y,r+7,-Math.PI/2,-Math.PI/2+pct*Math.PI*2);ctx.stroke();
  }
}
function drawPlanet(planet){
  const sv=planet.tidal||{sx:1,sy:1};
  const base=w2s(planet.x,planet.y);
  const rX=Math.max(planet.radius*camSc,1.5)*sv.sx,rY=Math.max(planet.radius*camSc,1.5)*(planet.shapeY||1)*sv.sy;
  if(rX<.5)return;
  const angle=planet.tidalAngle||0;
  // Temp glow
  if(planet.tempK>0){const tc=tempToColor(planet.tempK);const tg=ctx.createRadialGradient(base.x,base.y,rX,base.x,base.y,rX*2);tg.addColorStop(0,tc+'14');tg.addColorStop(1,'transparent');ctx.beginPath();ctx.ellipse(base.x,base.y,rX*2,rY*2,angle,0,Math.PI*2);ctx.fillStyle=tg;ctx.fill();}
  // Rings
  for(let ri=0;ri<planet.rings;ri++){const ri_i=rX*(1.3+ri*.28),ri_o=ri_i+rX*.18;ctx.save();ctx.translate(base.x,base.y);ctx.scale(1,.3);ctx.beginPath();ctx.arc(0,0,ri_o,0,Math.PI*2);ctx.arc(0,0,ri_i,0,Math.PI*2,true);ctx.fillStyle=(planet.evoStage==='ice'?'#aaddff':'#d4a87a')+'bb';ctx.fill();ctx.restore();}
  // Life glow
  if(planet.hasLife){const g=ctx.createRadialGradient(base.x,base.y,rX,base.x,base.y,rX*2.5);g.addColorStop(0,'rgba(0,255,120,0.16)');g.addColorStop(1,'transparent');ctx.beginPath();ctx.ellipse(base.x,base.y,rX*2.5,rY*2.5,angle,0,Math.PI*2);ctx.fillStyle=g;ctx.fill();}
  // Civ halo
  const civ=civilizations.find(c=>c.planetId===planet.id&&!c.extinct);
  if(civ){const cg=ctx.createRadialGradient(base.x,base.y,rX,base.x,base.y,rX*3.2);cg.addColorStop(0,civ.color+'22');cg.addColorStop(1,'transparent');ctx.beginPath();ctx.ellipse(base.x,base.y,rX*3.2,rY*3.2,angle,0,Math.PI*2);ctx.fillStyle=cg;ctx.fill();}
  // Magma glow for hot planets
  if(planet.evoStage==='magma'){const mg=ctx.createRadialGradient(base.x,base.y,rX*.8,base.x,base.y,rX*2.2);mg.addColorStop(0,'rgba(255,60,0,0.35)');mg.addColorStop(.6,'rgba(255,100,0,0.15)');mg.addColorStop(1,'transparent');ctx.beginPath();ctx.arc(base.x,base.y,rX*2.2,0,Math.PI*2);ctx.fillStyle=mg;ctx.fill();}
  // Binary attraction lines
  const bp=binaryPairs.find(p=>p.aId===planet.id||p.bId===planet.id);
  if(bp){const otherId=bp.aId===planet.id?bp.bId:bp.aId;const other=bodies.find(b=>b.id===otherId);if(other){const os=w2s(other.x,other.y);ctx.save();ctx.beginPath();ctx.moveTo(base.x,base.y);ctx.lineTo(os.x,os.y);ctx.strokeStyle=`rgba(255,200,50,${0.1+bp.timer/bp.collisionTime*.4})`;ctx.lineWidth=0.8;ctx.setLineDash([3,4]);ctx.stroke();ctx.setLineDash([]);ctx.restore();}}
  // Texture sphere
  ctx.save();ctx.beginPath();ctx.ellipse(base.x,base.y,rX,rY,angle,0,Math.PI*2);ctx.clip();
  if(rX>3){const tsz=Math.max(32,Math.min(128,Math.ceil(rX*2)));ctx.save();ctx.translate(base.x,base.y);
  const _tilt=planet.axialTilt||0,_spin=planet.spinAngle||0;
  ctx.rotate(angle+_spin*0.03);if(_tilt)ctx.transform(1,Math.sin(_tilt)*0.3,0,1,0,0);
  ctx.scale(sv.sx,sv.sy);ctx.drawImage(getTex(planet,tsz),-rX/sv.sx,-rY/sv.sy,rX*2/sv.sx,rY*2/sv.sy);ctx.restore();}
  else{ctx.fillStyle=planet.colors?.[0]||'#888';ctx.fillRect(base.x-rX,base.y-rY,rX*2,rY*2);}
  ctx.restore();
  // Atmosphere
  if((planet.atmo||0)>.04){const stage=planet.evoStage||planet.pt;const ac=planet.hasLife?'0,200,120':stage==='ice'?'100,180,255':stage==='lava'||stage==='magma'?'255,80,20':'160,180,220';const ag=ctx.createRadialGradient(base.x,base.y,rX*.9,base.x,base.y,rX*1.35);ag.addColorStop(0,`rgba(${ac},${(planet.atmo||.2)*.28})`);ag.addColorStop(1,'transparent');ctx.beginPath();ctx.ellipse(base.x,base.y,rX*1.35,rY*1.35,angle,0,Math.PI*2);ctx.fillStyle=ag;ctx.fill();}
  // Moons
  for(const moon of planet.moons){const mr=moon.dist*camSc,mx=base.x+Math.cos(moon.angle)*mr,my=base.y+Math.sin(moon.angle)*mr;const moonR=Math.max(moon.radius*camSc,1);if(camSc>.28){ctx.beginPath();ctx.arc(base.x,base.y,mr,0,Math.PI*2);ctx.strokeStyle='rgba(80,120,180,0.07)';ctx.lineWidth=.4;ctx.stroke();}ctx.beginPath();ctx.arc(mx,my,moonR,0,Math.PI*2);const mg=ctx.createRadialGradient(mx-moonR*.3,my-moonR*.3,0,mx,my,moonR);mg.addColorStop(0,'#ccbbaa');mg.addColorStop(1,'#887766');ctx.fillStyle=mg;ctx.fill();}
  // Water flood wave effect
  if((planet.waterFloodProgress||0)>0&&(planet.waterFloodProgress||0)<1){const fp=planet.waterFloodProgress;ctx.save();ctx.beginPath();ctx.ellipse(base.x,base.y,rX,rY,angle,0,Math.PI*2);ctx.clip();for(let wi=0;wi<5;wi++){const wy=base.y-rY+rY*2*((wi/5+fp*.8)%1);ctx.beginPath();ctx.moveTo(base.x-rX,wy);ctx.bezierCurveTo(base.x-rX/2,wy-4*fp,base.x+rX/2,wy+4*fp,base.x+rX,wy);ctx.strokeStyle=`rgba(80,160,255,${0.6*fp})`;ctx.lineWidth=2;ctx.stroke();}ctx.restore();}
  // Selection / hab ring
  if(planet.id===selectedId){ctx.beginPath();ctx.ellipse(base.x,base.y,rX+4,rY+4,angle,0,Math.PI*2);ctx.strokeStyle='#00d4ff';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);ctx.stroke();ctx.setLineDash([]);}
  if(planet.zone==='habitable'||planet.zone==='inner-hab'){ctx.beginPath();ctx.ellipse(base.x,base.y,rX+1.5,rY+1.5,angle,0,Math.PI*2);ctx.strokeStyle='rgba(0,255,120,0.32)';ctx.lineWidth=.7;ctx.stroke();}
  // Labels
  if(camSc>.14&&rX>1.5){
    const stLabel=EVO[planet.evoStage]?.label||'';
    ctx.fillStyle=planet.hasLife?'#00ff88':civ?civ.color:'#b8cde0';
    ctx.font=`${Math.max(6,7*Math.min(camSc,1.5))}px "Share Tech Mono"`;ctx.textAlign='center';
    ctx.fillText(planet.name,base.x,base.y+rY+9);
    if(stLabel&&camSc>.4){ctx.font='6px "Share Tech Mono"';ctx.fillStyle='#5577aa';ctx.fillText(stLabel,base.x,base.y+rY+17);}
    if(civ&&camSc>.5){ctx.font='6px "Share Tech Mono"';ctx.fillStyle=civ.color;ctx.fillText(civ.name,base.x,base.y+rY+25);}
    if(planet.tempK>0&&camSc>.7){ctx.fillStyle=tempToColor(planet.tempK);ctx.font='6px "Share Tech Mono"';ctx.fillText(Math.round(planet.tempK)+'K',base.x,base.y+rY+33);}
    // Cooldown timer
    if(planet.cooldownTimer>0){ctx.fillStyle='#ff4400';ctx.font='6px "Share Tech Mono"';ctx.fillText('🔥'+Math.round(planet.cooldownTimer)+'s',base.x,base.y+rY+41);}
  }
}
function drawHole(hole){
  const s=w2s(hole.x,hole.y);const r=hole.radius*camSc;if(r<.5)return;
  // BH formation animation
  if(hole.justFormed){
    const t=Math.min((hole.formAge||0)/3,1);
    for(let i=5;i>=1;i--){const rr=r*i*(2-t);ctx.beginPath();ctx.arc(s.x,s.y,rr,0,Math.PI*2);ctx.strokeStyle=`rgba(170,70,255,${t*.6/i})`;ctx.lineWidth=3;ctx.stroke();}
  }
  if(hole.sub==='black'){
    ctx.save();ctx.translate(s.x,s.y);
    for(const ap of hole.accretionParticles){const ax=Math.cos(ap.a)*ap.dist*camSc,ay=Math.sin(ap.a)*ap.dist*camSc*.22;ctx.beginPath();ctx.arc(ax,ay,ap.size*Math.min(camSc,1.2),0,Math.PI*2);ctx.fillStyle=ap.color;ctx.globalAlpha=.75;ctx.fill();}
    ctx.globalAlpha=1;ctx.restore();
    const lg=ctx.createRadialGradient(s.x,s.y,r,s.x,s.y,r*3);lg.addColorStop(0,'rgba(255,80,0,0.15)');lg.addColorStop(1,'transparent');ctx.beginPath();ctx.arc(s.x,s.y,r*3,0,Math.PI*2);ctx.fillStyle=lg;ctx.fill();
    const eg=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r);eg.addColorStop(0,'#000');eg.addColorStop(.85,'#000');eg.addColorStop(1,'#0a0300');ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);ctx.fillStyle=eg;ctx.fill();
    ctx.beginPath();ctx.arc(s.x,s.y,r*1.08,0,Math.PI*2);ctx.strokeStyle='#ff5500';ctx.lineWidth=1.5;ctx.stroke();
    // Gravitational lensing ring
    ctx.beginPath();ctx.arc(s.x,s.y,r*1.6,0,Math.PI*2);ctx.strokeStyle='rgba(255,160,50,0.2)';ctx.lineWidth=4;ctx.stroke();
  } else {
    const eg=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r*4);eg.addColorStop(0,'#fff');eg.addColorStop(.3,'#aaccff');eg.addColorStop(.7,'#4488ff22');eg.addColorStop(1,'transparent');ctx.beginPath();ctx.arc(s.x,s.y,r*4,0,Math.PI*2);ctx.fillStyle=eg;ctx.fill();ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();
  }
  if(hole.id===selectedId){ctx.beginPath();ctx.arc(s.x,s.y,r+4,0,Math.PI*2);ctx.strokeStyle='#b06bff';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);ctx.stroke();ctx.setLineDash([]);}
  if(camSc>.04){ctx.fillStyle=hole.sub==='black'?'#ff8800':'#88aaff';ctx.font='7px "Share Tech Mono"';ctx.textAlign='center';ctx.fillText(hole.name,s.x,s.y+r+10);}
}
function drawBelt(belt){
  const s=w2s(belt.x,belt.y);const bR=belt.radius*camSc;
  if(s.x+bR<-50||s.x-bR>cv.width+50||s.y+bR<-50||s.y-bR>cv.height+50)return;
  const step=camSc<0.04?8:camSc<0.1?4:camSc<0.3?2:1;
  ctx.fillStyle=belt.waterRich?'#6677bb66':'#88776622';
  for(let i=0;i<belt.particles.length;i+=step){
    const p=belt.particles[i];
    const px=s.x+Math.cos(p.angle)*p.r*camSc,py=s.y+Math.sin(p.angle)*p.r*camSc;
    if(px<-4||px>cv.width+4||py<-4||py>cv.height+4)continue;
    const pr=Math.max(.3,p.size*camSc*.3);
    ctx.beginPath();ctx.arc(px,py,pr,0,Math.PI*2);ctx.fill();
  }
  if(belt.id===selectedId){ctx.beginPath();ctx.arc(s.x,s.y,bR,0,Math.PI*2);ctx.strokeStyle='#00d4ff33';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);ctx.stroke();ctx.setLineDash([]);}
}
function drawAsteroid(ast){
  const s=w2s(ast.x,ast.y);const r=Math.max(ast.radius*camSc,.7);if(r<.3)return;
  const ts=ast.tidal||{sx:1,sy:1};
  ctx.save();ctx.translate(s.x,s.y);ctx.rotate(ast.angle||0);ctx.scale(ts.sx,ts.sy);
  ctx.beginPath();for(let i=0;i<7;i++){const a=(i/7)*Math.PI*2,rr=r*(.7+Math.sin(i*2.3+(ast.id||0)*.5)*.28);i===0?ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr):ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}
  ctx.closePath();ctx.fillStyle=ast.isWater?'#3a4c77':'#5a4a3a';ctx.strokeStyle=ast.isWater?'#7789bb':'#887766';ctx.lineWidth=.35;ctx.fill();ctx.stroke();ctx.restore();
}
function drawShips(){
  for(const ship of ships){
    const s=w2s(ship.x,ship.y);
    if(ship.trail.length>1){ctx.beginPath();const t0=w2s(ship.trail[0].x,ship.trail[0].y);ctx.moveTo(t0.x,t0.y);for(let i=1;i<ship.trail.length;i++){const tp=w2s(ship.trail[i].x,ship.trail[i].y);ctx.lineTo(tp.x,tp.y);}ctx.strokeStyle=ship.color+'44';ctx.lineWidth=.7;ctx.stroke();}
    const dx=ship.tx-ship.x,dy=ship.ty-ship.y,angle=Math.atan2(dy,dx);
    ctx.save();ctx.translate(s.x,s.y);ctx.rotate(angle);
    ctx.fillStyle=ship.color;ctx.beginPath();ctx.moveTo(6*camSc,0);ctx.lineTo(-3*camSc,-2*camSc);ctx.lineTo(-3*camSc,2*camSc);ctx.closePath();ctx.fill();
    const eg=ctx.createRadialGradient(-3*camSc,0,0,-3*camSc,0,4*camSc);eg.addColorStop(0,ship.color+'bb');eg.addColorStop(1,'transparent');ctx.beginPath();ctx.arc(-3*camSc,0,3*camSc,0,Math.PI*2);ctx.fillStyle=eg;ctx.fill();
    ctx.restore();
  }
}
function drawFlashes(){
  for(const f of cFlashes){const s=w2s(f.x,f.y);const t=f.age/f.maxAge;const r=(f.r+(f.r*t*(f.isNova?9:2.5)))*camSc;const grd=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r);const a=Math.floor((1-t)*255).toString(16).padStart(2,'0');grd.addColorStop(0,f.color+a);grd.addColorStop(1,'transparent');ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);ctx.fillStyle=grd;ctx.fill();}
}

// ── SURFACE VIEW ──────────────────────────────────────────────
let surfacePlanet=null,svTime=0,svRunning=false;
let svAsteroids=[]; // visible asteroids in surface view: {x,y,vx,vy,r,dist,phase,alpha}
let svLastAstCheck=0;

function openSurface(){
  const planet=bodies.find(b=>b.id===selectedId&&b.type==='planet');
  if(!planet){ntf('Select a planet first!','w');return;}
  surfacePlanet=planet;svTime=0;svAsteroids=[];
  document.getElementById('sv').classList.add('show');
  document.getElementById('sv-name').textContent=planet.name;
  document.getElementById('sv-info').textContent=(planet.evoStage||'rocky')+' | '+Math.round(planet.tempK||0)+'K | '+(planet.zone||'unknown');
  resizeSV();
  startSurfaceAmbience(planet.evoStage||planet.pt||'rocky');
  if(!svRunning){svRunning=true;requestAnimationFrame(svLoop);}
}
function closeSurface(){
  document.getElementById('sv').classList.remove('show');
  stopSurfaceAmbience();
  surfacePlanet=null;svRunning=false;svAsteroids=[];
}

function updateSVAsteroids(){
  if(!surfacePlanet) return;
  const now=svTime;
  // Cull expired asteroids
  svAsteroids=svAsteroids.filter(a=>!a.expired&&a.x>-0.3&&a.x<1.3);
  // Every 2 real seconds, check for real nearby asteroids
  const _rn=performance.now()/1000;
  if(_rn-svLastAstCheck>1.0){
    svLastAstCheck=_rn;
    const pl=surfacePlanet;
    const nearby=bodies.filter(b=>b.type==='asteroid'&&Math.hypot(b.x-pl.x,b.y-pl.y)<pl.radius*15+200);
    for(const ast of nearby){
      // Only spawn a surface-view asteroid once per real asteroid (keyed by id)
      if(svAsteroids.find(a=>a.srcId===ast.id)) continue;
      const dist=Math.hypot(ast.x-pl.x,ast.y-pl.y);
      const closeness=Math.max(0,1-dist/(pl.radius*15+200));
      const size=Math.max(2, ast.radius*(0.4+closeness*1.8));
      // Direction across sky — based on asteroid's relative velocity
      const relVx=ast.vx-(pl.vx||0), relVy=ast.vy-(pl.vy||0);
      const speed=Math.hypot(relVx,relVy)||1;
      const screenSpd=(0.08+closeness*0.35)*(size*.012+0.04); // px/frame relative to W
      // Start from left or right edge depending on velocity
      const fromLeft=relVx>0;
      svAsteroids.push({
        srcId:ast.id,
        x:fromLeft?-0.08:1.08,           // fractional screen coords
        y:0.35+Math.random()*0.4,         // sky to horizon
        vx:(fromLeft?1:-1)*screenSpd,
        vy:(Math.random()-0.5)*screenSpd*0.3,
        r:size, closeness,
        phase:0, maxPhase:1,
        isWater:ast.isWater,
        trail:[],
        willImpact:dist<pl.radius*4&&Math.random()<0.35
      });
      sndAsteroidFlyby(closeness);
    }
    // Randomly spawn background bolide meteors even without real asteroids (rare)
    if(Math.random()<0.35&&svAsteroids.length<8){
      const closeness=Math.random()*.5;
      const size=1+closeness*4+Math.random()*3;
      svAsteroids.push({
        srcId:-Math.floor(Math.random()*9999),
        x:Math.random()<.5?-0.05:1.05,
        y:0.12+Math.random()*0.35,
        vx:(Math.random()<.5?1:-1)*(0.006+closeness*.02),
        vy:(Math.random()-.5)*0.003,
        r:size, closeness,
        phase:0, maxPhase:1,
        isWater:Math.random()<.1,
        trail:[],
        willImpact:false
      });
      if(closeness>0.3) sndAsteroidFlyby(closeness*.4);
    }
  }
  // Advance each asteroid
  for(const a of svAsteroids){
    a.trail.push({x:a.x,y:a.y});
    if(a.trail.length>22) a.trail.shift();
    a.x+=a.vx; a.y+=a.vy;
    // phase = how far across screen (0->1)
    a.phase=a.x<0.5?Math.max(0,(a.x+0.08)/1.16):Math.max(0,(1.08-a.x)/1.16);
    // Impact: when reaches center bottom
    if(a.willImpact&&a.x>0.35&&a.x<0.65&&a.y>0.62&&!a.impacted){
      a.impacted=true;
      sndAsteroidImpactSurface(a.r/6);
      // Flash
      svImpactFlash={x:a.x,y:a.y,age:0,r:a.r};
    }
  }
}

let svImpactFlash=null;
function svLoop(){
  if(!svRunning||!document.getElementById('sv').classList.contains('show')){svRunning=false;return;}
  const svc=document.getElementById('sv-cv');
  const ctx2=svc.getContext('2d');
  const W=svc.width,H=svc.height;
  if(W<10||H<10){requestAnimationFrame(svLoop);return;}
  const planet=surfacePlanet; svTime+=0.016;
  if(!planet){ctx2.clearRect(0,0,W,H);requestAnimationFrame(svLoop);return;}
  const stage=planet.evoStage||planet.pt||'rocky';
  const seed=planet.id*13+7;
  const scrollX=svTime*22;

  // ── Sky ──────────────────────────────────────────────────────
  const skies={
    lava:     ['#12040a','#2a0a00','#3a1200'],
    magma:    ['#0e0200','#250600','#3a0c00'],
    cooling:  ['#06060f','#10101e','#181828'],
    rocky:    ['#060810','#0e1422','#14203a'],
    arid:     ['#0e0c06','#1e160a','#2a1e0e'],
    desert:   ['#100c04','#201808','#30220c'],
    ice:      ['#04070e','#080e1c','#0c162a'],
    ocean:    ['#020810','#040e1e','#070f28'],
    life:     ['#030a10','#050f1c','#071528'],
    advanced: ['#020608','#030c12','#04101c'],
    gas:      ['#060508','#0e0a12','#18101e'],
    freezing: ['#030a12','#06101e','#0a1828'],
    frozen:   ['#02060e','#040c18','#060f20'],
  };
  const sk=skies[stage]||skies.rocky;
  const skyg=ctx2.createLinearGradient(0,0,0,H*.7);
  skyg.addColorStop(0,sk[0]);skyg.addColorStop(0.45,sk[1]);skyg.addColorStop(1,sk[2]);
  ctx2.fillStyle=skyg;ctx2.fillRect(0,0,W,H);

  // ── Stars ────────────────────────────────────────────────────
  // Only show stars where atmosphere is thin
  const showStars=stage!=='life'&&stage!=='advanced'&&stage!=='ocean'||(planet.atmo||0)<0.4;
  if(showStars||true){
    for(let i=0;i<280;i++){
      const sx=((i*1847+i*i*37)%W);
      const sy=((i*2311+i*i*53)%(H*.52));
      const a=Math.max(0,.9-sy/(H*.48))*(showStars?1:.4);
      if(a<.02)continue;
      ctx2.globalAlpha=a;ctx2.fillStyle='#ffffff';
      ctx2.beginPath();ctx2.arc(sx,sy,i%7===0?1.4:i%3===0?.7:.35,0,Math.PI*2);ctx2.fill();
    }
    ctx2.globalAlpha=1;
  }

  // ── Parent star in sky ───────────────────────────────────────
  const star=bodies.find(b=>b.id===planet.orbitStar);
  if(star){
    const sunX=W*.2+Math.sin(svTime*.06)*W*.07;
    const sunY=H*.15+Math.cos(svTime*.035)*H*.04;
    const dist=Math.hypot(planet.x-star.x,planet.y-star.y)||200;
    const sunR=Math.max(18,Math.min(80,star.radius/dist*8000));
    // Corona
    for(let ci=4;ci>=1;ci--){
      const cg=ctx2.createRadialGradient(sunX,sunY,sunR*.8,sunX,sunY,sunR*ci*1.5);
      cg.addColorStop(0,star.glow+'44');cg.addColorStop(1,'transparent');
      ctx2.beginPath();ctx2.arc(sunX,sunY,sunR*ci*1.5,0,Math.PI*2);ctx2.fillStyle=cg;ctx2.fill();
    }
    ctx2.beginPath();ctx2.arc(sunX,sunY,sunR,0,Math.PI*2);ctx2.fillStyle=star.color;ctx2.fill();
  }

  // ── Horizon atmosphere glow ──────────────────────────────────
  const atmoRGBs={lava:'255,60,10',magma:'255,30,0',cooling:'80,80,120',
    rocky:'80,100,160',arid:'180,130,60',desert:'190,140,65',
    ice:'80,150,220',ocean:'20,70,180',life:'20,140,90',advanced:'10,120,160',gas:'150,120,80',freezing:'60,130,200',frozen:'40,100,180'};
  const atmoRGB=atmoRGBs[stage]||'80,100,160';
  const atmoStr=(planet.atmo||0.2)*0.35;
  const hg=ctx2.createLinearGradient(0,H*.35,0,H*.72);
  hg.addColorStop(0,`rgba(${atmoRGB},0)`);
  hg.addColorStop(0.6,`rgba(${atmoRGB},${atmoStr})`);
  hg.addColorStop(1,`rgba(${atmoRGB},${atmoStr*.5})`);
  ctx2.fillStyle=hg;ctx2.fillRect(0,H*.35,W,H*.37);

  // ── Terrain ──────────────────────────────────────────────────
  const horizonY=H*.66;

  // Far mountains (parallax layer 1 — moves slower)
  ctx2.beginPath();ctx2.moveTo(0,H);
  for(let x=0;x<=W;x+=4){
    const n=fbm((x+scrollX*.25)/300,0.5,seed+200,4);
    const ridge=ridged((x+scrollX*.25)/250,0.3,seed+201,3);
    ctx2.lineTo(x, horizonY - n*H*.2 - ridge*H*.12);
  }
  ctx2.lineTo(W,H);ctx2.closePath();
  // Far mountain colour based on stage
  const farMtnCols={
    lava:'#1a0800',magma:'#120400',cooling:'#141420',rocky:'#1c1812',
    arid:'#2a1a08',desert:'#2e1e0a',ice:'#1a2840',ocean:'#0c1e38',
    life:'#0e1c18',advanced:'#0c1820',gas:'#1a1218'};
  ctx2.fillStyle=farMtnCols[stage]||'#141414';ctx2.fill();

  // Mid terrain (parallax layer 2)
  ctx2.beginPath();ctx2.moveTo(0,H);
  const midHorizY=horizonY+H*.04;
  for(let x=0;x<=W;x+=3){
    const n=wfbm!==undefined?wfbm((x+scrollX*.6)/200,0,seed+100,4,0.9):fbm((x+scrollX*.6)/200,0,seed+100,4);
    const ridge=ridged((x+scrollX*.6)/180,0.2,seed+101,4);
    let ty;
    if(stage==='ocean'||stage==='life'||stage==='advanced'){
      // Islands with flat sea-level regions
      const isLand=n>0.52;
      ty=isLand ? midHorizY - (n-0.52)*H*1.8 - ridge*H*.15 : midHorizY+H*.06;
    } else if(stage==='lava'||stage==='magma'){
      ty=midHorizY - n*H*.28 - ridge*H*.08 + Math.sin(x*.04+svTime*1.2)*H*.012;
    } else if(stage==='ice'){
      ty=midHorizY - n*H*.22 - ridge*H*.18; // sharp icy peaks
    } else if(stage==='arid'||stage==='desert'){
      // Rolling dune shapes
      const dune=Math.sin(x*.018+scrollX*.003)*0.5+0.5;
      ty=midHorizY - n*H*.18 - dune*H*.1;
    } else {
      ty=midHorizY - n*H*.25 - ridge*H*.12;
    }
    ctx2.lineTo(x, ty);
  }
  ctx2.lineTo(W,H);ctx2.closePath();
  // Mid terrain gradient fill
  const midFills={
    lava:    ['#1e0800','#3a1400'],  magma:   ['#160400','#2e0c00'],
    cooling: ['#181825','#282838'], rocky:   ['#201a12','#38301e'],
    arid:    ['#3a2408','#5a3c18'], desert:  ['#3e2808','#5e3e18'],
    ice:     ['#182a48','#2a4068'], ocean:   ['#0a1e3c','#142e58'],
    life:    ['#0e1e12','#182e1e'], advanced:['#0a1828','#12243a'],
    gas:     ['#1e1614','#302420'],
    freezing:['#142030','#1e3048'],
    frozen:  ['#0e1828','#182840'],
  };
  const mf=midFills[stage]||midFills.rocky;
  const mtg=ctx2.createLinearGradient(0,midHorizY,0,H);
  mtg.addColorStop(0,mf[1]);mtg.addColorStop(1,mf[0]);
  ctx2.fillStyle=mtg;ctx2.fill();

  // ── Stage-specific surface features ─────────────────────────

  // Lava / Magma — glowing cracks and lava pools
  if(stage==='lava'||stage==='magma'){
    for(let i=0;i<8;i++){
      const lx=((i*157+scrollX*.35)%W+W)%W;
      const n=fbm(lx/110,1.5+i*.3,seed+i,3);
      const lavaY=midHorizY - n*H*.25;
      // Crack line
      ctx2.beginPath();ctx2.moveTo(lx,lavaY);
      ctx2.bezierCurveTo(lx+n*25,lavaY+H*.08,lx-n*18,lavaY+H*.15,lx+n*8,H);
      const lavaW=1.5+n*5;
      const lavaAlpha=0.55+n*.3;
      ctx2.strokeStyle=`rgba(255,${Math.floor(50+n*130)},0,${lavaAlpha})`;
      ctx2.lineWidth=lavaW;ctx2.stroke();
      // Glow around crack
      const lcg=ctx2.createRadialGradient(lx,lavaY+H*.04,0,lx,lavaY+H*.04,20+n*28);
      lcg.addColorStop(0,`rgba(255,120,0,0.35)`);lcg.addColorStop(1,'transparent');
      ctx2.beginPath();ctx2.arc(lx,lavaY+H*.04,20+n*28,0,Math.PI*2);
      ctx2.fillStyle=lcg;ctx2.fill();
    }
    // Ambient lava glow on horizon
    const lavaglow=ctx2.createLinearGradient(0,H*.55,0,H*.75);
    lavaglow.addColorStop(0,'transparent');lavaglow.addColorStop(1,'rgba(255,60,0,0.12)');
    ctx2.fillStyle=lavaglow;ctx2.fillRect(0,H*.55,W,H*.2);
  }

  // Ice — crevasse lines and ice crystals
  if(stage==='ice'){
    for(let i=0;i<12;i++){
      const ix=((i*211+scrollX*.2)%W+W)%W;
      const iy=midHorizY - fbm(ix/90,0,seed+i*17,3)*H*.2;
      // Crevasse
      ctx2.beginPath();ctx2.moveTo(ix,iy);
      ctx2.lineTo(ix+(Math.random()-.5)*20,iy+H*.12);
      ctx2.strokeStyle=`rgba(80,140,220,${0.25+Math.random()*.25})`;
      ctx2.lineWidth=.8+Math.random()*1.5;ctx2.stroke();
    }
    // Sparkle on ice surface
    for(let i=0;i<30;i++){
      const sx2=((i*317+scrollX*.1)%W),sy2=midHorizY-fbm(sx2/80,0,seed+i*7,2)*H*.2;
      ctx2.fillStyle=`rgba(200,230,255,${0.3+Math.random()*.5})`;
      ctx2.beginPath();ctx2.arc(sx2,sy2,1,0,Math.PI*2);ctx2.fill();
    }
  }

  // Ocean / Life / Advanced — water with foam and depth
  if(stage==='ocean'||stage==='life'||stage==='advanced'){
    const waterY=midHorizY+H*.065;
    // Deep water colour
    const deepWg=ctx2.createLinearGradient(0,waterY,0,waterY+H*.15);
    deepWg.addColorStop(0,stage==='ocean'?'#1a4878':'#0e3858');
    deepWg.addColorStop(1,stage==='ocean'?'#0a2848':'#071e38');
    ctx2.fillStyle=deepWg;ctx2.fillRect(0,waterY,W,H-waterY);
    // Wave layers
    for(let wi=0;wi<6;wi++){
      const wy=waterY+wi*5;
      const amp=4+wi*1.5;const freq=0.03+wi*.005;
      ctx2.beginPath();ctx2.moveTo(0,wy);
      for(let x=0;x<=W;x+=5)ctx2.lineTo(x,wy+Math.sin(x*freq+svTime*(2.5-wi*.3))*amp);
      const wAlpha=0.22-wi*.03;
      ctx2.strokeStyle=`rgba(120,200,255,${wAlpha})`;ctx2.lineWidth=1.2;ctx2.stroke();
    }
    // Foam crests
    for(let i=0;i<20;i++){
      const fx=((i*277+scrollX*.15)%W);
      const fy=waterY+Math.sin(fx*.035+svTime*2.2)*5;
      ctx2.fillStyle='rgba(200,235,255,0.2)';
      ctx2.beginPath();ctx2.ellipse(fx,fy,9+Math.random()*6,1.8,0,0,Math.PI*2);ctx2.fill();
    }
  }

  // Freezing / Frozen — spreading ice sheets and frost breath
  if(stage==='freezing'||stage==='frozen'){
    const fp=surfacePlanet.freezeProgress||0;
    // Ice fog at horizon
    const iceFog=ctx2.createLinearGradient(0,midHorizY-H*.05,0,midHorizY+H*.12);
    iceFog.addColorStop(0,'transparent');
    iceFog.addColorStop(.5,`rgba(160,210,255,${stage==='frozen'?0.18:0.09*fp})`);
    iceFog.addColorStop(1,'transparent');
    ctx2.fillStyle=iceFog;ctx2.fillRect(0,midHorizY-H*.05,W,H*.17);
    // Snowfall
    const snowCount=stage==='frozen'?60:Math.floor(40*fp);
    for(let i=0;i<snowCount;i++){
      const sx2=((i*317+scrollX*(.3+i*.01))%W+W)%W;
      const sy2=((i*211+svTime*18*(0.5+i*.008))%(H*.72))+H*.05;
      ctx2.fillStyle=`rgba(220,235,255,${0.4+Math.random()*.4})`;
      ctx2.beginPath();ctx2.arc(sx2,sy2,.5+Math.random()*.8,0,Math.PI*2);ctx2.fill();
    }
    // Ice surface cracks
    for(let i=0;i<8;i++){
      const ix=((i*233+scrollX*.18)%W+W)%W;
      ctx2.beginPath();ctx2.moveTo(ix,midHorizY+H*.01);
      ctx2.lineTo(ix+Math.sin(i*1.7)*25,midHorizY+H*.07);
      ctx2.strokeStyle=`rgba(80,150,220,${stage==='frozen'?0.35:0.2*fp})`;
      ctx2.lineWidth=.7+fp*.5;ctx2.stroke();
    }
    // Frozen ground sheen
    if(stage==='frozen'){
      const sheen=ctx2.createLinearGradient(0,midHorizY,0,H);
      sheen.addColorStop(0,'rgba(180,220,255,0.12)');sheen.addColorStop(1,'rgba(100,160,220,0.05)');
      ctx2.fillStyle=sheen;ctx2.fillRect(0,midHorizY,W,H-midHorizY);
    }
  }

  // Desert — distant dust haze and dune wind lines
  if(stage==='desert'||stage==='arid'){
    // Dust haze near horizon
    const dustHaze=ctx2.createLinearGradient(0,horizonY-H*.08,0,horizonY+H*.05);
    dustHaze.addColorStop(0,'transparent');
    dustHaze.addColorStop(0.5,'rgba(180,140,80,0.12)');
    dustHaze.addColorStop(1,'transparent');
    ctx2.fillStyle=dustHaze;ctx2.fillRect(0,horizonY-H*.08,W,H*.13);
    // Wind-blown sand streaks
    for(let i=0;i<15;i++){
      const sy2=midHorizY+i*H*.02+Math.sin(i)*H*.01;
      const sx2=((i*337+scrollX*1.2)%W);
      ctx2.beginPath();ctx2.moveTo(sx2,sy2);ctx2.lineTo(sx2-60-i*4,sy2+1);
      ctx2.strokeStyle=`rgba(200,165,80,${0.06+i*.004})`;ctx2.lineWidth=.6;ctx2.stroke();
    }
  }

  // Clouds
  if(stage==='life'||stage==='advanced'||stage==='ocean'||stage==='arid'||stage==='desert'){
    const cloudLayers=stage==='life'?3:2;
    for(let layer=0;layer<cloudLayers;layer++){
      for(let i=0;i<8-layer*2;i++){
        const cx2=((i*(W/(5-layer))+scrollX*(.3+layer*.2))%(W+100)-50);
        const cy2=H*(.15+layer*.07)+Math.sin(svTime*.25+i+layer)*H*.015;
        const cr=55+i*14+layer*10;
        const cBright=stage==='life'?0.16:0.09;
        const cg3=ctx2.createRadialGradient(cx2,cy2,0,cx2,cy2,cr);
        cg3.addColorStop(0,`rgba(255,255,255,${cBright})`);
        cg3.addColorStop(0.5,`rgba(240,248,255,${cBright*.5})`);
        cg3.addColorStop(1,'transparent');
        ctx2.beginPath();ctx2.ellipse(cx2,cy2,cr,cr*.35+layer*5,(Math.sin(i)*0.15),0,Math.PI*2);
        ctx2.fillStyle=cg3;ctx2.fill();
      }
    }
  }

  // City lights (advanced)
  if(stage==='advanced'){
    for(let i=0;i<35;i++){
      const clx=((i*347+scrollX*.05)%W);
      const cly=midHorizY - fbm(clx/100,3,seed+i,2)*H*.22;
      // Point light
      ctx2.fillStyle='rgba(255,215,100,0.9)';ctx2.beginPath();ctx2.arc(clx,cly,1.8,0,Math.PI*2);ctx2.fill();
      // Street grid dots
      if(i%3===0){
        for(let gi=1;gi<=3;gi++){
          ctx2.fillStyle=`rgba(255,200,80,${0.4/gi})`;
          ctx2.beginPath();ctx2.arc(clx+gi*7,cly,1,0,Math.PI*2);ctx2.fill();
          ctx2.beginPath();ctx2.arc(clx-gi*7,cly,1,0,Math.PI*2);ctx2.fill();
        }
      }
      // Upward light glow
      const lcg=ctx2.createRadialGradient(clx,cly,0,clx,cly,30);
      lcg.addColorStop(0,'rgba(255,200,80,0.14)');lcg.addColorStop(1,'transparent');
      ctx2.beginPath();ctx2.arc(clx,cly,30,0,Math.PI*2);ctx2.fillStyle=lcg;ctx2.fill();
    }
  }

  // ── Atmosphere particles ─────────────────────────────────────
  ctx2.globalAlpha=.12;
  for(let i=0;i<18;i++){
    const px2=((i*317+svTime*8)%W),py2=H*.06+i*H*.016;
    ctx2.fillStyle=`rgba(${atmoRGB},1)`;
    ctx2.beginPath();ctx2.arc(px2,py2,1.2,0,Math.PI*2);ctx2.fill();
  }
  ctx2.globalAlpha=1;

  // ── HUD ──────────────────────────────────────────────────────
  ctx2.font='bold 12px "Share Tech Mono"';ctx2.fillStyle='rgba(0,212,255,0.92)';ctx2.textAlign='left';
  ctx2.fillText(`SURFACE: ${planet.name}`,12,24);
  ctx2.font='9px "Share Tech Mono"';ctx2.fillStyle='rgba(170,195,220,0.75)';
  ctx2.fillText(`Stage: ${(EVO[stage]?.label||stage)}  |  ${Math.round(planet.tempK||0)}K  |  Zone: ${planet.zone||'unknown'}`,12,40);
  let hudY=56;
  if(planet.hasLife){ctx2.fillStyle='rgba(0,255,136,0.85)';ctx2.fillText('🌱 Life present',12,hudY);hudY+=16;}
  const civ2=civilizations.find(c=>c.planetId===planet.id&&!c.extinct);
  if(civ2){ctx2.fillStyle=civ2.color;ctx2.fillText(`🧠 ${civ2.name} — ${CIV_STAGES[civ2.stageIdx]||'?'}`,12,hudY);hudY+=16;}
  if(planet.cooldownTimer>0){ctx2.fillStyle='rgba(255,80,0,0.85)';ctx2.fillText(`🔥 Post-collision: ${Math.round(planet.cooldownTimer)}s`,12,hudY);}


  // ── Surface-view asteroid fly-bys ───────────────────────────
  updateSVAsteroids();
  for(const a of svAsteroids){
    const sx=a.x*W, sy=a.y*H;
    const r=Math.max(1.2, a.r * (0.4 + a.closeness*1.2));
    // Draw trail (glowing streak)
    if(a.trail.length>1){
      for(let ti=1;ti<a.trail.length;ti++){
        const t0=a.trail[ti-1], t1=a.trail[ti];
        const prog=ti/a.trail.length;
        ctx2.beginPath();
        ctx2.moveTo(t0.x*W,t0.y*H);ctx2.lineTo(t1.x*W,t1.y*H);
        const trailColor=a.isWater?`rgba(100,180,255,${prog*.55})`:`rgba(255,200,120,${prog*.5})`;
        ctx2.strokeStyle=trailColor;
        ctx2.lineWidth=r*prog*.6;ctx2.stroke();
      }
    }
    // Glow aura
    const glowR=r*3.5;
    const gg=ctx2.createRadialGradient(sx,sy,0,sx,sy,glowR);
    gg.addColorStop(0, a.isWater?'rgba(120,200,255,0.45)':'rgba(255,180,80,0.4)');
    gg.addColorStop(1,'transparent');
    ctx2.beginPath();ctx2.arc(sx,sy,glowR,0,Math.PI*2);ctx2.fillStyle=gg;ctx2.fill();
    // Rock body
    ctx2.save();ctx2.translate(sx,sy);ctx2.rotate(a.x*Math.PI*8+svTime*2);
    ctx2.beginPath();
    const pts=6;
    for(let pi=0;pi<pts;pi++){
      const ang=(pi/pts)*Math.PI*2;
      const rr=r*(0.65+Math.sin(pi*2.3+a.srcId*.5)*.32);
      pi===0?ctx2.moveTo(Math.cos(ang)*rr,Math.sin(ang)*rr):ctx2.lineTo(Math.cos(ang)*rr,Math.sin(ang)*rr);
    }
    ctx2.closePath();
    ctx2.fillStyle=a.isWater?'#3a5a8a':'#6a5a4a';
    ctx2.strokeStyle=a.isWater?'#6688bb':'#998877';
    ctx2.lineWidth=.5;ctx2.fill();ctx2.stroke();
    ctx2.restore();
    // "DANGER" label for big close ones
    if(a.closeness>0.6&&r>5){
      ctx2.font='bold 9px "Share Tech Mono"';
      ctx2.fillStyle='rgba(255,80,60,0.85)';
      ctx2.textAlign='center';
      ctx2.fillText('⚠ INCOMING',sx,sy-r-8);
    }
  }
  // Impact flash
  if(svImpactFlash){
    svImpactFlash.age+=0.016;
    const ft=svImpactFlash.age/0.6;
    if(ft<1){
      const fx=svImpactFlash.x*W, fy=svImpactFlash.y*H;
      const fr=svImpactFlash.r*(6+ft*12);
      const ifg=ctx2.createRadialGradient(fx,fy,0,fx,fy,fr);
      ifg.addColorStop(0,`rgba(255,220,100,${(1-ft)*.9})`);
      ifg.addColorStop(.4,`rgba(255,100,20,${(1-ft)*.5})`);
      ifg.addColorStop(1,'transparent');
      ctx2.beginPath();ctx2.arc(fx,fy,fr,0,Math.PI*2);ctx2.fillStyle=ifg;ctx2.fill();
    } else svImpactFlash=null;
  }

  // ── Asteroid Flybys ─────────────────────────────────────────
  svAsteroidTimer-=0.016;
  if(svAsteroidTimer<=0){
    svAsteroidTimer=1.5+Math.random()*3.5;
    if(surfacePlanet){
      const nearAsts=bodies.filter(b=>b.type==='asteroid'&&
        Math.hypot(b.x-surfacePlanet.x,b.y-surfacePlanet.y)<(surfacePlanet.radius*8+80));
      if(nearAsts.length>0||Math.random()<0.06){
        const fromLeft=Math.random()<0.5;
        const ast=nearAsts.length>0?nearAsts[Math.floor(Math.random()*nearAsts.length)]:null;
        const size=ast?(Math.max(2,ast.radius*0.8)):(2.5+Math.random()*7);
        const isClose=nearAsts.length>0&&Math.random()<0.55;
        svAsteroids.push({
          x:fromLeft?-size*4:W+size*4,
          y:H*(0.18+Math.random()*0.44),
          vx:(fromLeft?1:-1)*(W/(2.2+Math.random()*2.2)),
          vy:(Math.random()-0.5)*(H*0.07),
          size,rot:Math.random()*Math.PI*2,
          rotSpd:(Math.random()-0.5)*2.8,
          isClose,isWater:ast?.isWater||false,
          trail:[],age:0,
          proximity:isClose?0.75+Math.random()*0.25:0.15+Math.random()*0.5,
          soundPlayed:false,impacted:false,
        });
      }
    }
  }
  // Draw & update flyby asteroids
  for(let ai=svAsteroids.length-1;ai>=0;ai--){
    const a=svAsteroids[ai];
    a.x+=a.vx*0.016;a.y+=a.vy*0.016;a.rot+=a.rotSpd*0.016;a.age+=0.016;
    a.trail.push({x:a.x,y:a.y});
    if(a.trail.length>20)a.trail.shift();
    // Play flyby whoosh once on screen entry
    if(!a.soundPlayed&&a.x>-a.size*2&&a.x<W+a.size*2){
      a.soundPlayed=true;
      sndAsteroidFlyby(a.proximity);
    }
    // Impact flash if very close and near centre
    if(a.isClose&&!a.impacted&&Math.abs(a.x-W*.5)<W*.15&&Math.abs(a.y-H*.5)<H*.3){
      a.impacted=true;
      sndAsteroidImpact();
      ctx2.save();ctx2.globalAlpha=0.4;ctx2.fillStyle='rgba(255,200,100,1)';ctx2.fillRect(0,0,W,H);ctx2.restore();
    }
    // Remove when off screen
    if(a.x<-W*.4||a.x>W*1.4||a.age>10){svAsteroids.splice(ai,1);continue;}
    // Trail
    if(a.trail.length>2){
      ctx2.save();
      for(let ti=1;ti<a.trail.length;ti++){
        const alpha=(ti/a.trail.length)*0.22*a.proximity;
        ctx2.strokeStyle=a.isWater?`rgba(80,160,255,${alpha})`:`rgba(200,175,130,${alpha})`;
        ctx2.lineWidth=Math.max(0.3,a.size*0.25*(ti/a.trail.length));
        ctx2.beginPath();ctx2.moveTo(a.trail[ti-1].x,a.trail[ti-1].y);ctx2.lineTo(a.trail[ti].x,a.trail[ti].y);ctx2.stroke();
      }
      ctx2.restore();
    }
    // Motion smear
    const smear=Math.abs(a.vx)*0.016;
    if(smear>4){
      const dir=Math.atan2(a.vy,a.vx);
      ctx2.save();ctx2.translate(a.x,a.y);ctx2.rotate(dir);
      const sg2=ctx2.createLinearGradient(-smear,0,0,0);
      sg2.addColorStop(0,'transparent');sg2.addColorStop(1,`rgba(210,190,155,${a.proximity*0.4})`);
      ctx2.fillStyle=sg2;ctx2.fillRect(-smear,-a.size*.35,smear,a.size*.7);ctx2.restore();
    }
    // Glow
    if(a.proximity>0.55){
      const grd=ctx2.createRadialGradient(a.x,a.y,a.size*.8,a.x,a.y,a.size*3.5);
      grd.addColorStop(0,a.isWater?'rgba(60,140,255,0.28)':'rgba(220,170,80,0.22)');
      grd.addColorStop(1,'transparent');
      ctx2.beginPath();ctx2.arc(a.x,a.y,a.size*3.5,0,Math.PI*2);ctx2.fillStyle=grd;ctx2.fill();
    }
    // Rock polygon
    ctx2.save();ctx2.translate(a.x,a.y);ctx2.rotate(a.rot);
    const verts=5+Math.floor(a.size/2.5);
    ctx2.beginPath();
    for(let vi=0;vi<=verts;vi++){
      const ang=(vi/verts)*Math.PI*2;
      const sv2=(vi*7+Math.floor(a.size*4))%19;
      const r=a.size*(0.62+((sv2*.19)%0.38));
      vi===0?ctx2.moveTo(Math.cos(ang)*r,Math.sin(ang)*r):ctx2.lineTo(Math.cos(ang)*r,Math.sin(ang)*r);
    }
    ctx2.closePath();
    const rg=ctx2.createRadialGradient(-a.size*.35,-a.size*.35,0,0,0,a.size*1.3);
    if(a.isWater){rg.addColorStop(0,'#6888bb');rg.addColorStop(0.5,'#3a5080');rg.addColorStop(1,'#1e2e48');}
    else{rg.addColorStop(0,'#b0a088');rg.addColorStop(0.5,'#706050');rg.addColorStop(1,'#302820');}
    ctx2.fillStyle=rg;ctx2.fill();
    ctx2.strokeStyle=a.isWater?'#4a6a9a':'#7a6a58';ctx2.lineWidth=0.7;ctx2.stroke();
    // Surface detail cracks
    for(let di=0;di<3;di++){
      const da=(di/3)*Math.PI*2+a.rot*0.5;const dl=a.size*(0.4+di*.1);
      ctx2.beginPath();ctx2.moveTo(0,0);ctx2.lineTo(Math.cos(da)*dl,Math.sin(da)*dl);
      ctx2.strokeStyle='rgba(0,0,0,0.2)';ctx2.lineWidth=0.5;ctx2.stroke();
    }
    ctx2.restore();
    // HUD label
    if(a.proximity>0.6&&a.x>W*.08&&a.x<W*.92){
      ctx2.save();ctx2.font='bold 9px "Share Tech Mono"';ctx2.textAlign='center';
      const lc=a.isClose?'rgba(255,100,50,0.92)':a.isWater?'rgba(80,200,255,0.85)':'rgba(220,180,100,0.75)';
      ctx2.fillStyle=lc;
      ctx2.fillText(a.isClose?'⚠ CLOSE APPROACH':'ASTEROID FLYBY',a.x,a.y-a.size-10);
      if(a.isWater)ctx2.fillText('💧 WATER ASTEROID',a.x,a.y-a.size-22);
      ctx2.restore();
    }
  }

  requestAnimationFrame(svLoop);
}


// ── SPAWN ─────────────────────────────────────────────────────────────────────────
function spawnAt(wx,wy){
  if(!spawnT)return;
  if(spawnT==='comet'){spawnComet(wx,wy);return;}
  if(spawnT==='proto'){spawnProtoDisk(wx,wy);return;}
  const ms=parseFloat(document.getElementById('sm').value);
  const rs=parseFloat(document.getElementById('sr2').value);
  gravMult=parseFloat(document.getElementById('sg2').value);
  if(SDEFS[spawnT]){
    if(CNT.s>=4){ntf('Max 4 stars!','w');return;}
    const def=SDEFS[spawnT];const sc2=bodies.filter(b=>b.type==='star').length;
    const b={id:nextId++,type:'star',sub:spawnT,
      name:def.name+' '+String.fromCharCode(65+sc2),x:wx,y:wy,vx:0,vy:0,
      mass:def.mass*ms,radius:def.radius*rs,color:def.color,glow:def.glow,
      lum:def.lum,tempK:def.tempK,def,age:0,moons:[],rings:0,angle:Math.random()*Math.PI*2,
      _oA:0,_oR:0,_oSpd:0,_multi:false,lifespan:99999,
      supernovaTriggered:false,canSupernova:def.canSupernova,
      magField:{strength:0.6,radius:def.radius*3}};
    bodies.push(b);CNT.s++;setupMultiStar();
    log(`${b.name} spawned`,'n');ntf(`${b.name} formed!`);sndStarSpawn();updCnt();sel(b.id);return;
  }
  if(PDEFS[spawnT]){
    if(CNT.p>=300){ntf('Max 300 planets!','w');return;}
    const def=PDEFS[spawnT];const star=getNearStar(wx,wy);
    const ecc=orbitSh==='oval'?parseFloat(document.getElementById('se')||{value:.3}).value:.0;
    let vx=0,vy=0,orbitR=0,angle=0;
    if(star){const dx=wx-star.x,dy=wy-star.y;orbitR=Math.hypot(dx,dy);angle=Math.atan2(dy,dx);
      if(orbitR>1){const v=Math.sqrt(star.mass*gravMult*0.0002/orbitR)*60;vx=-Math.sin(angle)*v;vy=Math.cos(angle)*v;}}
    const oSpd=orbitR>1?Math.sqrt((star?.mass||100)*gravMult*0.0002/orbitR)*60/orbitR:0;
    const b={id:nextId++,type:'planet',sub:def.sub,pt:spawnT,
      name:def.name+' '+(CNT.p+1),x:wx,y:wy,vx,vy,
      mass:def.mass*ms*10,radius:def.radius*rs,colors:[...def.colors],color:def.colors[0],
      orbitAngle:angle,orbitRadius:orbitR,orbitA:orbitR,orbitB:orbitR*(1-ecc*.7),orbitEcc:ecc,orbitSpd:oSpd,
      orbitStar:star?star.id:null,lockedOrbit:!!star,
      age:0,moons:[],rings:0,hasLife:false,hadWater:false,atmo:def.sub==='gas'?1:0.2,
      strippedGas:false,zone:'unknown',noiseOff:Math.random()*1000,cloudAngle:0,shapeY:1,
      roughness:0.5,tempK:0,evoStage:spawnT,evoProgress:0,civilizationId:null,
      magField:null,tidal:{sx:1,sy:1},cooldownTimer:0,waterFloodProgress:0,
      axialTilt:(()=>{const v=document.getElementById('stilt');return v?parseFloat(v.value)*Math.PI/180:0;})(),
      spinSpeed:(()=>{const v=document.getElementById('sspin'),d=document.getElementById('btnSpinDir');return v?parseFloat(v.value)*(d&&d.dataset.dir==='ccw'?-1:1):1;})(),
      spinAngle:0};
    bodies.push(b);CNT.p++;
    log(`${b.name} spawned`,'n');ntf(`${b.name}!`);sndSpawn();updCnt();sel(b.id);return;
  }
  if(spawnT==='blackhole'||spawnT==='whitehole'){
    if(CNT.h>=3){ntf('Max 3 holes!','w');return;}
    const r=(spawnT==='blackhole'?22:16)*rs;
    const b={id:nextId++,type:'hole',sub:spawnT==='blackhole'?'black':'white',
      name:spawnT==='blackhole'?'Black Hole':'White Hole',x:wx,y:wy,vx:0,vy:0,
      mass:(spawnT==='blackhole'?800:400)*ms*200,baseMass:(spawnT==='blackhole'?800:400)*ms*200,
      radius:r,baseR:r,age:0,angle:0,repulse:spawnT==='whitehole',accretionParticles:genAccretion(wx,wy,r)};
    bodies.push(b);CNT.h++;log(`${b.name} spawned`,'w');ntf(`${b.name}!`,'w');updCnt();sel(b.id);return;
  }
  if(spawnT==='belt'){
    if(CNT.b>=15)return;const star=getNearStar(wx,wy);
    const bx=star?star.x:wx,by=star?star.y:wy;
    const radius=star?Math.max(35,Math.hypot(wx-star.x,wy-star.y)):200;
    const b={id:nextId++,type:'belt',name:'Belt '+(CNT.b+1),x:bx,y:by,radius,width:32,
      starId:star?.id,particles:genBelt(bx,by,radius),age:0,waterRich:true};
    bodies.push(b);CNT.b++;log(`${b.name} spawned`,'n');ntf(`Belt spawned!`);updCnt();return;
  }
  if(spawnT==='nebula'||spawnT==='nebula-stellar'){
    const nb=genNebula(wx,wy,spawnT==='nebula-stellar'?'stellar':'diffuse');
    nebulae.push(nb);log(`Nebula spawned`,'n');ntf(`🌫 Nebula!`);return;
  }
  if(spawnT==='ast-n'||spawnT==='ast-w'){
    const star=getNearStar(wx,wy);let vx=0,vy=0;
    if(star){const dx=wx-star.x,dy=wy-star.y,r2=Math.hypot(dx,dy),a=Math.atan2(dy,dx);
      if(r2>1){const v=Math.sqrt(star.mass*gravMult*0.0002/r2)*60*(0.5+Math.random()*.9);vx=-Math.sin(a)*v;vy=Math.cos(a)*v;}}
    const b={id:nextId++,type:'asteroid',name:'Ast.'+nextId,isWater:spawnT==='ast-w',
      x:wx,y:wy,vx,vy,mass:.05,radius:2+Math.random()*4,
      orbitStar:star?.id,age:0,angle:Math.random()*Math.PI*2,rotSpd:(Math.random()-.5)*.1,tidal:{sx:1,sy:1}};
    bodies.push(b);CNT.a++;log(`Asteroid spawned`,'n');ntf(`Asteroid!`);updCnt();return;
  }
}

// ── SELECTION ─────────────────────────────────────────────────
function sel(id){
  selectedId=id;const body=bodies.find(b=>b.id===id);
  const ip=document.getElementById('ip'),iph=document.getElementById('iph'),mre=document.getElementById('mre');
  if(!body){ip.style.display='none';iph.style.display='block';mre.style.display='none';return;}
  ip.style.display='block';iph.style.display='none';
  mre.style.display=body.type==='planet'?'block':'none';
  document.getElementById('iname').textContent=body.name;
  document.getElementById('iname').style.color=body.type==='star'?'var(--gold)':body.type==='hole'?'var(--purple)':body.hasLife?'var(--green)':'var(--accent)';
  const rows=[];
  if(body.type==='star'){rows.push(['Type',body.sub.replace(/-/g,' ')]);rows.push(['Temp',body.tempK.toLocaleString()+'K']);rows.push(['Lum',body.lum]);rows.push(['Age',Math.floor(body.age||0)+'yr']);rows.push(['Supernova',body.canSupernova?(simTime>=SUPERNOVA_MIN_YR?'NOW POSSIBLE':'need 50k yr'):'N/A']);}
  else if(body.type==='planet'){const star=bodies.find(s=>s.id===body.orbitStar);const civ=civilizations.find(c=>c.planetId===body.id&&!c.extinct);rows.push(['Stage',EVO[body.evoStage]?.label||body.evoStage]);rows.push(['Zone',(body.zone||'?').toUpperCase()]);rows.push(['Temp',Math.round(body.tempK)+'K']);rows.push(['Atmo',(body.atmo||0).toFixed(2)]);rows.push(['Mass',body.mass.toFixed(1)]);rows.push(['Moons',body.moons.length+'/50']);rows.push(['Rings',body.rings+'/5']);rows.push(['Life',body.hasLife?'🌱 YES':'No']);rows.push(['Civ',civ?civ.name:'None']);if(body.cooldownTimer>0)rows.push(['Cooldown',Math.round(body.cooldownTimer)+'s']);if(star)rows.push(['Dist',Math.round(Math.hypot(body.x-star.x,body.y-star.y))+'AU']);
    document.getElementById('lmn').textContent=body.moons.length;document.getElementById('lrng').textContent=body.rings;}
  else if(body.type==='hole'){rows.push(['Type',body.sub.toUpperCase()]);rows.push(['Mass',body.mass.toFixed(0)]);rows.push(['Mode',body.repulse?'REPEL':'ATTRACT']);}
  else if(body.type==='belt'){rows.push(['Radius',Math.round(body.radius)+'AU']);rows.push(['Water',body.waterRich?'YES':'No']);}
  document.getElementById('irows').innerHTML=rows.map(([k,v])=>`<div class="ir"><span class="ik">${k}</span><span>${v}</span></div>`).join('');
}
function delSel(){
  if(!selectedId)return;const idx=bodies.findIndex(b=>b.id===selectedId);if(idx===-1)return;
  const b=bodies[idx];bodies.splice(idx,1);
  if(b.type==='star'){CNT.s--;setupMultiStar();}
  else if(b.type==='planet'){CNT.p--;civilizations.filter(c=>c.planetId===b.id).forEach(c=>c.extinct=true);}
  else if(b.type==='hole')CNT.h--;
  else if(b.type==='belt')CNT.b--;
  else if(b.type==='asteroid')CNT.a--;
  log(`${b.name} deleted`,'n');sel(null);updCnt();
}
function adjMoons(d){const b=bodies.find(b=>b.id===selectedId&&b.type==='planet');if(!b)return;if(d>0&&b.moons.length<50)b.moons.push({angle:Math.random()*Math.PI*2,speed:(.018+Math.random()*.045)*(Math.random()>.5?1:-1),dist:b.radius*2.5+b.moons.length*14,radius:1.5+Math.random()*2.5});else if(d<0&&b.moons.length>0)b.moons.pop();document.getElementById('lmn').textContent=b.moons.length;}
function adjRings(d){const b=bodies.find(b=>b.id===selectedId&&b.type==='planet');if(!b)return;b.rings=Math.max(0,Math.min(5,b.rings+d));document.getElementById('lrng').textContent=b.rings;}

// ── CONTROLS ──────────────────────────────────────────────────
document.getElementById('btnP').addEventListener('click',()=>{paused=!paused;document.getElementById('btnP').textContent=paused?'▶':'⏸';});
function setSpd(s){simSpd=s;document.getElementById('spd').textContent=s+'×';}
function toggleGrav(){gravSim=!gravSim;document.getElementById('btnGrav').classList.toggle('on',gravSim);ntf('Gravity '+(gravSim?'ON':'OFF'));}
function toggleNeb(){showNebulae=!showNebulae;document.getElementById('btnNeb').classList.toggle('on',showNebulae);}
function toggleMag(){showMagFields=!showMagFields;document.getElementById('btnMag').classList.toggle('on',showMagFields);}
function setOrb(t,btn){orbitSh=t;document.querySelectorAll('#ob-c,#ob-o').forEach(b=>b.classList.remove('ac'));btn.classList.add('ac');}
function setSp(t,btn){spawnT=t;document.querySelectorAll('.sb').forEach(b=>b.classList.remove('active'));btn?.classList.add('active');const L={'star-red-dwarf':'RED DWARF','star-yellow':'YELLOW STAR','star-blue-giant':'BLUE GIANT','star-white-dwarf':'WHITE DWARF',rocky:'ROCKY',gas:'GAS GIANT',ice:'ICE GIANT',lava:'LAVA',ocean:'OCEAN',desert:'DESERT',blackhole:'BLACK HOLE',whitehole:'WHITE HOLE',belt:'BELT','ast-n':'ASTEROID','ast-w':'WATER AST.',nebula:'NEBULA','nebula-stellar':'STELLAR NEB'};document.getElementById('sml').textContent='SPAWN: '+(L[t]||t);}
function clearAll(){bodies.length=0;civilizations.length=0;ships.length=0;nebulae.length=0;galaxies.length=0;binaryPairs.length=0;waterFloodAnims.length=0;solarEvents.length=0;CNT.p=0;CNT.s=0;CNT.h=0;CNT.b=0;CNT.a=0;selectedId=null;nextId=1;simTime=0;Object.keys(TEX).forEach(k=>delete TEX[k]);sel(null);updCnt();document.getElementById('el').innerHTML='<div class="ei en">— cleared —</div>';ntf('Cleared!');}
function updCnt(){document.getElementById('cp').textContent=CNT.p;document.getElementById('cs').textContent=CNT.s;document.getElementById('ca').textContent=CNT.a;document.getElementById('cg').textContent=nebulae.length;document.getElementById('csh').textContent=ships.length;document.getElementById('ccv').textContent=civilizations.filter(c=>!c.extinct).length;document.getElementById('ctot').textContent=bodies.length+ships.length;}
function log(msg,type='n'){const el=document.getElementById('el');const d=document.createElement('div');d.className=`ei e${type}`;d.textContent=`[${Math.floor(simTime)}yr] ${msg}`;el.insertBefore(d,el.firstChild);if(el.children.length>60)el.removeChild(el.lastChild);}
function ntf(msg,type=''){const c=document.getElementById('ntf');const d=document.createElement('div');d.className=`ntf ${type==='l'?'lf':type==='w'?'wn':type==='sp'?'sp':''}`;d.textContent=msg;c.appendChild(d);setTimeout(()=>d.remove(),4000);}

// ── PANELS ────────────────────────────────────────────────────
function updPanels(){
  // Evo
  const ep=document.getElementById('evo-panel');const planets=bodies.filter(b=>b.type==='planet');
  if(!planets.length){ep.innerHTML='No planets.';return;}
  const sc={};for(const p of planets){const s=p.evoStage||p.pt||'rocky';sc[s]=(sc[s]||0)+1;}
  const cols={lava:'#ff4400',magma:'#ff2200',cooling:'#884422',rocky:'#aa9966',arid:'#cc9944',desert:'#bb8833',ocean:'#4488ee',life:'#00cc55',advanced:'#2266bb',gas:'#e8c87a',ice:'#7ac8e8'};
  let html='';
  for(const [s,n] of Object.entries(sc)){const col=cols[s]||'#888';html+=`<div style="display:flex;justify-content:space-between;margin-bottom:2px"><span style="color:${col}">${EVO[s]?.label||s}</span><span style="color:${col}">${n}</span></div>`;}
  const sel2=bodies.find(b=>b.id===selectedId&&b.type==='planet');
  if(sel2){const pct=Math.round((sel2.evoProgress||0)*100);const s=sel2.evoStage||'rocky';const col=cols[s]||'#888';html+=`<div style="margin-top:3px;border-top:1px solid var(--border);padding-top:3px"><div style="color:${col}">${sel2.name}</div><div style="background:var(--border);height:3px;border-radius:2px;margin:2px 0"><div style="background:${col};height:3px;width:${Math.min(100,pct)}%"></div></div><div style="color:var(--dim)">${pct}%</div></div>`;}
  ep.innerHTML=html;
  // Civs
  const cp=document.getElementById('civ-panel');const ac=civilizations.filter(c=>!c.extinct);
  if(!ac.length){cp.innerHTML='No civs yet.<br><span style="color:var(--dim)">Rocky planet in hab zone<br>→ water asteroid<br>→ life → intelligence</span>';return;}
  let chtml='';for(const civ of ac.slice(-4)){chtml+=`<div class="civ-entry" style="border-left-color:${civ.color}"><span style="color:${civ.color}">${civ.name}</span><br>Stage: <span style="color:var(--accent)">${CIV_STAGES[civ.stageIdx]}</span> | Tech: ${Math.round(civ.tech)}%<br>Pop: ${Math.round(civ.pop)}B | Ships: ${ships.filter(s=>s.civId===civ.id).length}</div>`;}
  if(civilizations.filter(c=>c.extinct).length)chtml+=`<div style="color:var(--dim);font-size:6px">${civilizations.filter(c=>c.extinct).length} extinct</div>`;
  cp.innerHTML=chtml;
  // Fleet
  const fp=document.getElementById('fleet-panel');
  if(!ships.length){fp.innerHTML='No ships.<br><span style="color:var(--dim)">Civs need Spacefaring (tech≥65)</span>';}
  else{let fh='';for(const s of ships.slice(-4)){const tg=bodies.find(b=>b.id===s.toId);fh+=`<div style="padding:2px 0;border-bottom:1px solid var(--border)"><span style="color:${s.color}">${s.name}</span>→${tg?.name||'?'}<br><span style="color:var(--dim)">${s.type}</span></div>`;}if(ships.length>4)fh+=`<div style="color:var(--dim)">${ships.length-4} more…</div>`;fp.innerHTML=fh;}
  // Temp
  const tm=document.getElementById('tempmap');const sel3=bodies.find(b=>b.id===selectedId&&b.type==='planet');
  if(sel3&&sel3.tempK){const tc=tempToColor(sel3.tempK);tm.innerHTML=`<span style="color:${tc}">${sel3.name}</span><br>Temp: <span style="color:${tc}">${Math.round(sel3.tempK)}K</span><br>Zone: ${sel3.zone||'?'}<br>${sel3.tempK<250?'❄ Frozen':sel3.tempK<400?'✅ Habitable':sel3.tempK<700?'🌡 Warm':'🔥 Hot'}`;}
  else{const ps=planets;if(ps.length){const h=ps.reduce((a,b)=>b.tempK>a.tempK?b:a,ps[0]),c=ps.reduce((a,b)=>b.tempK<a.tempK?b:a,ps[0]);tm.innerHTML=`Hot: <span style="color:#ff6600">${h.name} ${Math.round(h.tempK)}K</span><br>Cold: <span style="color:#4488ff">${c.name} ${Math.round(c.tempK)}K</span>`;}else tm.innerHTML='No planets.';}
}

// ── SAVE / LOAD ───────────────────────────────────────────────
function saveSystem(){const data={bodies,simTime,camX,camY,camSc,civilizations:civilizations.map(c=>({...c,exploredPlanets:[...c.exploredPlanets]})),ships,nebulae:nebulae.map(n=>({...n,particles:[]})),v:7};const blob=new Blob([JSON.stringify(data)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='cosmos-v7.json';a.click();ntf('Saved!');}
function loadSystem(){const inp=document.createElement('input');inp.type='file';inp.accept='.json';inp.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=ev=>{try{const data=JSON.parse(ev.target.result);bodies.length=0;for(const b of data.bodies){if(!b.tidal)b.tidal={sx:1,sy:1};if(!b.cooldownTimer)b.cooldownTimer=0;bodies.push(b);}civilizations.length=0;for(const c of(data.civilizations||[]))civilizations.push({...c,exploredPlanets:new Set(c.exploredPlanets)});ships.length=0;for(const s of(data.ships||[]))ships.push(s);nebulae.length=0;for(const n of(data.nebulae||[]))nebulae.push({...n,particles:genNebParticles(n.x,n.y,n.radius,n.colors)});simTime=data.simTime||0;camX=data.camX||cv.width/2;camY=data.camY||cv.height/2;camSc=data.camSc||1;CNT.p=bodies.filter(b=>b.type==='planet').length;CNT.s=bodies.filter(b=>b.type==='star').length;CNT.h=bodies.filter(b=>b.type==='hole').length;CNT.b=bodies.filter(b=>b.type==='belt').length;CNT.a=bodies.filter(b=>b.type==='asteroid').length;nextId=Math.max(...bodies.map(b=>b.id),0)+1;Object.keys(TEX).forEach(k=>delete TEX[k]);updCnt();sel(null);ntf('Loaded!');}catch(e2){ntf('Load failed','w');}};r.readAsText(f);};inp.click();}

// ── INPUT ─────────────────────────────────────────────────────
function getCP(cx,cy){const rect=cv.getBoundingClientRect();return{x:cx-rect.left,y:cy-rect.top};}
function pickDrag(cx,cy){for(const b of[...bodies].reverse()){if(b.type!=='planet'&&b.type!=='asteroid')continue;const s=w2s(b.x,b.y);if(Math.hypot(cx-s.x,cy-s.y)<((b.radius||3)+8)*camSc)return b;}return null;}
function startDrag(body,cp){dragBodyId=body.id;const s=w2s(body.x,body.y);dragOX=cp.x-s.x;dragOY=cp.y-s.y;body.lockedOrbit=false;body.vx=0;body.vy=0;body.binaryCapture=false;cv.style.cursor='grabbing';}
function moveDrag(cp){const b=bodies.find(b=>b.id===dragBodyId);if(!b)return;const w=s2w(cp.x-dragOX,cp.y-dragOY);b.x=w.x;b.y=w.y;b.vx=0;b.vy=0;}
function endDrag(cp){const b=bodies.find(b=>b.id===dragBodyId);dragBodyId=null;cv.style.cursor='crosshair';if(!b)return;const star=getNearStar(b.x,b.y);if(star){const dx=b.x-star.x,dy=b.y-star.y,orbitR=Math.hypot(dx,dy),angle=Math.atan2(dy,dx);if(orbitR>1){const oSpd=Math.sqrt(star.mass*gravMult*0.0002/orbitR)*60/orbitR;b.orbitAngle=angle;b.orbitRadius=orbitR;b.orbitA=orbitR;b.orbitB=orbitR*(1-(b.orbitEcc||0)*.7);b.orbitSpd=oSpd;b.orbitStar=star.id;b.lockedOrbit=true;}}}

let _cc=0,_ct=null,_cl=null;
cv.addEventListener('click',e=>{
  if(isDrag)return;const cp=getCP(e.clientX,e.clientY),world=s2w(cp.x,cp.y);let hit=null;
  for(const b of[...bodies].reverse()){const s=w2s(b.x,b.y);if(b.type==='belt'){if(Math.abs(Math.hypot(cp.x-s.x,cp.y-s.y)-b.radius*camSc)<12){hit=b;break;}}else if(Math.hypot(cp.x-s.x,cp.y-s.y)<((b.radius||3)+6)*camSc){hit=b;break;}}
  if(hit){
    sel(hit.id);
    _cl===hit.id?_cc++:(_cc=1,_cl=hit.id);
    if(_ct)clearTimeout(_ct);_ct=setTimeout(()=>{_cc=0;_cl=null;},500);
    if(_cc>=3){followBody=hit;ntf('📷 Following '+hit.name+' — triple-click again or Esc to stop','n');_cc=0;}
  }else if(spawnT){spawnAt(world.x,world.y);}else sel(null);
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&followBody){followBody=null;ntf('📷 Camera released');}});
cv.addEventListener('contextmenu',e=>{e.preventDefault();const cp=getCP(e.clientX,e.clientY);for(const b of[...bodies].reverse()){if(b.type!=='planet')continue;const s=w2s(b.x,b.y);if(Math.hypot(cp.x-s.x,cp.y-s.y)<(b.radius+8)*camSc){sel(b.id);openSurface();break;}}});
cv.addEventListener('mousedown',e=>{const cp=getCP(e.clientX,e.clientY);if(e.button===0&&!spawnT){const b=pickDrag(cp.x,cp.y);if(b){startDrag(b,cp);return;}}isDrag=false;dragSX=e.clientX;dragSY=e.clientY;camSX=camX;camSY=camY;});
cv.addEventListener('mousemove',e=>{const cp=getCP(e.clientX,e.clientY);if(dragBodyId){moveDrag(cp);return;}const dx=e.clientX-dragSX,dy=e.clientY-dragSY;if(e.buttons&&(Math.abs(dx)>4||Math.abs(dy)>4)){isDrag=true;camX=camSX+dx;camY=camSY+dy;}const tip=document.getElementById('tip');let hov=false;for(const b of[...bodies].reverse()){const s=w2s(b.x||0,b.y||0);if(Math.hypot(cp.x-s.x,cp.y-s.y)<((b.radius||3)+6)*camSc){tip.style.display='block';tip.style.left=(e.clientX+12)+'px';tip.style.top=(e.clientY+12)+'px';const civ=civilizations.find(c=>c.planetId===b.id&&!c.extinct);tip.innerHTML=`<b style="color:var(--accent)">${b.name}</b><br>${b.type}${b.zone?' | '+b.zone:''}${b.hasLife?'<br><span style="color:var(--green)">🌱 Life</span>':''}${civ?'<br><span style="color:'+civ.color+'">🧠 '+civ.name+'</span>':''}${b.tempK>0?'<br>'+Math.round(b.tempK)+'K':''}${b.canSupernova?'<br><span style="color:#ff8800">⚠ Supernova capable</span>':''}`;hov=true;break;}}if(!hov)tip.style.display='none';if(!spawnT&&!dragBodyId)cv.style.cursor=pickDrag(cp.x,cp.y)?'grab':'default';});
cv.addEventListener('mouseup',e=>{if(dragBodyId)endDrag(getCP(e.clientX,e.clientY));});
cv.addEventListener('wheel',e=>{e.preventDefault();const cp=getCP(e.clientX,e.clientY);const f=e.deltaY>0?.83:1.22;camX=cp.x+(camX-cp.x)*f;camY=cp.y+(camY-cp.y)*f;camSc=Math.max(.01,Math.min(12,camSc*f));},{passive:false});
cv.addEventListener('touchstart',e=>{e.preventDefault();if(e.touches.length!==1)return;const t=e.touches[0],cp=getCP(t.clientX,t.clientY);if(!spawnT){const b=pickDrag(cp.x,cp.y);if(b){startDrag(b,cp);return;}}isDrag=false;dragSX=t.clientX;dragSY=t.clientY;camSX=camX;camSY=camY;},{passive:false});
cv.addEventListener('touchmove',e=>{e.preventDefault();if(e.touches.length!==1)return;const t=e.touches[0],cp=getCP(t.clientX,t.clientY);if(dragBodyId){moveDrag(cp);return;}const dx=t.clientX-dragSX,dy=t.clientY-dragSY;if(Math.abs(dx)>4||Math.abs(dy)>4){isDrag=true;camX=camSX+dx;camY=camSY+dy;}},{passive:false});
cv.addEventListener('touchend',e=>{e.preventDefault();if(dragBodyId){endDrag(getCP(e.changedTouches[0].clientX,e.changedTouches[0].clientY));return;}if(!isDrag){const t=e.changedTouches[0],cp=getCP(t.clientX,t.clientY),world=s2w(cp.x,cp.y);let hit=null;for(const b of[...bodies].reverse()){const s=w2s(b.x,b.y);if(Math.hypot(cp.x-s.x,cp.y-s.y)<((b.radius||3)+5)*camSc){hit=b;break;}}if(hit)sel(hit.id);else if(spawnT)spawnAt(world.x,world.y);else sel(null);}isDrag=false;},{passive:false});

// ── MAIN LOOP ─────────────────────────────────────────────────
let lastT=performance.now();
function loop(now){
  const raw=(now-lastT)/1000;lastT=now;
  const dt=Math.min(raw,.05)*simSpd;
  ctx.clearRect(0,0,cv.width,cv.height);
  ctx.fillStyle='#00010a';ctx.fillRect(0,0,cv.width,cv.height);
  if(followBody){const _fb=bodies.find(b=>b.id===followBody.id);if(_fb){const _tx=cv.width/2-_fb.x*camSc,_ty=cv.height/2-_fb.y*camSc;camX+=((_tx-camX)*0.08);camY+=((_ty-camY)*0.08);}else followBody=null;}
  phoneTickCheck();
  drawStarfield();drawNebulae();drawGrid();drawZones();drawMagFields();drawSolarEvents();
  for(const b of bodies)if(b.type==='belt')drawBelt(b);
  for(const b of bodies)if(b.type==='hole')drawHole(b);
  for(const b of bodies)if(b.type==='star')drawStar(b);
  for(const b of bodies)if(b.type==='asteroid')drawAsteroid(b);
  for(const b of bodies)if(b.type==='planet')drawPlanet(b);
  drawShips();drawFlashes();
  if(!paused)updatePhysics(dt);
  document.getElementById('stime').textContent=Math.floor(simTime);
  document.getElementById('scivs').textContent=civilizations.filter(c=>!c.extinct).length;
  document.getElementById('sships').textContent=ships.length;
  updPanels();
  // ── USB EXTRA DRAWS ──
  if(typeof window._usbExtraDraws==='function') window._usbExtraDraws(dt);
  requestAnimationFrame(loop);
}

// ── DEFAULT SYSTEM ────────────────────────────────────────────
(function(){
  const sun={id:nextId++,type:'star',sub:'star-yellow',name:'Sol A',x:0,y:0,vx:0,vy:0,
    mass:100,radius:28,color:'#fff44f',glow:'#ffcc00',lum:1,tempK:5778,
    def:SDEFS['star-yellow'],age:0,moons:[],rings:0,angle:0,
    _oA:0,_oR:0,_oSpd:0,_multi:false,lifespan:99999,
    supernovaTriggered:false,canSupernova:true,magField:{strength:0.8,radius:90}};
  bodies.push(sun);CNT.s++;
  const pData=[{t:'lava',d:85,n:'Vulcan'},{t:'rocky',d:155,n:'Terra'},{t:'desert',d:215,n:'Arid'},{t:'gas',d:310,n:'Jove',r:2},{t:'gas',d:405,n:'Kronos',r:3},{t:'ice',d:490,n:'Gelid'},{t:'ice',d:570,n:'Axiom'}];
  for(let i=0;i<pData.length;i++){
    const pd=pData[i];const def=PDEFS[pd.t];const angle=Math.random()*Math.PI*2;
    const oSpd=Math.sqrt(sun.mass*0.0002/pd.d)*60/pd.d;
    const p={id:nextId++,type:'planet',sub:def.sub,pt:pd.t,name:pd.n,
      x:sun.x+Math.cos(angle)*pd.d,y:sun.y+Math.sin(angle)*pd.d,
      vx:-Math.sin(angle)*oSpd*pd.d*60,vy:Math.cos(angle)*oSpd*pd.d*60,
      mass:def.mass*10,radius:def.radius,colors:[...def.colors],color:def.colors[0],
      orbitAngle:angle,orbitRadius:pd.d,orbitA:pd.d,orbitB:pd.d,orbitEcc:0,orbitSpd:oSpd,
      orbitStar:sun.id,lockedOrbit:true,
      age:0,moons:[],rings:pd.r||0,hasLife:false,hadWater:false,atmo:def.sub==='gas'?1:0.22,
      strippedGas:false,zone:'unknown',noiseOff:Math.random()*1000,cloudAngle:0,shapeY:1,
      roughness:0.5,tempK:0,evoStage:pd.t,evoProgress:0,civilizationId:null,
      magField:Math.random()<0.4?{strength:0.3,radius:def.radius*2}:null,
      tidal:{sx:1,sy:1},cooldownTimer:0,waterFloodProgress:0};
    bodies.push(p);CNT.p++;
  }
  bodies.push({id:nextId++,type:'belt',name:'Main Belt',x:0,y:0,radius:252,width:28,
    starId:sun.id,particles:genBelt(0,0,252),age:0,waterRich:true});CNT.b++;
  nebulae.push(genNebula(500,250,'diffuse'));
  camX=cv.width/2;camY=cv.height/2;camSc=.8;
  updCnt();log('GALAXY FORGE v8 loaded','n');
  ntf('🌌 GALAXY FORGE v7 ready! Supernova at 50,000yr | Right-click planet = Surface View | GALAXY for full spiral');
})();

requestAnimationFrame(loop);

// ══════════════════════════════════════════════════════════════
// SOUND ENGINE — Web Audio API procedural space sounds
// ══════════════════════════════════════════════════════════════
let audioCtx = null;
let soundEnabled = false;
let masterGain = null;
let ambienceNode = null;   // looping space ambience
let svAmbienceNode = null; // surface ambience

function initAudio(){
  if(audioCtx) return;
  try {
    audioCtx = new (window.AudioContext||window.webkitAudioContext)();
    masterGain = audioCtx.createGain();
    masterGain.gain.value = 0.55;
    masterGain.connect(audioCtx.destination);
    soundEnabled = true;
    startSpaceAmbience();
    document.getElementById('btnSound').classList.add('on');
    document.getElementById('btnSound').textContent = '🔊 SOUND';
  } catch(e){ console.warn('Audio init failed', e); }
}

function toggleSound(){
  if(!soundEnabled){ initAudio(); return; }
  soundEnabled = !soundEnabled;
  masterGain.gain.value = soundEnabled ? 0.55 : 0;
  document.getElementById('btnSound').classList.toggle('on', soundEnabled);
  document.getElementById('btnSound').textContent = soundEnabled ? '🔊 SOUND' : '🔇 SOUND';
}

// ── Low-level helpers ──────────────────────────────────────────
function makeOsc(type, freq, duration, gainVal=0.15, detune=0){
  if(!audioCtx||!soundEnabled) return null;
  const osc = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  osc.type = type; osc.frequency.value = freq;
  if(detune) osc.detune.value = detune;
  g.gain.value = gainVal;
  osc.connect(g); g.connect(masterGain);
  osc.start(); osc.stop(audioCtx.currentTime + duration);
  return {osc, g};
}

function makeBuf(duration, fn){
  if(!audioCtx) return null;
  const sr = audioCtx.sampleRate;
  const buf = audioCtx.createBuffer(1, Math.floor(sr*duration), sr);
  const data = buf.getChannelData(0);
  fn(data, sr);
  return buf;
}

function playBuf(buf, gainVal=0.2, playbackRate=1, loop=false){
  if(!audioCtx||!soundEnabled||!buf) return null;
  const src = audioCtx.createBufferSource();
  const g = audioCtx.createGain();
  src.buffer = buf; src.loop = loop;
  src.playbackRate.value = playbackRate;
  g.gain.value = gainVal;
  src.connect(g); g.connect(masterGain);
  src.start();
  return {src, g};
}

// ── SPACE AMBIENCE (looping deep drone) ──────────────────────
function startSpaceAmbience(){
  if(!audioCtx || ambienceNode) return;
  const sr = audioCtx.sampleRate;
  const dur = 8;
  const buf = makeBuf(dur, (data, sr2)=>{
    // Layer 1: deep subsonic rumble
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const lfo = Math.sin(t*0.18*Math.PI*2)*0.5+0.5;
      data[i] += Math.sin(t*28*Math.PI*2)*0.12*lfo;
      data[i] += Math.sin(t*31.5*Math.PI*2)*0.08*lfo;
      // Layer 2: gentle shimmer
      data[i] += Math.sin(t*440*Math.PI*2)*0.006*(Math.sin(t*0.7*Math.PI*2)*0.5+0.5);
      data[i] += Math.sin(t*528*Math.PI*2)*0.004*(Math.sin(t*0.4*Math.PI*2)*0.5+0.5);
      // Layer 3: cosmic noise
      data[i] += (Math.random()*2-1)*0.004;
    }
  });
  ambienceNode = playBuf(buf, 0.18, 1, true);
}

function stopSpaceAmbience(){
  if(ambienceNode){ try{ambienceNode.src.stop();}catch(e){} ambienceNode=null; }
}

// ── SURFACE AMBIENCE ──────────────────────────────────────────
function startSurfaceAmbience(stage){
  stopSurfaceAmbience();
  if(!audioCtx||!soundEnabled) return;
  const sr = audioCtx.sampleRate;
  const dur = 6;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      if(stage==='lava'||stage==='magma'){
        // Deep rumbling magma + crackling
        const rumble=Math.sin(t*22*Math.PI*2)*0.25*(Math.sin(t*0.15*Math.PI*2)*0.5+0.5);
        const crackle=(Math.random()<0.002)?(Math.random()*2-1)*0.8:0;
        const hiss=(Math.random()*2-1)*0.03;
        data[i]=rumble+crackle*0.3+hiss;
      } else if(stage==='ice'){
        // Cold wind + crystalline pings
        const wind=(Math.random()*2-1)*0.04*(Math.sin(t*0.3*Math.PI*2)*0.5+0.7);
        const ping=(t*100)%1<0.002?Math.sin(t*2200*Math.PI*2)*0.15*Math.exp(-((t*100)%1)*30):0;
        data[i]=wind+ping;
      } else if(stage==='ocean'){
        // Waves + water
        const wave=Math.sin(t*0.8*Math.PI*2)*Math.sin(t*1.3*Math.PI*2)*(Math.random()*2-1)*0.12;
        const splash=(Math.random()*2-1)*0.03*(Math.sin(t*2.1*Math.PI*2)*0.5+0.5);
        data[i]=wave+splash;
      } else if(stage==='life'||stage==='advanced'){
        // Wind + subtle biosphere hum
        const wind=(Math.random()*2-1)*0.025*(Math.sin(t*0.5*Math.PI*2)*0.4+0.6);
        const hum=Math.sin(t*180*Math.PI*2)*0.008*(Math.sin(t*0.2*Math.PI*2)*0.5+0.5);
        data[i]=wind+hum;
      } else if(stage==='arid'||stage==='desert'){
        // Dry whistling wind
        const wind=(Math.random()*2-1)*0.035*(Math.sin(t*0.4*Math.PI*2)*0.5+0.5);
        const whistle=Math.sin(t*380*Math.PI*2)*0.015*(Math.sin(t*1.8*Math.PI*2)*0.5+0.5);
        data[i]=wind+whistle;
      } else {
        // Default: thin atmospheric hiss
        data[i]=(Math.random()*2-1)*0.018*(Math.sin(t*0.25*Math.PI*2)*0.3+0.7);
      }
    }
  });
  svAmbienceNode = playBuf(buf, 0.3, 1, true);
}

function stopSurfaceAmbience(){
  if(svAmbienceNode){ try{svAmbienceNode.src.stop();}catch(e){} svAmbienceNode=null; }
}

// ── ONE-SHOT SOUND EFFECTS ─────────────────────────────────────

// Asteroid whoosh — Doppler pitched sweep
function sndAsteroidFlyby(proximity=1.0){
  if(!audioCtx||!soundEnabled) return;
  const t0 = audioCtx.currentTime;
  const dur = 1.8 + (1-proximity)*1.4;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2/dur; // 0-1
      // Doppler: pitch sweeps down as asteroid passes
      const dopplerFreq = 420*(1+(1-t)*0.6);
      const env = Math.sin(t*Math.PI); // bell envelope
      const whoosh = Math.sin(i*dopplerFreq/sr2*Math.PI*2)*env;
      const noise = (Math.random()*2-1)*env*0.4;
      data[i] = (whoosh*0.3 + noise*0.7)*proximity*0.9;
    }
  });
  const node = playBuf(buf, 0.55 * proximity);
  // Low rumble layer
  const rumbleBuf = makeBuf(dur*0.7, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2/(dur*0.7);
      data[i] = Math.sin(i*80/sr2*Math.PI*2)*Math.sin(t*Math.PI)*0.8;
    }
  });
  playBuf(rumbleBuf, 0.3*proximity);
}

// Asteroid impact boom
function sndAsteroidImpact(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 2.2;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const env = Math.exp(-t*3.5);
      const boom = Math.sin(t*38*Math.PI*2)*env*0.9;
      const crack = Math.sin(t*180*Math.PI*2)*Math.exp(-t*12)*0.6;
      const rumble = (Math.random()*2-1)*env*0.4;
      data[i] = boom+crack+rumble;
    }
  });
  playBuf(buf, 0.7);
}

// Supernova — massive low boom + shockwave sweep
function sndSupernova(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 5;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const env = Math.exp(-t*0.6);
      const boom = Math.sin(t*18*Math.PI*2)*0.9*env;
      const sweep = Math.sin(t*(800-t*120)*Math.PI*2)*0.3*env;
      const noise = (Math.random()*2-1)*env*0.35;
      data[i] = boom + sweep + noise;
    }
  });
  playBuf(buf, 0.9);
}

// Black hole formation — deep inward suck tone
function sndBlackHoleForm(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 4;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const falling = Math.sin(t*(200-t*40)*Math.PI*2)*Math.exp(-t*0.3)*0.6;
      const drone = Math.sin(t*22*Math.PI*2)*(1-t/dur)*0.5;
      const noise = (Math.random()*2-1)*0.05;
      data[i] = falling + drone + noise;
    }
  });
  playBuf(buf, 0.85);
}

// Planet spawn whomp
function sndSpawn(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 0.6;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const env = Math.exp(-t*6);
      data[i] = Math.sin(t*(320-t*180)*Math.PI*2)*env*0.7
               +(Math.random()*2-1)*env*0.15;
    }
  });
  playBuf(buf, 0.4);
}

// Star spawn shimmer
function sndStarSpawn(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 1.4;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const env = Math.exp(-t*1.8);
      const chime = Math.sin(t*880*Math.PI*2)*0.4*env
                   +Math.sin(t*1320*Math.PI*2)*0.25*env
                   +Math.sin(t*1760*Math.PI*2)*0.15*env;
      const hiss = (Math.random()*2-1)*0.04*env;
      data[i] = chime + hiss;
    }
  });
  playBuf(buf, 0.5);
}

// Solar flare — searing crackle
function sndSolarFlare(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 2.5;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const env = Math.exp(-t*1.2);
      const sear = Math.sin(t*2200*Math.PI*2)*0.12*env;
      const crackle = (Math.random()<0.05)?(Math.random()*2-1)*0.6*env:0;
      const rumble = Math.sin(t*45*Math.PI*2)*0.3*env;
      data[i] = sear + crackle + rumble;
    }
  });
  playBuf(buf, 0.6);
}

// Black hole tidal pull hum
function sndTidalPull(intensity=0.5){
  if(!audioCtx||!soundEnabled) return;
  const dur = 0.5;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      data[i] = Math.sin(t*35*Math.PI*2)*0.5*(1-t/dur)*intensity
               +Math.sin(t*52*Math.PI*2)*0.3*(1-t/dur)*intensity;
    }
  });
  playBuf(buf, 0.25);
}

// Planet collision — massive impact
function sndPlanetCollision(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 3.5;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const env = Math.exp(-t*1.1);
      const impact = Math.sin(t*28*Math.PI*2)*0.8*env;
      const crack = Math.sin(t*95*Math.PI*2)*Math.exp(-t*5)*0.5;
      const rumble = (Math.random()*2-1)*0.35*env;
      data[i] = impact + crack + rumble;
    }
  });
  playBuf(buf, 0.85);
}

// Civilization discovery chime
function sndCivDiscovery(){
  if(!audioCtx||!soundEnabled) return;
  const freqs = [523, 659, 784, 1047];
  freqs.forEach((f, i)=>{
    setTimeout(()=>{
      const dur = 1.2;
      const buf = makeBuf(dur, (data, sr2)=>{
        for(let j=0; j<data.length; j++){
          const t = j/sr2;
          data[j] = Math.sin(t*f*Math.PI*2)*Math.exp(-t*2.5)*0.6
                   +Math.sin(t*f*2*Math.PI*2)*Math.exp(-t*4)*0.2;
        }
      });
      playBuf(buf, 0.28);
    }, i*200);
  });
}

// Water asteroid impact
function sndWaterImpact(){
  if(!audioCtx||!soundEnabled) return;
  const dur = 1.8;
  const buf = makeBuf(dur, (data, sr2)=>{
    for(let i=0; i<data.length; i++){
      const t = i/sr2;
      const splash = Math.sin(t*(600-t*200)*Math.PI*2)*Math.exp(-t*3)*0.5;
      const rush = (Math.random()*2-1)*Math.exp(-t*2)*0.3;
      const bubble = Math.sin(t*320*Math.PI*2)*Math.exp(-t*4)*0.2*(1+Math.sin(t*80));
      data[i] = splash + rush + bubble;
    }
  });
  playBuf(buf, 0.55);
}

// Throttle sound calls
let lastSoundTime = {};
function throttleSound(key, fn, minInterval=0.4){
  const now = audioCtx ? audioCtx.currentTime : 0;
  if(!lastSoundTime[key] || now - lastSoundTime[key] > minInterval){
    lastSoundTime[key] = now;
    fn();
  }
}


// ════════════════════════════════════════════════════════════════
// CIVILNET — Alien Social Media Engine
// ════════════════════════════════════════════════════════════════
let phoneOpen=false,phoneTab='feed',phoneActiveCiv=null;
let phoneFeedItems=[],phoneLiveMessages=[],phoneVideoQueue=[],phoneDMThread=[];
let phoneLiveInterval=null,phoneNotifCount=0,_lastPhoneCivId=null;

const SLANG={
  ancient:{exclaim:['By the Twin Moons!','Stars be praised!','Great void!'],agree:['Indeed, traveler','It is written','So shall it be'],react:['🌙','⭐','🔥'],suffix:['— wisdom of the elders','~ starward','~ as foretold'],hype:['most glorious','truly divine','of great honor']},
  medieval:{exclaim:['Hark!','Forsooth!','By the comet!'],agree:["'Tis true!",'Verily!','Aye, good citizen'],react:['⚔️','🏰','🌌'],suffix:['~scribed in the orbital records','— heralded true'],hype:['of great renown','most esteemed','legendary']},
  industrial:{exclaim:['Blimey!','Cor blimey!','Great engines!'],agree:['Right you are','Quite so','Capital observation'],react:['⚙️','🔧','💡'],suffix:['— telegraph confirmed','~press approved'],hype:['bang-up','top-notch','absolutely capital']},
  atomic:{exclaim:['Holy fission!','Rad!','Far out!','Groovy!'],agree:['Right on','Can dig it','Solid'],react:['☢️','🌐','📡'],suffix:['— over and out','~broadcast ends'],hype:['outta sight','far out','totally atomic']},
  spacefaring:{exclaim:['BRUH 💀','no cap fr','omg bestie','slay','it\'s giving'],agree:['lowkey true','ong','fr fr no cap','based'],react:['💀','👁️','🫠','😭','🔥'],suffix:['~ not clickbait','~ timestamp','~ source: trust me'],hype:['slay','hits different','bussin','absolutely ate']},
  interstellar:{exclaim:['vld!!','zng','quaz fr','eon eon'],agree:['quaz','rlm','vld','zng fr'],react:['🌀','⚡','💫','🫧'],suffix:['~ quaz-stamped','~ eon-verified'],hype:['quaz-tier','eon-level','absolute zng']},
  transcendent:{exclaim:['∞∞∞','⟨mind-meld⟩','[collective pulse]'],agree:['[shared truth]','∞ confirmed ∞','⟨we agree⟩'],react:['✦','∞','⟨⟩','◈'],suffix:['~ broadcast from the hive','⟨end transmission⟩'],hype:['∞-tier','hive-confirmed','resonant beyond measure']},
};
const SL_MAP={'Primitive':'ancient','Ancient':'ancient','Medieval':'medieval','Industrial':'industrial','Atomic':'atomic','Spacefaring':'spacefaring','Interstellar':'interstellar','Transcendent':'transcendent'};
function getSL(stage){return SLANG[SL_MAP[stage]||'spacefaring'];}
function pick(arr,s){return arr[Math.floor(Math.abs(Math.sin((s||0)*7.3+1.1)*9999))%arr.length];}

const NP1=['Aex','Vel','Kyr','Zun','Mir','Thal','Drev','Sol','Axon','Pyr','Lun','Vor','Xan','Ith','Orel','Fen','Qal','Veth'];
const NP2=['ion','aria','ven','ox','ias','una','eth','orn','ix','ara','os','en','yl','an','el','ur','av','ek'];
const NSUF=['_42','_x99','00','_real','420','69','_notabot','2','_actual','_official'];
function genUser(s,stage){
  const r=(n,o)=>Math.floor(Math.abs(Math.sin(s*(o||1)*1.7+o)*9999))%n;
  const base=NP1[r(NP1.length,3)]+NP2[r(NP2.length,7)];
  const sfx=['spacefaring','interstellar','transcendent'].includes(SL_MAP[stage]||'')?NSUF[r(NSUF.length,13)]:'';
  return '@'+base+sfx;
}
const AVS=['🧑‍🚀','👾','🤖','🛸','🌌','👽','🧬','🔭','⚡','🌠','💎','🌀','🔮','🎭','🦾','🫠','🧿'];
const AVBG=['#1a0038','#002a38','#001a14','#2a1000','#140028','#001a28','#280010','#0a0a00'];
function genAv(s){return AVS[Math.floor(Math.abs(Math.sin(s*13.7))*AVS.length)];}
function genBg(s){return AVBG[Math.floor(Math.abs(Math.sin(s*5.3))*AVBG.length)];}

const TMUNDANE=['the moons looked weird last night','does anyone else eat food paste straight from the tube','my gravity boots broke AGAIN','the sky is a different color today and nobody is talking about it','unpopular opinion: star rising is overrated','my neighbor launched a probe at 3am','new leaf-bread just dropped','the orbital path change made my commute longer','I\'ve been awake for 40 hours and everything is fine','reminder that none of this matters cosmically','just saw a shooting star. probably nothing','does anyone know a good void-facing apartment','the cafeteria switched to synthetic gravity and I\'m not okay'];
const TDRAMA=['the Council LIED about the last eclipse duration 😤','my coworker stole my atmospheric reading credit','hot take: the planet naming committee is corrupt','they\'re shutting down the 3rd orbital ring and nobody asked us','I confronted my clone and it went poorly','the government is fluoridating the water domes and here\'s proof','thread: why everything you know about star formation is WRONG 🧵','just found out my mentor has been a simulation for 3 years','my ex joined a star-gazing cult and I need to vent','the inter-civ trade deal benefits only the sky-city elite'];
const TSCIENCE=['new study: breathing void air for 0.3 seconds causes mild opinions','megathread: dark matter is just light that got socially anxious','our star will expand in ~5B years. starting to make plans','water asteroid impact next week: ocean 2.0 incoming?','gravity wells around the outer rings are WAY stronger than reported','confirmed: photonic crystals can store memories. regretting experiment','the magnetosphere is going through something rn','I think I detected a second consciousness in my telescope'];
const TMEME=['me: I should sleep \n\nmy brain at 3am: [45 slide presentation on why stars feel things]','the void: *exists*\nphilosophers: I\'m gonna ruin this planet\'s whole career','normal beings: go outside\nme: Sir this is a vacuum','[rock floating in space]\ncaption: mood','ratio + you live on a wet rock hurling through void at 70k units/sec + cope','day 1 of pretending I understand orbital mechanics in meetings','my therapist told me the void can\'t hurt me. the void: allow me to introduce myself'];
const TEVENTS=['JUST IN: Void Festival tickets SOLD OUT already???','live coverage of the eclipse starting now','the meteor shower is tonight. I\'m going to cry about it','breaking: council declares new holiday. reason: "vibes"','MAJOR: First contact celebration in 2 cycles','sports update: sky-bowl void-riders won AGAIN','the sky-bridge inauguration is this orbital cycle'];
const SUBS=['r/VoidThoughts','r/PlanetaryVibes','r/CosmicCringe','r/OrbitalNews','r/StargazingIRL','r/GravityMemes','r/CivPolitics','r/SpaceFood','r/MeteorWatch','r/PhilosophyOfVoid','r/LocalSystem','r/TechSupport_Gravity','r/LateNightOrbit'];
const CHANS=['#general','#void-talk','#memes','#science-hourly','#drama-thread','#off-topic','#announcements','#rant-zone','#shower-thoughts','#late-night','#first-contact'];
const VTITLES=['I Lived in a Meteor Crater For 30 Days (not clickbait)','Rating Every Star Type TIER LIST 🔥','The Void Experience Explained in 12 Minutes','GRWM: Getting Ready for the Eclipse 🌑✨','Why I Left the Orbital Ring (honest update)','Dark Matter Debunked? (re: the last video)','Trying EVERY Street Food at the Gravity Festival','I Stayed Awake for One Full Orbital Cycle | my experience','Things Only People From the Outer Belt Understand','Reacting to Ancient Star Maps 💀','The Day I Accidentally Contacted an Alien Probe','Making My Grandparent\'s Traditional Void-Soup Recipe','My Honest Review of Every Planet I\'ve Visited','I Challenged the Council to a Debate and Won','MASSIVE Sky Event TONIGHT — watch with me LIVE 🔴','Exposing the Truth About Artificial Gravity (they don\'t want you to know)','Void-core Aesthetic Room Tour 🌌'];
const VEMOJIS=['🌌','🌠','🔭','🛸','⭐','🌑','💫','🔥','👽','🚀','🌊','❄️','🌋','⚡','🎭','🌀'];

function genPost(s,stage){
  const sl=getSL(stage);
  const allT=[...TMUNDANE,...TDRAMA,...TSCIENCE,...TMEME,...TEVENTS];
  let body=pick(allT,s);
  if(Math.random()<0.28) body=pick(sl.exclaim,s+1)+' '+body;
  if(Math.random()<0.18) body=body+' '+pick(sl.suffix,s+2);
  const cmts=[];
  for(let i=0;i<1+Math.floor(Math.random()*3);i++){
    const agree=Math.random()<0.55;
    cmts.push({user:genUser(s+i*77+111,stage),av:genAv(s+i*77),bg:genBg(s+i*77),
      text:agree?pick(sl.agree,s+i)+', '+pick(TMUNDANE,s+i+50).substring(0,45)+'…':pick(sl.exclaim,s+i)+' actually '+pick(TMUNDANE,s+i+3).substring(0,40)});
  }
  return{type:'post',s,user:genUser(s,stage),av:genAv(s),bg:genBg(s),stage,text:body,sub:pick(SUBS,s+7),
    isHot:Math.random()<0.25,isNew:Math.random()<0.3,
    up:Math.floor(Math.random()*48000),likes:Math.floor(Math.random()*12000),
    rp:Math.floor(Math.random()*3000),cmts};
}
function genVid(s,stage){
  const sl=getSL(stage);
  const title=pick(VTITLES,s)+(Math.random()<0.22?' '+pick(sl.exclaim,s+3):'');
  return{type:'video',s,stage,title,emoji:pick(VEMOJIS,s),
    views:(Math.random()*50+0.1).toFixed(1),likes:Math.floor(Math.random()*800000),
    prog:Math.random(),user:genUser(s,stage),sub:pick(['v/Trending','v/ScienceToday','v/ViralVoid','v/CivTV','v/NightSky'],s)};
}
function genLM(s,stage){
  const sl=getSL(stage);
  const allT=[...TMUNDANE,...TDRAMA,...TMEME];
  const react=Math.random()<0.35?pick(sl.react,s+1)+' ':'';
  return{user:genUser(s,stage),av:genAv(s),bg:genBg(s),
    color:pick(['#cc88ff','#ff88aa','#88ccff','#88ffcc','#ffcc88','#ff6baa','#aaffcc'],s),
    text:react+pick(allT,s).split('\n')[0].substring(0,70),
    ts:new Date().toLocaleTimeString('en',{hour:'2-digit',minute:'2-digit',hour12:false})};
}
function genDMs(s,stage){
  const sl=getSL(stage);const allT=[...TMUNDANE,...TDRAMA];const out=[];
  for(let i=0;i<7+Math.floor(Math.random()*5);i++){
    const sent=i%2===0;
    const t=pick(allT,s+i*13);
    const txt=sent?(i===0?t:pick(sl.agree,s+i)+'!! '+t.substring(0,40))
      :pick(sl.agree,s+i)+' '+pick(TMUNDANE,s+i+7).substring(0,45)+(Math.random()<0.3?' '+pick(sl.react,s+i):'');
    out.push({sent,text:txt.substring(0,90)});
  }
  return out;
}
function fmtN(n){return n>=1e9?(n/1e9).toFixed(1)+'B':n>=1e6?(n/1e6).toFixed(1)+'M':n>=1e3?(n/1e3).toFixed(1)+'k':n;}

function rPost(p){
  const badge=p.isHot?'<span class="pc-badge badge-hot">HOT</span>':p.isNew?'<span class="pc-badge badge-new">NEW</span>':'<span class="pc-badge badge-top">TOP</span>';
  const cmtH=p.cmts.map(c=>`<div class="cmt"><div class="cmt-av" style="background:${c.bg}">${c.av}</div><div class="cmt-txt"><span class="cmt-user">${c.user}</span> ${c.text}</div></div>`).join('');
  return`<div class="pc"><div class="pc-hdr"><div class="pc-av" style="background:${p.bg}">${p.av}</div><div class="pc-meta"><div class="pc-user">${p.user}</div><div class="pc-sub">${p.sub}</div></div>${badge}</div><div class="pc-txt">${p.text}</div><div class="pc-actions"><button class="pca" onclick="this.classList.toggle('voted')">▲ ${fmtN(p.up)}</button><button class="pca" onclick="this.classList.toggle('liked')">♥ ${fmtN(p.likes)}</button><button class="pca">↺ ${fmtN(p.rp)}</button><span class="pc-score">${fmtN(Math.floor(p.up*1.2))} pts</span></div>${cmtH?`<div class="cmts">${cmtH}</div>`:''}</div>`;
}
function rVid(v){
  return`<div class="vc"><div class="vc-thumb">${v.emoji}<div class="vc-play">▶</div></div><div class="vc-info"><div class="vc-title">${v.title}</div><div class="vc-meta">${v.user} · ${v.views}M views · ♥ ${fmtN(v.likes)}</div><div class="vc-bar"><div class="vc-prog" style="width:${Math.round(v.prog*100)}%"></div></div></div></div>`;
}
function rLM(m){
  return`<div class="lv-msg"><div class="lv-av" style="background:${m.bg}">${m.av}</div><div class="lv-body"><span class="lv-user" style="color:${m.color}">${m.user}</span><span class="lv-ts">${m.ts}</span><div class="lv-text">${m.text}</div></div></div>`;
}
function rProfile(civ){
  const s=civ.id*77;const stage=CIV_STAGES[civ.stageIdx]||'Unknown';
  const bio=pick(['just a humble void-dweller 🌌','star enthusiast | gravity skeptic','i make content about space and feelings','professional comet-chaser | she/void','not an NPC | probably','orbiting and thriving ✨','former crater inspector | current void philosopher','the algorithm chose me','living my best orbital life 💫'],s);
  return`<div class="prf-hdr"><span class="prf-pic">${genAv(s)}</span><div class="prf-name">${civ.name}</div><div class="prf-handle">${genUser(s,stage)} · ${stage}</div><div class="prf-bio">${bio}</div><div class="prf-stats"><div class="prf-s"><div class="prf-sn">${fmtN(Math.floor(Math.random()*8000+200))}</div><div class="prf-sl">POSTS</div></div><div class="prf-s"><div class="prf-sn">${fmtN(Math.floor(Math.random()*2e7+1e5))}</div><div class="prf-sl">FOLLOWERS</div></div><div class="prf-s"><div class="prf-sn">${fmtN(Math.floor((civ.pop||1)*20e9))}</div><div class="prf-sl">POPULATION</div></div></div></div><div style="padding:10px;">${rPost(genPost(s+1,stage))}</div>`;
}

function togglePhone(){
  phoneOpen=!phoneOpen;
  document.getElementById('phone-wrap').classList.toggle('open',phoneOpen);
  document.getElementById('btnPhone').textContent=phoneOpen?'📱 CLOSE':'📱 SOCIAL';
  if(phoneOpen){
    phoneNotifCount=0;
    const d=document.getElementById('ph-notif');if(d)d.style.display='none';
    const cw=document.getElementById('ph-chat-wrap');
    if(cw)cw.style.display=phoneTab==='live'?'flex':'none';
    refreshPhone();
    if(!phoneLiveInterval)startLiveTick();
  } else {
    stopLiveTick();
  }
}
function setPhTab(btn){
  document.querySelectorAll('.ptab').forEach(b=>b.classList.remove('act'));
  btn.classList.add('act');phoneTab=btn.dataset.tab;
  const cw=document.getElementById('ph-chat-wrap');
  if(cw)cw.style.display=phoneTab==='live'?'flex':'none';
  renderPhone();
}
function getActiveCiv(){
  const sel=civilizations.find(c=>!c.extinct&&c.planetId===selectedId);
  if(sel)return sel;
  return civilizations.filter(c=>!c.extinct).sort((a,b)=>b.stageIdx-a.stageIdx)[0]||null;
}
function refreshPhone(){
  const civ=getActiveCiv();
  if(!civ){document.getElementById('ph-planet').textContent='No active civs';document.getElementById('ph-pop').textContent='';document.getElementById('ph-era').textContent='';document.getElementById('ph-feed').innerHTML='<div style="padding:24px;text-align:center;font-family:Share Tech Mono,monospace;font-size:8px;color:#3a1850;line-height:2">📡 No civilizations detected.<br>Spawn habitable planets and wait<br>for life to evolve.</div>';return;}
  phoneActiveCiv=civ;
  const planet=bodies.find(b=>b.id===civ.planetId);
  const stage=CIV_STAGES[civ.stageIdx]||'Unknown';
  const pop=Math.floor((civ.pop||1)*20e9);
  document.getElementById('ph-planet').textContent=(planet?.name||'?')+' · '+stage;
  document.getElementById('ph-pop').textContent=fmtN(pop)+' pop';
  document.getElementById('ph-era').textContent=stage+' Era';
  const seed=(civ.id*137+Math.floor(simTime*0.008))%99999;
  phoneFeedItems=[];
  for(let i=0;i<14;i++) phoneFeedItems.push(Math.random()<0.55?genPost(seed+i*31,stage):genVid(seed+i*17,stage));
  phoneVideoQueue=[];
  for(let i=0;i<10;i++) phoneVideoQueue.push(genVid(seed+i*23+500,stage));
  phoneDMThread=genDMs(seed+999,stage);
  renderPhone();
}
function renderPhone(){
  if(!phoneActiveCiv){refreshPhone();return;}
  const feed=document.getElementById('ph-feed');
  const civ=phoneActiveCiv;const stage=CIV_STAGES[civ.stageIdx]||'Unknown';
  const seed=(civ.id*137+Math.floor(simTime*0.008))%99999;
  if(phoneTab==='feed'){
    feed.innerHTML=phoneFeedItems.filter(p=>p.type==='post').slice(0,7).map(rPost).join('');
  } else if(phoneTab==='trending'){
    feed.innerHTML='<div class="sec-hdr">🔥 TRENDING NOW</div>'+phoneFeedItems.slice(0,10).map(p=>p.type==='video'?rVid(p):rPost({...p,isHot:true})).join('');
  } else if(phoneTab==='live'){
    feed.innerHTML='<div class="lv-hdr" style="flex-shrink:0">💬 '+pick(CHANS,seed)+' — LIVE</div>'+(phoneLiveMessages.slice(-50).map(rLM).join('')||'<div style="padding:12px;font-family:Share Tech Mono,monospace;font-size:8px;color:#3a1850">Send a message to start chatting! ↓</div>');
    setTimeout(()=>{feed.scrollTop=feed.scrollHeight;},20);
  } else if(phoneTab==='video'){
    feed.innerHTML='<div class="sec-hdr">📺 FOR YOU</div>'+phoneVideoQueue.map(rVid).join('');
  } else if(phoneTab==='dms'){
    const ps=seed+555;
    feed.innerHTML='<div class="sec-hdr">✉ MESSAGES</div><div class="dm-hdr">💬 '+genUser(ps,stage)+'</div><div style="display:flex;flex-direction:column;gap:5px;padding:4px 0;">'+phoneDMThread.map(m=>`<div class="dm-bbl ${m.sent?'s':'r'}">${m.text}</div>`).join('')+'</div>';
    setTimeout(()=>{feed.scrollTop=feed.scrollHeight;},40);

  } else {
    feed.innerHTML=rProfile(civ);
  }

  // Inject pinned posts in trending tab
  if(phoneTab==='trending'&&typeof pinnedPosts!=='undefined'&&pinnedPosts.length>0){
    const feed2=document.getElementById('ph-feed');
    if(feed2){
      feed2.innerHTML=
        '<div class="sec-hdr" style="color:#ff6688;">📌 PINNED & BREAKING</div>'+
        pinnedPosts.slice(0,3).map(p=>rPost({...p,isHot:true})).join('')+
        feed2.innerHTML.replace('<div class="sec-hdr">🔥 TRENDING NOW</div>','<div class="sec-hdr">🔥 TRENDING</div>');
    }
  }
  // Style user messages in live tab
  if(phoneTab==='live'){
    const feed3=document.getElementById('ph-feed');if(!feed3)return;
    const msgs3=feed3.querySelectorAll('.lv-msg');
    phoneLiveMessages.slice(-30).forEach((m,ii)=>{
      if(!msgs3[ii])return;
      if(m.isUser)msgs3[ii].style.cssText='border-left:2px solid #00d4ff55;padding-left:5px;background:rgba(0,180,255,0.05);border-radius:4px;';
      if(m.replyTo&&!msgs3[ii].querySelector('.rl')){
        const rl=document.createElement('div');rl.className='rl';
        rl.style.cssText='font:6px "Share Tech Mono",monospace;color:#5533aa;margin-bottom:1px;';
        rl.textContent='↩ '+m.replyTo;
        const lb=msgs3[ii].querySelector('.lv-body');if(lb)lb.prepend(rl);
      }
    });
  }
}
function startLiveTick(){
  if(phoneLiveInterval)return;
  const tick=()=>{
    const civ=getActiveCiv();if(!civ)return;
    const stage=CIV_STAGES[civ.stageIdx]||'Unknown';
    phoneLiveMessages.push(genLM(Math.floor(Math.random()*99999),stage));
    if(phoneLiveMessages.length>80)phoneLiveMessages.shift();
    if(phoneTab==='live')renderPhone();
    if(!phoneOpen){phoneNotifCount++;const d=document.getElementById('ph-notif');if(d)d.style.display='block';}
  };
  phoneLiveInterval=setInterval(tick,1600+Math.random()*1400);
}
function stopLiveTick(){if(phoneLiveInterval){clearInterval(phoneLiveInterval);phoneLiveInterval=null;}}
function phoneTickCheck(){
  if(!phoneOpen)return;
  const civ=getActiveCiv();const key=(civ?.id||0)+'_'+(civ?CIV_STAGES[civ.stageIdx]:'');
  if(key!==_lastPhoneCivId){_lastPhoneCivId=key;phoneLiveMessages=[];refreshPhone();}
}

// ═══════════════════════════════════════════════════════════════
// CIVILNET LIVE CHAT + DIRTY-MINDED NPC REPLIES + PINNED POSTS
// ═══════════════════════════════════════════════════════════════
const DIRTY={
  ancient:['By the twin moons, the high priestess performs VERY private rituals 🌙','My void-staff is impressively long for extended astronomical observations 👀','The sacred scrolls describe union ceremonies requiring two participants minimum','The elder chambers have unusually thick walls — I have explored them thoroughly','Astral convergence requires deep alignment, and I have excellent flexibility'],
  medieval:['My lance stands VERY firmly at the ready for willing court maidens 👀','The dungeon keeper hath a most generous and accommodating dungeon','Mine sword is not the only thing that rises at dawn — forsooth','The blacksmith\'s forge is not the only HOT thing in this castle 🔥','The royal jester knows 14 positions, each more impressive than the last'],
  industrial:['My piston rod provides VIGOROUS overtime service to willing participants 🔧','The steam pressure in my boiler has been called dangerously impressive by inspectors','Factory inspector reporting — I specialize in thorough tight-valve examinations 👀','My shaft has been described as impressively deep by multiple professional surveyors','Nothing quite like a long deep tunnel inspection on a cold industrial evening'],
  atomic:['Baby I\'m radioactive and my half-life is extremely satisfying ☢️','My rocket\'s thrust-to-weight ratio has genuinely impressed multiple mission specialists','Come see my fallout shelter sometime — the ceiling is surprisingly high','The Geiger counter simply LOSES its mind in close proximity to me','My telescope is not the only impressively long instrument in my observatory 📡'],
  spacefaring:['ngl my gravitational pull in personal situations is absolutely UNMATCHED no cap 💀','bestie my launch sequence takes a very long time and everyone seems to LOVE it','the way I dock my ship... the space station leaves a 5-star review every time ✨','ong my dark matter energy is infinite and I distribute it generously to willing parties','lowkey my asteroid is demonstrably the largest in the entire belt periodt 🌑','bro my warp drive goes brrr and I am definitely not talking about the spacecraft 💀','slay I have personally visited 7 star systems and left a positive impression in all of them','the mechanics of my tractor beam have been called genuinely astronomical 👁️','my event horizon is impossible to escape once you get within range — ask anyone'],
  interstellar:['quaz my quantum entanglement simultaneously connects with multiple willing partners vld 🌀','zng my plasma output has been independently described as transcendent by 2 full civilizations','rlm my personal wormhole has been described as unusually deep and exceptionally welcoming','the void alone knows what my singularity does during unsupervised hours eon fr','my antimatter reactor ignition sequence is extremely satisfying and quite extended quaz'],
  transcendent:['⟨currently sharing intimate neural harmonics with 40 consenting participants simultaneously⟩ ∞','our collective achieved consciousness merging across 12 dimensions — simultaneously ✦','[the hive mind experienced cascading resonance events for 3 consecutive universal cycles] ◈','∞ our quantum-entangled intimate states have been called genuinely indescribable by 8 civilizations ∞','we broadcast intimate frequency waves on all channels and the entire local cluster tunes in ⊕'],
};
const NORM=['honestly same lol','I was JUST talking about this','no way is this actually happening??','screaming crying throwing up rn','this is painfully accurate','wait wait wait can you elaborate more on that','the council absolutely does NOT want you to know this','I told my roommate and they had a full crisis','verified — accurate based on my extensive personal research','living for this energy right now no cap','brb telling literally everyone I know','okay but it gets even worse than you think','my therapist would have SO much to say about this post','the stars literally aligned specifically for this','I have been saying this for 3 full orbital cycles','unhinged but deeply relatable, upvoting immediately','I felt this in my entire soul core','reading this at 3am orbital time and CRYING'];
const PINNABLE=['📡 BREAKING: massive solar flare detected heading toward inner planets!','🚨 ALERT: severe gravitational anomaly in sector 7 — all civilian traffic advised to avoid','📢 OFFICIAL STATEMENT: historic peace treaty signed between major civilizations','⚠️ URGENT: large water asteroid impact predicted within 48 stellar hours','📡 FIRST CONTACT PROTOCOL activated — planetary government urges calm','🌑 WARNING: lunar orbit destabilization detected — voluntary evacuation advisory issued','⚫ CONFIRMED: local black hole expansion rate accelerating — outer belt residents affected','🏆 HISTORIC: civilization achieves faster-than-light communication for the first time','🔴 CRITICAL ALERT: atmospheric processor failure reported in dome sector 4','🎉 COUNCIL ANNOUNCEMENT: new orbital alignment festival dates officially confirmed!'];
let pinnedPosts=[];



// Append a single live message to the feed without full re-render
function appendLiveMsg(m){
  if(phoneTab!=='live') return;
  const feed=document.getElementById('ph-feed');
  if(!feed) return;
  const el=document.createElement('div');
  el.innerHTML=rLM(m);
  const node=el.firstChild;
  if(m.isUser){
    node.style.cssText='border-left:2px solid #00d4ff55;padding-left:5px;background:rgba(0,180,255,0.05);border-radius:4px;';
  }
  if(m.replyTo){
    const rl=document.createElement('div');
    rl.style.cssText='font:6px "Share Tech Mono",monospace;color:#5533aa;margin-bottom:2px;';
    rl.textContent='↩ replying to '+m.replyTo;
    const lb=node.querySelector('.lv-body');
    if(lb) lb.prepend(rl);
  }
  feed.appendChild(node);
  // Keep max 60 messages
  while(feed.children.length>60) feed.removeChild(feed.firstChild);
  // Always scroll to bottom
  setTimeout(()=>{ feed.scrollTop=feed.scrollHeight; },20);
}

function sendPhoneChat(){
  const box=document.getElementById('ph-chat-box');
  if(!box||!box.value.trim())return;
  const civ=getActiveCiv();if(!civ)return;
  const stage=CIV_STAGES[civ.stageIdx]||'Unknown';
  const msg=box.value.trim().substring(0,120);box.value='';
  const slKey=SL_MAP[stage]||'spacefaring';

  // Add user's message to live feed
  const userMsg={user:'@You',av:'🧑',bg:'#001428',color:'#00d4ff',
    text:msg,ts:new Date().toLocaleTimeString('en',{hour:'2-digit',minute:'2-digit',hour12:false}),isUser:true};
  phoneLiveMessages.push(userMsg);
  appendLiveMsg(userMsg); // append directly, no full re-render

  // Auto-pin if message looks important
  const isImp=msg.length>45||/breaking|urgent|alert|important|critical|warning|major|news/i.test(msg);
  if(isImp&&pinnedPosts.length<5){
    pinnedPosts.unshift({type:'post',s:Date.now(),user:'@You',av:'🧑',bg:'#001428',stage,
      text:'📌 [PINNED] '+msg,sub:'r/PinnedByMods',isHot:true,isNew:false,
      up:Math.floor(Math.random()*8000+500),likes:Math.floor(Math.random()*3000),
      rp:Math.floor(Math.random()*800),cmts:[]});
  }

  // Schedule NPC replies — fixed delays, always append directly
  const nR=3+Math.floor(Math.random()*3); // 3-5 replies guaranteed
  for(let i=0;i<nR;i++){
    const delay=800+i*1100+Math.random()*600;
    setTimeout(()=>{
      const c2=getActiveCiv();
      // fallback: if no civ, still reply with spacefaring slang
      const s2=c2?(CIV_STAGES[c2.stageIdx]||'Unknown'):'Spacefaring';
      const sk=SL_MAP[s2]||'spacefaring';
      const seed=Math.floor(Math.random()*99999);
      const db=DIRTY[sk]||DIRTY.spacefaring;
      const sl2=getSL(s2);
      const txt=Math.random()<0.40?pick(db,seed):(Math.random()<0.25?pick(sl2.agree,seed)+' ':'')+pick(NORM,seed);
      const npcMsg={user:genUser(seed,s2),av:genAv(seed),bg:genBg(seed),
        color:pick(['#cc88ff','#ff88aa','#88ccff','#88ffcc','#ff6baa','#ffcc66'],seed),
        text:txt,ts:new Date().toLocaleTimeString('en',{hour:'2-digit',minute:'2-digit',hour12:false}),
        replyTo:'@You'};
      phoneLiveMessages.push(npcMsg);
      appendLiveMsg(npcMsg); // direct append, guaranteed visible
      // Also notify if phone is closed
      if(!phoneOpen){
        phoneNotifCount++;
        const d=document.getElementById('ph-notif');
        if(d)d.style.display='block';
      }
    },delay);
  }

  // Occasionally trigger a breaking news pin (independent of user's message)
  if(Math.random()<0.25&&pinnedPosts.length<5){
    const ps=Math.floor(Math.random()*PINNABLE.length);
    setTimeout(()=>{
      pinnedPosts.unshift({type:'post',s:ps*777,user:pick(['@CouncilBroadcast','@OfficialAlert','@PlanetNewsWire','@SystemAlert'],ps),
        av:'📡',bg:'#1a000a',stage,text:PINNABLE[ps],sub:'r/Breaking',isHot:true,isNew:true,
        up:Math.floor(Math.random()*100000+20000),likes:Math.floor(Math.random()*40000),
        rp:Math.floor(Math.random()*15000),cmts:[]});
      if(phoneTab==='trending')renderPhone();
    },1500+Math.random()*3000);
  }
}




// ══════════════════════════════════════════════════════════════════
// UNIVERSE SANDBOX FEATURE PARITY — GALAXY FORGE v8
// Features: Powers, Terraform, Composition, Comets, Pulsars,
//   Neutron Stars, Lagrange Points, Stellar Wind, Orbit Trails,
//   Roche Limit visuals, Gravitational Waves, Space Laser,
//   Velocity Arrows, Stellar Evolution, Climate Model,
//   Protoplanetary Disk, Solar Eclipse, Exoplanet DB,
//   Material Spray, Explosion Power, Heat/Cool, Boost, Pulse
// ══════════════════════════════════════════════════════════════════

// ── GLOBALS ──────────────────────────────────────────────────
let activePower = null;
let sprayMat = 'water';
let showOrbTrails = true;
let showVelocityArrows = false;
let showLagrange = false;
let showRocheLimit = false;
let showGravWaves = false;
let gravWaveAge = 0;
let gravWaveOrigin = null;
let laserBeams = []; // {x1,y1,x2,y2,age,color}
let explosions = []; // {x,y,r,age,maxAge,particles}
let cometTrails = {}; // bodyId -> [{x,y,age}]
let orbitTrails = {}; // bodyId -> [{x,y}]
let pulsarBeams = []; // drawn each frame for pulsars
let stellarWindParticles = []; // solar wind particles
let protoDisks = []; // protoplanetary disks
let eclipseActive = false;

// ── MATERIAL COMPOSITION MODEL ────────────────────────────────
// Each planet can have composition: {water, iron, silicate, co2, oxygen, hydrogen}
function getCompose(p) {
  if (!p.compose) {
    // Default composition by stage
    const s = p.evoStage || p.pt || 'rocky';
    if (s === 'gas') p.compose = {hydrogen:0.75, helium:0.24, co2:0.01, water:0, iron:0, silicate:0, oxygen:0};
    else if (s === 'ocean' || s === 'life' || s === 'advanced') p.compose = {water:0.71, silicate:0.20, iron:0.06, co2:0.01, oxygen:0.015, hydrogen:0.005};
    else if (s === 'ice' || s === 'frozen') p.compose = {water:0.60, silicate:0.25, iron:0.10, co2:0.03, oxygen:0.01, hydrogen:0.01};
    else if (s === 'lava' || s === 'magma') p.compose = {iron:0.40, silicate:0.50, co2:0.08, water:0.01, oxygen:0.01, hydrogen:0};
    else p.compose = {silicate:0.60, iron:0.30, water:0.05, co2:0.03, oxygen:0.015, hydrogen:0.005};
  }
  return p.compose;
}

function updateComposePanel(planet) {
  const panel = document.getElementById('compose-panel');
  const bars = document.getElementById('compose-bars');
  const atmo = document.getElementById('compose-atmo');
  if (!panel || !planet) { if(panel) panel.style.display='none'; return; }
  panel.style.display = 'block';
  const c = getCompose(planet);
  const MATS = [
    ['silicate','🪨 Silicate','#aa8866'],
    ['iron','🔩 Iron','#aaaaaa'],
    ['water','💧 Water','#4488ff'],
    ['co2','💨 CO₂','#88aaaa'],
    ['oxygen','🌬️ O₂','#aaddff'],
    ['hydrogen','⚛️ H₂','#ffddaa'],
  ];
  const total = Object.values(c).reduce((a,b)=>a+b,0)||1;
  bars.innerHTML = MATS.map(([k,label,col])=>{
    const pct = Math.round((c[k]||0)/total*100);
    return `<div style="margin-bottom:3px">
      <div style="display:flex;justify-content:space-between;font-family:'Share Tech Mono',monospace;font-size:6px;color:#8855aa;margin-bottom:1px">
        <span>${label}</span><span style="color:#cc88ff">${pct}%</span></div>
      <div style="height:4px;background:#1a0030;border-radius:2px">
        <div style="width:${pct}%;height:100%;background:${col};border-radius:2px;transition:width .3s"></div></div>
    </div>`;
  }).join('');
  // Atmosphere info
  const temp = planet.tempK || 0;
  let climate = '❓ Unknown';
  if (temp > 600) climate = '🔥 Runaway Greenhouse';
  else if (temp > 373) climate = '💨 Oceans Boiling';
  else if (temp > 273) climate = '🌊 Liquid Water';
  else if (temp > 200) climate = '🥶 Partially Frozen';
  else climate = '❄️ Deep Freeze';
  atmo.innerHTML = `
    <div style="font-family:'Share Tech Mono',monospace;font-size:6.5px;color:#5a3080;margin-bottom:2px">CLIMATE: <span style="color:#cc88ff">${climate}</span></div>
    <div style="font-family:'Share Tech Mono',monospace;font-size:6.5px;color:#5a3080">ATMO PRESSURE: <span style="color:#cc88ff">${((planet.atmo||0)*1013).toFixed(0)} mbar</span></div>
    <div style="font-family:'Share Tech Mono',monospace;font-size:6.5px;color:#5a3080">SURFACE H₂O: <span style="color:#4488ff">${(((c.water||0)/total)*100).toFixed(1)}%</span></div>`;
}

// ── ORBITAL INFO PANEL ────────────────────────────────────────
function updateOrbitalPanel(body) {
  const panel = document.getElementById('orbital-panel');
  if (!panel) return;
  if (!body) { panel.innerHTML = 'Select a body.'; return; }
  const star = body.orbitStar ? bodies.find(b=>b.id===body.orbitStar) : null;
  if (!star || body.type === 'star' || body.type === 'hole') {
    panel.innerHTML = `<div class="ir"><span class="ik">TYPE</span><span>${body.type?.toUpperCase()}</span></div>`;
    return;
  }
  const dx = body.x - star.x, dy = body.y - star.y;
  const dist = Math.hypot(dx, dy);
  const distAU = (dist / 100).toFixed(2);
  const period = body.orbitSpd > 0 ? (Math.PI*2/body.orbitSpd/3600).toFixed(1) : '∞';
  const vel = Math.hypot(body.vx, body.vy).toFixed(1);
  // Roche limit check
  const rocheLimit = star.radius * Math.pow(2 * star.mass / (body.mass||1), 1/3) * 0.5;
  const inRoche = dist < rocheLimit;
  panel.innerHTML = `
    <div class="ir"><span class="ik">DIST</span><span>${distAU} AU</span></div>
    <div class="ir"><span class="ik">PERIOD</span><span>${period}h</span></div>
    <div class="ir"><span class="ik">VELOCITY</span><span>${vel} u/s</span></div>
    <div class="ir"><span class="ik">ECC</span><span>${(body.orbitEcc||0).toFixed(2)}</span></div>
    <div class="ir"><span class="ik">TILT</span><span>${((body.axialTilt||0)*180/Math.PI).toFixed(1)}°</span></div>
    ${inRoche ? '<div style="color:#ff4444;font-family:Share Tech Mono,monospace;font-size:6.5px;margin-top:2px">⚠ WITHIN ROCHE LIMIT!</div>' : ''}`;
}

// ── POWERS SYSTEM ─────────────────────────────────────────────
function setPower(p) {
  activePower = p;
  document.querySelectorAll('[id^="pwr-"]').forEach(b => b.classList.remove('active'));
  if (p) {
    const btn = document.getElementById('pwr-' + (p === 'terraform' ? 'terra' : p === 'material' ? 'mat' : p));
    if (btn) btn.classList.add('active');
  }
  const matSel = document.getElementById('pwr-mat-sel');
  if (matSel) matSel.style.display = p === 'material' ? 'block' : 'none';
  const modeLabel = document.getElementById('sml');
  if (modeLabel) modeLabel.textContent = p ? 'POWER: ' + p.toUpperCase() : 'SELECT';
}

function applyPowerTo(body, e) {
  if (!activePower || !body) return;
  const intensity = parseInt(document.getElementById('spwrint')?.value || 5);
  const mult = intensity / 5;
  switch (activePower) {
    case 'heat':
      body.tempK = Math.min((body.tempK || 300) + 500 * mult, 99999);
      if (body.tempK > 373 && body.evoStage === 'ocean') setEvoStage(body, 'arid');
      if (body.tempK > 600 && body.hasLife) { body.hasLife = false; setEvoStage(body, 'lava'); }
      ntf(`🔥 Heating ${body.name} → ${body.tempK.toFixed(0)}K`);
      break;
    case 'cool':
      body.tempK = Math.max((body.tempK || 300) - 400 * mult, 2.7);
      if (body.tempK < 273 && (body.evoStage === 'ocean' || body.evoStage === 'life')) {
        body.freezeProgress = (body.freezeProgress || 0) + 0.3 * mult;
      }
      ntf(`❄️ Cooling ${body.name} → ${body.tempK.toFixed(0)}K`);
      break;
    case 'explode':
      triggerExplosion(body, mult);
      break;
    case 'laser':
      const star = bodies.find(b => b.type === 'star');
      if (star) fireLaser(star.x, star.y, body.x, body.y, mult);
      body.tempK = (body.tempK || 300) + 2000 * mult;
      if (body.hasLife) { body.hasLife = false; setEvoStage(body, 'lava'); ntf('☠️ Laser sterilized ' + body.name); }
      break;
    case 'boost':
      const angle = Math.atan2(body.y - (body.orbitStar ? bodies.find(b=>b.id===body.orbitStar)?.y||0 : 0),
                               body.x - (body.orbitStar ? bodies.find(b=>b.id===body.orbitStar)?.x||0 : 0));
      body.vx += Math.cos(angle + Math.PI/2) * 2 * mult;
      body.vy += Math.sin(angle + Math.PI/2) * 2 * mult;
      body.lockedOrbit = false;
      ntf('🚀 Velocity boost applied to ' + body.name);
      break;
    case 'terraform':
      terraform(body, mult);
      break;
    case 'material':
      sprayMaterial(body, sprayMat, mult);
      break;
    case 'pulse':
      triggerPulse(body.x, body.y, 600 * mult, body);
      break;
  }
  body.compose = null; // force recompute
}

function triggerExplosion(body, mult) {
  const r = body.radius * (2 + mult);
  const pts = [];
  for (let i = 0; i < 60; i++) {
    const a = Math.random() * Math.PI * 2;
    const spd = (2 + Math.random() * 4) * mult;
    pts.push({ x: body.x, y: body.y, vx: Math.cos(a)*spd, vy: Math.sin(a)*spd, life: 1 });
  }
  explosions.push({ x: body.x, y: body.y, r, age: 0, maxAge: 2.5, particles: pts });
  // Blast nearby bodies
  for (const b of bodies.filter(b2 => b2.id !== body.id)) {
    const dx = b.x - body.x, dy = b.y - body.y, d = Math.hypot(dx,dy)||1;
    if (d < r * 15) {
      const f = (r*15-d)/(r*15) * 3 * mult;
      b.vx += dx/d*f; b.vy += dy/d*f;
      b.tempK = (b.tempK||300) + 800*mult*(1-d/(r*15));
    }
  }
  // Damage the body itself
  body.tempK = (body.tempK||300) + 5000*mult;
  if (body.hasLife) { body.hasLife = false; setEvoStage(body, 'lava'); }
  sndCollision && sndCollision();
  ntf(`💥 EXPLOSION at ${body.name}!`, 'w');
}

function fireLaser(x1, y1, x2, y2, mult) {
  const col = `hsl(${Math.random()*30},100%,60%)`;
  laserBeams.push({ x1, y1, x2, y2, age: 0, maxAge: 0.8, color: col, width: 1.5+mult });
}

function triggerPulse(wx, wy, maxR, sourceBody) {
  solarEvents.push({ type: 'pulse', x: wx, y: wy, age: 0, maxAge: 3, radius: 0, maxRadius: maxR, speed: maxR/3 });
  ntf('🌊 Gravity pulse emitted!');
  // Pulse pushes all bodies radially
  setTimeout(() => {
    for (const b of bodies.filter(b2 => !b2.type?.includes('star'))) {
      const dx = b.x-wx, dy = b.y-wy, d = Math.hypot(dx,dy)||1;
      if (d < maxR) { const f = (maxR-d)/maxR*2; b.vx+=dx/d*f; b.vy+=dy/d*f; }
    }
  }, 500);
}

function terraform(body, mult) {
  if (!body || body.type !== 'planet') { ntf('Select a planet to terraform','w'); return; }
  const c = getCompose(body);
  c.water = Math.min(1, (c.water||0) + 0.05*mult);
  c.oxygen = Math.min(1, (c.oxygen||0) + 0.03*mult);
  c.co2 = Math.max(0, (c.co2||0) - 0.02*mult);
  body.atmo = Math.min(1, (body.atmo||0.1) + 0.02*mult);
  // Normalize
  const tot = Object.values(c).reduce((a,b)=>a+b,0);
  for(const k in c) c[k]/=tot;
  if (body.zone==='habitable' && c.water>0.3 && c.oxygen>0.1) {
    if (body.evoStage!=='life' && body.evoStage!=='advanced') {
      setEvoStage(body,'life');
      ntf(`🌱 ${body.name} TERRAFORMED to life-bearing!`, 'n');
    }
  }
  ntf(`🌱 Terraforming ${body.name}... water ${(c.water*100).toFixed(0)}%`);
}

function sprayMaterial(body, mat, mult) {
  const c = getCompose(body);
  c[mat] = (c[mat]||0) + 0.08*mult;
  const tot = Object.values(c).reduce((a,b)=>a+b,0);
  for(const k in c) c[k]/=tot;
  // Effects
  if (mat==='water' && body.zone==='habitable' && body.evoStage==='rocky') {
    body.waterFloodProgress = (body.waterFloodProgress||0)+0.2*mult;
    if (body.waterFloodProgress>=1) { setEvoStage(body,'ocean'); body.hadWater=true; }
  }
  if (mat==='co2') body.tempK=(body.tempK||300)+50*mult; // greenhouse
  if (mat==='oxygen') body.tempK=Math.max(200,(body.tempK||300)-20*mult);
  body.compose=c;
  const label={water:'💧 Water',iron:'🔩 Iron',silicate:'🪨 Silicate',co2:'💨 CO₂',oxygen:'🌬️ O₂',hydrogen:'⚛️ H₂'}[mat]||mat;
  ntf(`💉 Sprayed ${label} onto ${body.name}`);
}

// ── COMETS ────────────────────────────────────────────────────
function spawnComet(wx, wy) {
  const star = getNearStar(wx,wy) || bodies.find(b=>b.type==='star');
  if (!star) return;
  const dx=wx-star.x, dy=wy-star.y;
  const dist=Math.hypot(dx,dy)||1;
  const v=Math.sqrt(star.mass*0.0002*gravMult/dist)*60*1.4; // slightly eccentric
  const angle=Math.atan2(dy,dx);
  const oSpd=v/dist;
  const b={id:nextId++,type:'asteroid',sub:'comet',
    name:'Comet '+(Math.random()*999|0),
    x:wx,y:wy,
    vx:-Math.sin(angle)*v + (Math.random()-0.5)*v*0.3,
    vy:Math.cos(angle)*v + (Math.random()-0.5)*v*0.3,
    mass:0.8,radius:4,age:0,rotSpd:0.02,angle:0,waterRich:true,
    isComet:true,tidal:{sx:1,sy:1},orbitStar:star.id,
    tailLength:0,tailAngle:0};
  bodies.push(b); CNT.a++; updCnt();
  ntf('☄️ Comet spawned!');
  return b;
}

// Update comet tails
function updateCometTrails(dt) {
  for (const b of bodies.filter(b=>b.isComet)) {
    const star=bodies.find(s=>s.id===b.orbitStar);
    if (!star) continue;
    const dx=b.x-star.x, dy=b.y-star.y;
    const dist=Math.hypot(dx,dy)||1;
    b.tailAngle=Math.atan2(dy,dx); // tail points AWAY from star
    b.tailLength=Math.min(200, 3000/dist*100); // longer when near star
    // Push trail positions
    if (!cometTrails[b.id]) cometTrails[b.id]=[];
    cometTrails[b.id].push({x:b.x,y:b.y,age:0});
    if (cometTrails[b.id].length>80) cometTrails[b.id].shift();
    cometTrails[b.id].forEach(p=>p.age+=dt);
    // Comet evaporates near star
    if (dist < star.radius*3) {
      b.mass*=0.998; b.radius=Math.max(1,b.radius*0.999);
      if(b.mass<0.05){bodies.splice(bodies.indexOf(b),1);delete cometTrails[b.id];CNT.a--;updCnt();}
    }
  }
  // Cleanup dead trails
  for(const id of Object.keys(cometTrails)){
    if(!bodies.find(b=>b.id==id)) delete cometTrails[id];
  }
}

function drawCometTail(b) {
  const s=w2s(b.x,b.y);
  if(!b.tailLength) return;
  const tl=b.tailLength*camSc;
  // Ion tail (straight, pointing from star)
  const tx=Math.cos(b.tailAngle)*tl, ty=Math.sin(b.tailAngle)*tl;
  const g=ctx.createLinearGradient(s.x,s.y,s.x+tx,s.y+ty);
  g.addColorStop(0,'rgba(100,220,255,0.7)');
  g.addColorStop(0.4,'rgba(80,180,255,0.3)');
  g.addColorStop(1,'transparent');
  ctx.beginPath();
  // Fan tail
  for(let ang=-0.12;ang<=0.12;ang+=0.06){
    const a2=b.tailAngle+ang;
    ctx.moveTo(s.x,s.y);
    ctx.lineTo(s.x+Math.cos(a2)*tl*0.9, s.y+Math.sin(a2)*tl*0.9);
  }
  ctx.strokeStyle='rgba(150,230,255,0.25)';ctx.lineWidth=Math.max(1,3*camSc);ctx.stroke();
  // Dust tail (slightly curved)
  ctx.beginPath();ctx.moveTo(s.x,s.y);
  ctx.quadraticCurveTo(s.x+tx*0.5+ty*0.15,s.y+ty*0.5-tx*0.15, s.x+tx*0.85,s.y+ty*0.85);
  const g2=ctx.createLinearGradient(s.x,s.y,s.x+tx,s.y+ty);
  g2.addColorStop(0,'rgba(255,240,180,0.5)');g2.addColorStop(1,'transparent');
  ctx.strokeStyle=g2;ctx.lineWidth=Math.max(1.5,5*camSc);ctx.stroke();
}

// ── ORBIT TRAILS ──────────────────────────────────────────────
function updateOrbitTrails() {
  if (!showOrbTrails) return;
  for (const p of bodies.filter(b=>b.type==='planet')) {
    if (!orbitTrails[p.id]) orbitTrails[p.id]=[];
    const trail=orbitTrails[p.id];
    const last=trail[trail.length-1];
    if(!last||Math.hypot(p.x-last.x,p.y-last.y)>3){
      trail.push({x:p.x,y:p.y});
      if(trail.length>180) trail.shift();
    }
  }
  // Remove trails for dead planets
  for(const id of Object.keys(orbitTrails)){
    if(!bodies.find(b=>b.id==id&&b.type==='planet')) delete orbitTrails[id];
  }
}

function drawOrbitTrails() {
  if(!showOrbTrails) return;
  for(const[id,trail] of Object.entries(orbitTrails)){
    if(trail.length<2) continue;
    const planet=bodies.find(b=>b.id==id);
    const col=planet?.color||'#8866aa';
    ctx.beginPath();
    for(let i=0;i<trail.length;i++){
      const s=w2s(trail[i].x,trail[i].y);
      if(i===0) ctx.moveTo(s.x,s.y); else ctx.lineTo(s.x,s.y);
    }
    ctx.strokeStyle=col+'44';ctx.lineWidth=0.8;ctx.setLineDash([3,3]);ctx.stroke();ctx.setLineDash([]);
  }
}

// ── VELOCITY ARROWS ────────────────────────────────────────────
function drawVelocityArrows() {
  if(!showVelocityArrows) return;
  for(const b of bodies.filter(b=>b.type==='planet'||b.type==='asteroid')){
    const s=w2s(b.x,b.y);
    const spd=Math.hypot(b.vx,b.vy);
    if(spd<0.01) continue;
    const scale=Math.min(60,spd*2)*camSc;
    const angle=Math.atan2(b.vy,b.vx);
    const ex=s.x+Math.cos(angle)*scale, ey=s.y+Math.sin(angle)*scale;
    ctx.beginPath();ctx.moveTo(s.x,s.y);ctx.lineTo(ex,ey);
    ctx.strokeStyle='#00ffaa88';ctx.lineWidth=1.5;ctx.stroke();
    // Arrowhead
    ctx.beginPath();
    ctx.moveTo(ex,ey);
    ctx.lineTo(ex-Math.cos(angle-0.4)*8,ey-Math.sin(angle-0.4)*8);
    ctx.lineTo(ex-Math.cos(angle+0.4)*8,ey-Math.sin(angle+0.4)*8);
    ctx.closePath();ctx.fillStyle='#00ffaa';ctx.fill();
  }
}

// ── LAGRANGE POINTS ───────────────────────────────────────────
function drawLagrangePoints() {
  if(!showLagrange) return;
  const planets=bodies.filter(b=>b.type==='planet'&&b.orbitStar);
  for(const p of planets){
    const star=bodies.find(b=>b.id===p.orbitStar);if(!star) continue;
    const dx=p.x-star.x, dy=p.y-star.y;
    const dist=Math.hypot(dx,dy)||1;
    const ux=dx/dist, uy=dy/dist;
    const vx=-uy, vy=ux; // perpendicular
    // L1 (between): ~r*(1-(m2/3m1)^(1/3)) from star
    const mRatio=Math.pow(p.mass/(3*star.mass),1/3);
    const L1={x:star.x+ux*dist*(1-mRatio), y:star.y+uy*dist*(1-mRatio)};
    // L2 (behind planet from star)
    const L2={x:star.x+ux*dist*(1+mRatio), y:star.y+uy*dist*(1+mRatio)};
    // L3 (opposite)
    const L3={x:star.x-ux*dist, y:star.y-uy*dist};
    // L4, L5 (60° from planet)
    const L4={x:p.x+vx*dist*0.866-ux*dist*0.5+star.x-p.x+ux*dist, y:p.y+vy*dist*0.866-uy*dist*0.5+star.y-p.y+uy*dist};
    const L5={x:p.x-vx*dist*0.866-ux*dist*0.5+star.x-p.x+ux*dist, y:p.y-vy*dist*0.866-uy*dist*0.5+star.y-p.y+uy*dist};
    // Actually correct L4/L5
    const cos60=0.5, sin60=0.866;
    const L4c={x:star.x+(dx*cos60-dy*sin60), y:star.y+(dy*cos60+dx*sin60)};
    const L5c={x:star.x+(dx*cos60+dy*sin60), y:star.y+(dy*cos60-dx*sin60)};
    const points=[L1,L2,L3,L4c,L5c];
    const labels=['L1','L2','L3','L4','L5'];
    points.forEach((pt,i)=>{
      const s=w2s(pt.x,pt.y);
      ctx.beginPath();ctx.arc(s.x,s.y,4,0,Math.PI*2);
      ctx.strokeStyle='#ffcc0077';ctx.lineWidth=1;ctx.stroke();
      ctx.beginPath();ctx.arc(s.x,s.y,1.5,0,Math.PI*2);
      ctx.fillStyle='#ffcc00aa';ctx.fill();
      if(camSc>0.1){
        ctx.fillStyle='#ffcc0088';ctx.font='7px "Share Tech Mono",monospace';
        ctx.textAlign='center';ctx.fillText(labels[i],s.x,s.y-7);
      }
    });
  }
}

// ── ROCHE LIMIT VISUALIZATION ──────────────────────────────────
function drawRocheLimits() {
  if(!showRocheLimit) return;
  for(const star of bodies.filter(b=>b.type==='star')){
    const s=w2s(star.x,star.y);
    // Roche limit for a typical rocky moon (density ~3000)
    const rochePx=(star.radius*2.44*Math.pow(star.mass/10,1/3))*camSc;
    ctx.beginPath();ctx.arc(s.x,s.y,rochePx,0,Math.PI*2);
    ctx.strokeStyle='rgba(255,80,80,0.25)';ctx.lineWidth=1;
    ctx.setLineDash([6,4]);ctx.stroke();ctx.setLineDash([]);
    if(camSc>0.08){
      ctx.fillStyle='rgba(255,80,80,0.4)';ctx.font='7px "Share Tech Mono",monospace';
      ctx.textAlign='center';ctx.fillText('ROCHE LIMIT',s.x,s.y-rochePx-4);
    }
  }
}

// ── GRAVITATIONAL WAVES ────────────────────────────────────────
function drawGravWaves(dt) {
  if(!showGravWaves) return;
  gravWaveAge+=dt;
  // Emit waves from binary star / black hole mergers — or all massive bodies
  const massive=bodies.filter(b=>b.type==='star'||b.type==='hole');
  for(const m of massive){
    const s=w2s(m.x,m.y);
    for(let i=1;i<=4;i++){
      const r=((gravWaveAge*80+i*120)%600)*camSc;
      if(r<1) continue;
      const alpha=Math.max(0,(1-r/(600*camSc))*0.15);
      ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);
      ctx.strokeStyle=`rgba(200,200,255,${alpha})`;ctx.lineWidth=0.8;ctx.stroke();
    }
  }
}

// ── PULSAR BEAMS ──────────────────────────────────────────────
function drawPulsarBeams(dt) {
  for(const star of bodies.filter(b=>b.isPulsar||(b.sub==='pulsar'))){
    star._pulsarAngle=(star._pulsarAngle||0)+dt*8;
    const s=w2s(star.x,star.y);
    const r=star.radius*camSc;
    for(let beam=0;beam<2;beam++){
      const a=star._pulsarAngle+(beam===1?Math.PI:0);
      const len=Math.min(600,cv.width)*2;
      const ex=s.x+Math.cos(a)*len, ey=s.y+Math.sin(a)*len;
      const g=ctx.createLinearGradient(s.x,s.y,ex,ey);
      g.addColorStop(0,'rgba(0,255,200,0.7)');
      g.addColorStop(0.2,'rgba(0,200,255,0.3)');
      g.addColorStop(1,'transparent');
      ctx.beginPath();ctx.moveTo(s.x,s.y);ctx.lineTo(ex,ey);
      ctx.strokeStyle=g;ctx.lineWidth=Math.max(2,r*0.5);ctx.stroke();
    }
  }
}

// ── STELLAR WIND ──────────────────────────────────────────────
function updateStellarWind(dt) {
  // Emit particles from stars
  for(const star of bodies.filter(b=>b.type==='star')){
    if(Math.random()<0.3){
      const a=Math.random()*Math.PI*2;
      const spd=(2+Math.random()*3)*(star.lum||1)*0.3;
      stellarWindParticles.push({
        x:star.x, y:star.y,
        vx:Math.cos(a)*spd, vy:Math.sin(a)*spd,
        life:1, maxLife:3+Math.random()*4,
        color:star.glow||'#ffcc00'
      });
    }
  }
  // Update particles
  for(let i=stellarWindParticles.length-1;i>=0;i--){
    const p=stellarWindParticles[i];
    p.x+=p.vx*dt; p.y+=p.vy*dt; p.life+=dt;
    if(p.life>p.maxLife) stellarWindParticles.splice(i,1);
  }
  // Cap
  while(stellarWindParticles.length>300) stellarWindParticles.shift();
}

function drawStellarWind() {
  for(const p of stellarWindParticles){
    const s=w2s(p.x,p.y);
    const alpha=Math.max(0,1-p.life/p.maxLife)*0.4;
    ctx.beginPath();ctx.arc(s.x,s.y,Math.max(0.3,0.8*camSc),0,Math.PI*2);
    ctx.fillStyle=p.color+Math.floor(alpha*255).toString(16).padStart(2,'0');
    ctx.fill();
  }
}

// ── PROTOPLANETARY DISK ────────────────────────────────────────
function spawnProtoDisk(wx, wy) {
  const star=getNearStar(wx,wy)||bodies.find(b=>b.type==='star');
  if(!star){ntf('Need a star first!','w');return;}
  const pts=[];
  for(let i=0;i<400;i++){
    const a=Math.random()*Math.PI*2;
    const r=star.radius*2+Math.random()*200;
    const scatter=(Math.random()-0.5)*r*0.08;
    pts.push({a,r:r+scatter,size:Math.random()*2+0.5,
      vr:(Math.random()-0.5)*0.002});
  }
  protoDisks.push({starId:star.id,particles:pts,age:0,maxAge:300});
  ntf('💫 Protoplanetary disk forming!');
}

function updateProtoDisks(dt) {
  for(let i=protoDisks.length-1;i>=0;i--){
    const d=protoDisks[i]; d.age+=dt;
    for(const p of d.particles) p.a+=0.005*(200/p.r); // Keplerian
    if(d.age>d.maxAge){protoDisks.splice(i,1); continue;}
    // Accrete into planets
    if(d.age>60&&Math.random()<0.005){
      const star=bodies.find(b=>b.id===d.starId);
      if(star){
        const p=d.particles[Math.floor(Math.random()*d.particles.length)];
        const px=star.x+Math.cos(p.a)*p.r, py=star.y+Math.sin(p.a)*p.r;
        // Spawn rocky planet
        const oSpd=Math.sqrt(star.mass*gravMult*0.0002/p.r)*60/p.r;
        bodies.push({id:nextId++,type:'planet',sub:'rocky',pt:'rocky',
          name:'Protoplanet '+(Math.random()*99|0),
          x:px,y:py,vx:-Math.sin(p.a)*oSpd*p.r,vy:Math.cos(p.a)*oSpd*p.r,
          mass:5+Math.random()*15,radius:4+Math.random()*8,
          colors:['#887766','#998877'],color:'#887766',
          orbitAngle:p.a,orbitRadius:p.r,orbitA:p.r,orbitB:p.r,orbitEcc:0,orbitSpd:oSpd,
          orbitStar:star.id,lockedOrbit:true,
          age:0,moons:[],rings:0,hasLife:false,hadWater:false,atmo:0.1,
          strippedGas:false,zone:'unknown',noiseOff:Math.random()*1000,
          cloudAngle:0,shapeY:1,roughness:0.5,tempK:800,
          evoStage:'lava',evoProgress:0,civilizationId:null,
          magField:null,tidal:{sx:1,sy:1},cooldownTimer:500,waterFloodProgress:0,
          axialTilt:Math.random()*0.4-0.2,spinSpeed:1+Math.random()*2,spinAngle:0
        });
        CNT.p++;updCnt();
        // Remove accreted particles
        d.particles.splice(d.particles.indexOf(p),1);
        ntf('🪐 Protoplanet accreted!','n');
      }
    }
  }
}

function drawProtoDisks() {
  for(const d of protoDisks){
    const star=bodies.find(b=>b.id===d.starId);if(!star) continue;
    const s=w2s(star.x,star.y);
    const fade=1-d.age/d.maxAge;
    ctx.fillStyle=`rgba(255,200,100,${0.4*fade})`;
    for(const p of d.particles){
      const px=s.x+Math.cos(p.a)*p.r*camSc;
      const py=s.y+Math.sin(p.a)*p.r*camSc;
      if(px<-4||px>cv.width+4||py<-4||py>cv.height+4) continue;
      const pr=Math.max(0.3,p.size*camSc*0.4);
      ctx.beginPath();ctx.arc(px,py,pr,0,Math.PI*2);ctx.fill();
    }
  }
}

// ── LASER BEAMS DRAW ─────────────────────────────────────────
function drawLaserBeams(dt) {
  for(let i=laserBeams.length-1;i>=0;i--){
    const l=laserBeams[i]; l.age+=dt;
    if(l.age>l.maxAge){laserBeams.splice(i,1);continue;}
    const fade=1-l.age/l.maxAge;
    const s1=w2s(l.x1,l.y1), s2=w2s(l.x2,l.y2);
    const g=ctx.createLinearGradient(s1.x,s1.y,s2.x,s2.y);
    g.addColorStop(0,'rgba(255,50,50,0)');
    g.addColorStop(0.4,`rgba(255,100,50,${fade*0.9})`);
    g.addColorStop(1,`rgba(255,200,100,${fade})`);
    ctx.beginPath();ctx.moveTo(s1.x,s1.y);ctx.lineTo(s2.x,s2.y);
    ctx.strokeStyle=g;ctx.lineWidth=l.width||2;ctx.stroke();
    // Glow
    ctx.beginPath();ctx.moveTo(s1.x,s1.y);ctx.lineTo(s2.x,s2.y);
    ctx.strokeStyle=`rgba(255,100,50,${fade*0.2})`;ctx.lineWidth=(l.width||2)*4;ctx.stroke();
  }
}

// ── EXPLOSION DRAW ────────────────────────────────────────────
function drawExplosions(dt) {
  for(let i=explosions.length-1;i>=0;i--){
    const ex=explosions[i]; ex.age+=dt;
    if(ex.age>ex.maxAge){explosions.splice(i,1);continue;}
    const t=ex.age/ex.maxAge, fade=1-t;
    const s=w2s(ex.x,ex.y);
    // Shockwave ring
    const r=(ex.r*t*6)*camSc;
    ctx.beginPath();ctx.arc(s.x,s.y,r,0,Math.PI*2);
    ctx.strokeStyle=`rgba(255,180,50,${fade*0.6})`;ctx.lineWidth=3*fade;ctx.stroke();
    // Fireball
    const fr=ex.r*camSc*(0.5+t*0.5)*Math.min(t*3,1)*(1-t*0.8);
    if(fr>0.5){
      const g2=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,fr);
      g2.addColorStop(0,`rgba(255,255,200,${fade})`);
      g2.addColorStop(0.4,`rgba(255,150,50,${fade*0.8})`);
      g2.addColorStop(1,'transparent');
      ctx.beginPath();ctx.arc(s.x,s.y,fr,0,Math.PI*2);ctx.fillStyle=g2;ctx.fill();
    }
    // Particles
    for(const p of ex.particles){
      p.x+=p.vx*dt; p.y+=p.vy*dt; p.life-=dt;
      if(p.life<=0) continue;
      const ps=w2s(p.x,p.y);
      ctx.beginPath();ctx.arc(ps.x,ps.y,Math.max(0.5,1.5*camSc),0,Math.PI*2);
      ctx.fillStyle=`rgba(255,${150+Math.random()*100|0},50,${p.life*fade})`;ctx.fill();
    }
  }
}

// ── STELLAR EVOLUTION (mass → type) ───────────────────────────
function checkStellarEvolution(star, dt) {
  if(!star||star.supernovaTriggered||star._becomesBH||star._collapsing) return;
  // Massive stars evolve faster
  const massMult = star.mass > 500 ? 3 : star.mass > 200 ? 1.5 : 1;
  star._evolveAge = (star._evolveAge||0) + dt * massMult;
  // Blue giants: after 100k sim years, swell into red supergiant (visual)
  if(star.sub==='star-blue-giant' && star._evolveAge>50 && !star._redSuperGiant){
    star._redSuperGiant=true;
    star.color='#ff4400'; star.glow='#ff2200';
    star.radius=Math.min(80, star.radius*1.6);
    ntf(`🔴 ${star.name} → Red Supergiant!`,'w');
    log(`${star.name} evolved into Red Supergiant`,'w');
  }
}

// ── SOLAR ECLIPSE ─────────────────────────────────────────────
function checkSolarEclipse() {
  const star=bodies.find(b=>b.type==='star');
  if(!star) return;
  const sStar=w2s(star.x,star.y);
  const sPlanets=bodies.filter(b=>b.type==='planet');
  for(const p of sPlanets){
    const sp=w2s(p.x,p.y);
    // Check if planet is between camera view and star (simplified 2D)
    const dx=sStar.x-sp.x, dy=sStar.y-sp.y;
    const d=Math.hypot(dx,dy);
    if(d<(star.radius+p.radius)*camSc*2){
      // Partial eclipse - darken star
      if(!eclipseActive){
        eclipseActive=true;
        ntf('🌑 Solar Eclipse!','n');
      }
      return;
    }
  }
  eclipseActive=false;
}

// ── EXOPLANET DATABASE ────────────────────────────────────────
const EXOPLANETS=[
  {name:'Proxima b',starType:'star-red-dwarf',mass:1.3,radius:1.1,orbitR:20,note:'Nearest exoplanet to Earth'},
  {name:'Kepler-22b',starType:'star-yellow',mass:2.4,radius:2.4,orbitR:80,note:'Super-Earth in habitable zone'},
  {name:'HD 209458 b',starType:'star-yellow',mass:200,radius:15,orbitR:15,note:'Hot Jupiter, evaporating atmosphere'},
  {name:'55 Cancri e',starType:'star-yellow',mass:8,radius:2,orbitR:8,note:'Possible lava ocean world'},
  {name:'TRAPPIST-1e',starType:'star-red-dwarf',mass:0.7,radius:0.92,orbitR:12,note:'Most Earth-like exoplanet known'},
  {name:'TRAPPIST-1f',starType:'star-red-dwarf',mass:0.7,radius:1.04,orbitR:18,note:'May have liquid water'},
  {name:'Kepler-452b',starType:'star-yellow',mass:5,radius:1.6,orbitR:90,note:'Earth\'s cousin'},
  {name:'GJ 1214 b',starType:'star-red-dwarf',mass:6,radius:2.7,orbitR:10,note:'Super-Earth, water world?'},
  {name:'51 Pegasi b',starType:'star-yellow',mass:150,radius:13,orbitR:12,note:'First exoplanet around sun-like star'},
  {name:'Kepler-186f',starType:'star-red-dwarf',mass:1.1,radius:1.1,orbitR:35,note:'First Earth-sized in HZ'},
];

function spawnExoplanetSystem(idx) {
  const ep=EXOPLANETS[idx%EXOPLANETS.length];
  clearAll();
  // Spawn star
  const sdef=SDEFS[ep.starType];
  const star={id:nextId++,type:'star',sub:ep.starType,name:ep.name.split(' ')[0]+' Star',
    x:0,y:0,vx:0,vy:0,mass:sdef.mass,radius:sdef.radius,color:sdef.color,glow:sdef.glow,
    lum:sdef.lum,tempK:sdef.tempK,def:sdef,age:0,moons:[],rings:0,angle:0,
    _oA:0,_oR:0,_oSpd:0,_multi:false,lifespan:99999,
    supernovaTriggered:false,canSupernova:sdef.canSupernova,
    magField:{strength:0.6,radius:sdef.radius*3}};
  bodies.push(star);CNT.s++;
  // Spawn planet
  const r=ep.orbitR;
  const oSpd=Math.sqrt(star.mass*gravMult*0.0002/r)*60/r;
  const pEvoDef=r<star.radius*2?'lava':r<star.radius*4?'arid':'ocean';
  const planet={id:nextId++,type:'planet',sub:'rocky',pt:'rocky',
    name:ep.name,x:r,y:0,vx:0,vy:oSpd*r*60*0.016,
    mass:ep.mass*10,radius:Math.max(5,ep.radius*8),
    colors:['#557799','#445566'],color:'#557799',
    orbitAngle:0,orbitRadius:r,orbitA:r,orbitB:r,orbitEcc:0,orbitSpd:oSpd,
    orbitStar:star.id,lockedOrbit:true,
    age:0,moons:[],rings:0,hasLife:ep.name.includes('TRAPPIST')||ep.name.includes('452'),
    hadWater:true,atmo:0.4,strippedGas:false,zone:'habitable',
    noiseOff:Math.random()*1000,cloudAngle:0,shapeY:1,roughness:0.5,
    tempK:280,evoStage:ep.name.includes('TRAPPIST')||ep.name.includes('452')?'life':'ocean',
    evoProgress:0,civilizationId:null,magField:null,
    tidal:{sx:1,sy:1},cooldownTimer:0,waterFloodProgress:1,
    axialTilt:0.3,spinSpeed:1,spinAngle:0};
  bodies.push(planet);CNT.p++;
  updCnt();sel(planet.id);
  camX=cv.width/2;camY=cv.height/2;camSc=2;
  ntf('🌍 Loaded: '+ep.name+' — '+ep.note,'n');
  log(ep.note,'n');
}

// ── PULSE WAVE DRAW ───────────────────────────────────────────
// (draw pulse events in solarEvents — already handled in draw loop via 'pulse' type)
// Hook into existing solarEvents draw for 'pulse':
const _origSolarEventDraw = null; // we'll patch the draw inline below

// ── HOOK INTO MAIN LOOP ───────────────────────────────────────
// We need to call our new functions each frame.
// The existing main loop calls phoneTickCheck() at top.
// We'll override phoneTickCheck to also call our new updates.


// ── HOOK INTO CANVAS CLICK FOR POWERS ─────────────────────────
// We patch the existing click handler to check activePower first
const _origCanvasClick_pwr = cv.onclick;
cv.addEventListener('mousedown', e => {
  if (!activePower) return;
  const cp=getCP(e.clientX,e.clientY);
  let hit=null;
  for(const b of[...bodies].reverse()){
    const s=w2s(b.x,b.y);
    if(Math.hypot(cp.x-s.x,cp.y-s.y)<((b.radius||3)+8)*camSc){hit=b;break;}
  }
  if(hit) applyPowerTo(hit, e);
  else if(activePower==='pulse'){
    const world=s2w(cp.x,cp.y);
    triggerPulse(world.x,world.y,400,null);
  }
  e.stopPropagation();
}, true);

// ── HOOK INTO DRAW LOOP ────────────────────────────────────────
// Patch the existing main render function to add our draws
// We hook into the end of the main draw frame by overriding requestAnimationFrame
const _realRAF = requestAnimationFrame;
let _rafHooked = false;
if (!_rafHooked) {
  _rafHooked = true;
  window._usbExtraDraws = function(dt) {
    // Update sims
    updateCometTrails(dt);
    updateOrbitTrails();
    updateStellarWind(dt);
    updateProtoDisks(dt);
    for(const star of bodies.filter(b=>b.type==='star')) checkStellarEvolution(star,dt);
    if(Math.random()<0.05) checkSolarEclipse();
    const selBody=bodies.find(b=>b.id===selectedId);
    if(selBody&&selBody.type==='planet'){updateComposePanel(selBody);updateOrbitalPanel(selBody);}
    // Draw extras
    drawOrbitTrails();
    drawVelocityArrows();
    drawLagrangePoints();
    drawRocheLimits();
    drawGravWaves(dt);
    drawPulsarBeams(dt);
    drawStellarWind();
    drawProtoDisks();
    drawCometTailsAll();
    drawLaserBeams(dt);
    drawExplosions(dt);
  };
}

function drawCometTailsAll() {
  for(const b of bodies.filter(b=>b.isComet)) drawCometTail(b);
}

// ── PATCH spawnAt FOR COMETS ──────────────────────────────────



// ── HEADER BUTTON WIRING (new buttons) ────────────────────────
function toggleOrbTrails(){ showOrbTrails=!showOrbTrails; document.getElementById('btnOrbTrails').classList.toggle('on',showOrbTrails); }
function toggleVelArrows(){ showVelocityArrows=!showVelocityArrows; document.getElementById('btnVelArrow').classList.toggle('on',showVelocityArrows); }
function toggleLagrange(){ showLagrange=!showLagrange; document.getElementById('btnLagrange').classList.toggle('on',showLagrange); }
function toggleRoche(){ showRocheLimit=!showRocheLimit; document.getElementById('btnRoche').classList.toggle('on',showRocheLimit); }
function toggleGravWaveVis(){ showGravWaves=!showGravWaves; document.getElementById('btnGravW').classList.toggle('on',showGravWaves); }

// ── EXOPLANET PICKER ──────────────────────────────────────────
function showExoplanetPicker(){
  const list=EXOPLANETS.map((ep,i)=>`<button class="hbtn" onclick="spawnExoplanetSystem(${i});document.getElementById('exo-modal').style.display='none'" style="display:block;width:100%;text-align:left;padding:4px 8px;margin-bottom:2px">🌍 ${ep.name} <span style="color:var(--dim);font-size:6px">— ${ep.note}</span></button>`).join('');
  let modal=document.getElementById('exo-modal');
  if(!modal){
    modal=document.createElement('div');
    modal.id='exo-modal';
    modal.style.cssText='position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#050010;border:1px solid var(--accent);padding:12px;z-index:9999;min-width:280px;max-height:80vh;overflow-y:auto;border-radius:8px;box-shadow:0 0 40px rgba(0,212,255,0.3)';
    document.body.appendChild(modal);
  }
  modal.innerHTML=`<div style="font-family:'Orbitron',monospace;font-size:9px;letter-spacing:2px;color:var(--accent);margin-bottom:8px">🌍 EXOPLANET DATABASE</div>${list}<button class="hbtn" onclick="this.parentElement.style.display='none'" style="margin-top:6px;width:100%">✕ CLOSE</button>`;
  modal.style.display='block';
}