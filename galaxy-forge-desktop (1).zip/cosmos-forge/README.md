# 🌌 GALAXY FORGE

A universe simulator desktop app built with Electron.

## Run Locally (Dev Mode)

```bash
npm install
npm start
```

Press **F11** for fullscreen.

## Build Installer

```bash
# Windows (.exe installer)
npm run build:win

# macOS (.dmg)
npm run build:mac

# Linux (.AppImage)
npm run build:linux
```

Output goes to the `dist/` folder.

## Release to GitHub

```bash
git tag v1.0.0
git push origin v1.0.0
```

GitHub Actions will automatically build for Windows, Mac, and Linux and attach the installers to a GitHub Release.

## Requirements

- Node.js 18+
- npm
